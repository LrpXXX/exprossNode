## Generator编程

### 异步编程

异步编程对 JavaScript 语言太重要。JavaScript 这门语言的特点就是单线程，至于为什么设计为单线程下，在之前的文章里面已经有介绍到了，如果没有异步编程，应用根本没法用，非卡死不可。

异步编程方法一般分为几类：

1. 回调函数
2. 事件监听
3. 发布/订阅
4. Promise对象

ES6编程是目前我们最新编程规范，比如拿Nodejs为例子，我们在操作文件的时候，会使用fs提供的api

```js
fs.readFile('file/readme.md', function (err, data) {
  if (err) throw err;
  console.log(data);
});
```

 上面代码中，readFile 函数的第二个参数，就是回调函数，也就是任务的第二段。等到操作系统返回了 file/readme.md 这个文件以后，回调函数才会执行。

我们在读取文件操作或者发送异步请求的时候，频繁的使用回调函数，会出现回调地狱的问题

```js
fs.readFile('file/readme.md', function (err, data) {
  if (err) throw err;
  fs.readFile("file/message.md",function(err2, data2){
      //to do
  })
});
```

回调地狱的问题就是每次都需要在回调函数里面在执行新的异步方案，为了让代码更加优雅，维护性更高，我们在ES6中引入了Promise来进行处理

```js
new Promise((resolve,reject)=>{
    $.ajax({
        url:"http://www.xuchaobo.com",
        success:{
            resolve()
        }
    })
}).then((msg)=>{
    //继续发送异步请求
        return 
}).then((msg)=>{
    //继续发送异步请求  
}).catch((error)=>{
        //发生异常
})
```

通过Promise的方式，可以解决我们回调地狱的问题，代码结构更加的优雅。但是Promise 的写法只是回调函数的改进，使用then方法以后，异步任务的两段执行看得更清楚了，除此以外，并无新意。



### Generator编程

#### 基础语法

generator（生成器）是ES6标准引入的新的数据类型，一个generator看上去像一个函数，但可以返回多次。

当你在学习Generator的时候，你会发现他的语法根python很相似，其实他就借鉴了python的协程语法，意思就是多个线程相互协作，完成异步任务。

generator的基本语法为：

```js
// 语法1
function *main() {
    // do something……
}

// 语法2
function* main() {
    // do something
}
```

Iterator(迭代器)：当我们实例化一个生成器函数之后，这个实例就是一个迭代器。可以通过next()方法去启动生成器以及控制生成器的是否往下执行。

```js
let iterator = main(); //创建一个迭代器
```

yield/next：这是控制代码执行顺序的关键字。
通过yield语句可以在生成器函数内部暂停代码的执行使其挂起，此时生成器函数仍然是运行并且是活跃的，其内部资源都会保留下来，只不过是处在暂停状态。
在迭代器上调用next()方法可以使代码从暂停的位置开始继续往下执行。

案列：

```js
// 首先声明一个生成器函数
function* generators() {
    console.log('starting *generators()');
    yield; // 打住，不许往下走了
    console.log('continue yield 1');
    yield; // 打住，又不许往下走了
    console.log('continue yield 2');
}
// 构造出一个迭代器it
let iterater = generators();

// 调用next()启动*main生成器，表示从当前位置开始运行，停在下一个yield处
iterater.next(); // 输出 starting *main()

// 继续往下走
iterater.next(); // 输出 continue yield 1

// 再继续往下走
iterater.next(); // 输出 continue yield 2
```

我们看到第一个next就是在执行生成器，当代码遇到yield就会阻塞代码，等待下一次的next来唤醒代码。利用这种特性我们可以让生成器返回多个对象

```js
function* generators(val) {
    console.log("step1");
    let x = yield val + 1;
    console.log("step2",x);
    let y = yield (x * 2);
    console.log("step3",y);
    return x + y;
}

//启动一个generator函数
let iterater = generators(10);

let res = iterater.next(); 
console.log(res);  // 输出11 （yield语句后跟的值传给了next()的对象）

res = iterater.next(5); 
console.log(res); // 输出10 （x * 2得到了10传给next(5)运行后的对象）

res = iterater.next(20); // 
console.log(res); // 输出25  (return ...的值传给了next(20)运行后的对象)
```

整个代码流程：

1. 第一个next执行的时候，输出step1，返回的对象为`{value: 11, done: false}`,其中value就是返回值，done代表一个状态，false表示当前执行结果还没有结束。

2. 执行第二个next函数的时候，输出step2，遇到yield代码阻塞，但是返回结果为(x * 2)，所以输出为`{value: 10, done: false}`

3. 执行第三个next函数的时候，输出的值为step3，此刻y的值为20，next传递进去的值赋值给了y，在执行return时候，输出结果为：`{value: 25, done: true}`

    done的状态true代表执行完毕。

#### 处理异步

我们使用generator来处理传统的异步回调函数，接下来我们看一下下面的例子

```js
// 获取所有学生
function fecthStudent(stuid) {
    $.ajax({
        url:"./data.json",
        success:function(msg){
            const arr = msg.filter(res=>stuid == res.id)
            fetchClasses(arr[0].classesId)
        }
    })
}
// 获取所有班级
function fetchClasses(classid){
    $.ajax({
        url:"./data2.json",
        success:function(msg){
            console.log(msg.filter(res=>classid == res.id));
        }
    })
}

fecthStudent(1);
```

上面这个案列，发送异步请求获取到学生的信息，根据学生的信息在获取到班级的信息。这段代码就会产生回调地狱的问题。下一步的依赖必须要基于上一步的结果。所以这种操作就显示比较复杂和冗余，我们可以使用generator来优化代码

```js
// 获取所有学生
function fecthStudent(stuid) {
    $.ajax({
        url:"./data.json",
        success:function(msg){
            const arr = msg.filter(res=>stuid == res.id)
            it.next(arr[0])
        }
    })
}
// 获取所有班级
function fetchClasses(classid){
    $.ajax({
        url:"./data2.json",
        success:function(msg){
            let arr = msg.filter(res=>classid == res.id);
            it.next(arr[0])
        }
    })
}

function* show(){
    // 获取到学生
    let student = yield fecthStudent(1);
    console.log(student);
    let classes = yield fetchClasses(student.id);
    console.log(classes);
}
// 创建执行器，获取到每一步的结果
let it = show();
const res = it.next();
```

我们创建了show执行器，在里面调用fecthStudent和fetchClasses函数来获取数据。每一次调用异步函数过后，接受到一个结果，这个结果来自于success回调里面的it.next()。此处的yield是用于在异步流程中暂停阻塞代码，当然，它阻塞的只有生成器里面的代码，生成器外部的丝毫不受影响

#### await和async

我们使用generator来处理异步调用已经可以解决回调地狱的问题了，但是这种代码设计流程还是比较复杂，学习起来还是比较麻烦，在ES7中提供了async/await来完美解决了上面的问题

首先我们要知道await和async是generator的语法糖，实现原理还是通过generator实现。那接下来用await的语法来实现代码

创建一个异步函数获取学生信息，封装到一个Promise对象中

```js
function fecthStudent(stuid) {
    return new Promise((resolve, reject) => {
        $.ajax({
            url: "./data.json",
            success: function (msg) {
                const arr = msg.filter(res => stuid == res.id)
                // 成功的回调
                resolve(arr[0])
            },
            error: function (error) {
                // 失败的回调
                reject(error)
            }
        })
    })
}
```

接着我们在创建一个异步函数获取班级信息

```js
// 获取所有班级
function fetchClasses(classid) {
    return new Promise((resolve, reject) => {
        $.ajax({
            url: "./data2.json",
            success: function (msg) {
                let arr = msg.filter(res => classid == res.id);
                resolve(arr[0])
            }
        })
    })
}
```

上面这两个函数的公共特点就是封装到Promise对象中，成功过后调用resolve

```js
async function show(){
    const res = await fecthStudent(1);
    console.log(res);
    const res2 = await fetchClasses(res.classesId);
    console.log(res2);
}
show();
```

最后我们通过async和await来获取数据，必须等待await拿到结果过后，下一步才会继续执行。

并且await外面必须要申明函数为async

- async/await在处理promise的层面上省略了对决议的人工处理，让代码量得以减少，语义上也更容易理解
- yield包容性更广泛，async只能接口promise，yield除此之外还能接收字符串、数组、对象等各种类型的数据。



接班流程变化，跟教学的配合



评定薪资，每个阶段老师 都需要参与

学习任务比较重，很多时候 班主任角度 需要鼓励学生，压力如何设计。

前端 方向多。从业方向重点偏差问题。

最终差生如何管理。 

学生提升：

标准统一：教学管理，惩罚必须是教学老师的事儿。降级学生 新班主任必须要聊规则

收到offer和拒绝offer的比例。

对于学院offer的满意度









