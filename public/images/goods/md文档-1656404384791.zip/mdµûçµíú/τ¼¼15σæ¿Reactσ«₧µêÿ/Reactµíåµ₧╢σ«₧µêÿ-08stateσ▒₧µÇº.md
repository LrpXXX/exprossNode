## 组件实例的state属性

state为状态之意，组件在React中可以理解为一个状态机，组件的状态就是用state来记录的，相对于props而言，state是用在组件内部并且可以修改的。

一般情况下，我们可以在state中存放组件的私有数据，这个相当于vue中组件中的data(){return{}} ，例如通过ajax获取的数据都可以存在state中

使用state定义数据一共有三步骤

第一步：定义数据

定义数据可以在构造函数内部定义，也可以在构造函数外部定义

第二步：使用数据

在使用数据的时候为了提高读取性能，最好使用解构赋值方式

第三步：修改数据

修改数据的时候一定要使用setState({})来修改数据，这个方法是一个异步方法

#### 4.1 定义数据和使用数据

```js
import React, { Component } from 'react'
export default class StateComp extends Component {
    constructor(){
        super();
        //1.定义数据
        this.state={
            name:'张三'
        }
    }
    render() {
        return (
            <div>
                {this.state.name}
            </div>
        )
    }
}
```

在上面的例子中，state的初始化放在构造函数中，当然也可以放在构造函数的外部更为简单，如下所示

```js
import React, { Component } from 'react'
export default class StateComp extends Component {
    state={
        name:'张三'
    }
    render() {
        return (
            <div>
                {this.state.name}
            </div>
        )
    }
}
```

在使用数据的时候，最好使用解构赋值的方式，这样能够提高性能

```js
import React, { Component } from 'react'
export default class StateComp extends Component {
    state={
        name:'张三'
    }
    render() {
        //2.使用数据
        const {name}=this.state;
        return (
            <div>
                {name}
            </div>
        )
    }
}
```

#### 4.2 修改数据

```JS
import React, { Component } from 'react'
export default class StateComp extends Component {
    state={
        name:'张三'
    }
    changeData=()=>{
        this.state.name="李四";
    }
    render() {
        //2.使用数据
        const {name}=this.state;
        return (
            <div>
                {name}
                <button onClick={this.changeData}>修改数据</button>
            </div>
        )
    }
}

```

但是要注意不能直接this.state.name="李四";修改，如果这样做就会报如下错误

```JS
src\StateComp.js
  Line 7:9:  Do not mutate state directly. Use setState()  react/no-direct-mutation-state
```

我们需要使用setState()来对state进行修改，并自动更新页面

```js
import React, { Component } from 'react'
export default class StateComp extends Component {
    state={
        name:'张三'
    }
    changeData=()=>{
        this.setState({
            name:'李四'
        })
    }
    render() {
        //2.使用数据
        const {name}=this.state;
        return (
            <div>
                {name}
                <button onClick={this.changeData}>修改数据</button>
            </div>
        )
    }
}
```

#### 4.3 state扩展内容

setState何时是异步的，何时是同步的

当我们在react事件体系内部或者生命周期钩子函数中直接调用时，它是异步的，否则就是同步的，比如在setTimeout/setInterval里面直接调用setState时

1.首先，现在生命周期钩子函数中调用修改内部数据操作

```js
 componentDidMount(){
        this.setState({name:'王二麻子'});
        console.log('this.state',this.state);
 }
```

![1610347197892](F:\WEB前端\笔记\第4阶段\第15周React实战\image\16103471978921.png)



通过上图我们可以看出页面已经更新，打印在控制台的数据还是之前的，这就证明此时为异步的

我们再去钩子函数中修改代码

```js
componentDidMount(){
      setTimeout(()=>{
          this.setState({name:'王二麻子'});
          console.log('this.state',this.state);
      },1000)  
 }
```

观察控制台和页面效果

![1610347466531](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1610347466531.png)

通过上图证明此时为异步的

下面我们再来看一段代码

```js
componentDidMount(){
        this.setState({count:this.state.count+1});
        console.log(this.state.count);
        this.setState({count:this.state.count+1});
        console.log(this.state.count);
    }
```

上面两次更新count数据，但是控制台数据都只是0，页面数据都只是1，不管你写多少次代码都是一样，如果要想获取最新数据，需要如下编写代码

```js
componentDidMount(){
        this.setState((state)=>{
            console.log('state',state);
            return{
                count:state.count+1
            }
        });
        this.setState((state)=>{
            console.log('state',state);
            return{
                count:state.count+1
            }
        });
        this.setState((state)=>{
            console.log('state',state);
            return{
                count:state.count+1
            }
        });
    }
```

![1610348473958](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1610348473958.png)



**总结1：关于函数组件和类组件的对比**

- 函数组件也称为“无状态组件”，这种后续使用并不多，类组件也称为有状态组件，后续使用较多
- 有状态组件和无状态组件的使用场景
    - 如果一个组件需要有自己的私有数据，则推荐使用有状态组件（类组件）
    - 如果一个组件不需要有私有数据，则推荐使用无状态组件
    - 由于无状态组件没有自己的state和生命周期函数，所以运行效率会比有状态组件高一些
- 在实际开发过程中建议使用有状态组件

**总结2：组件的props和state之间的区别**

- props中的数据都是外部传递过来的；state中的数据，都是组件私有的（通过ajax获取的数据，一般都是私有数据）
- props中的数据都是只读的，不能重新赋值；state总的数据，是可读可写的。