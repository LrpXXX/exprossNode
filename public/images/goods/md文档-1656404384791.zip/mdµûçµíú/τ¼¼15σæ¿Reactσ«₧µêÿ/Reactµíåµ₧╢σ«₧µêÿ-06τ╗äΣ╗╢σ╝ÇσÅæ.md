## 一.React组件入门

### 1.组件的概念

在VUE中涉及到了组件的概念，在react中也是一样的概念。在传统的项目中，我们的页面都是以html的形势来进行开发，但是有很多内容是可以复用的，比如网站的头部和尾部，此刻我们就可以将这些内容抽取为组件，在任何一个页面中都可以复用这样就能达到代码的的复用。

​		组件允许你将 UI 拆分为独立可复用的代码片段，并对每个片段进行独立构思。本指南旨在介绍组件的相关理念。

​		React最强大的地方也是组件的开发，React按照可复用组件的概念来设计的。定义一个个的小组件，然后组装成大组件。所有的组件不论大小都是可复用的，即使跨项目也一样。一个组件，从形式上看就是一个普通的JS函数。

​	在React中我们定义组件有多种方式，目前可以分类为：

- 函数类型组件(无状态组件)
- 类组件(有状态组件)

#### r1.1 函数组件

```js
import React from 'react';
import ReactDOM from 'react-dom';
function LoginForm(){
    return <h1>会员登录</h1>;
}
const template=<LoginForm></LoginForm>
ReactDOM.render(template,document.getElementById('root'));
```

 在上面的代码中，我们定义了一个组件LoginForm，在ReactDOM.render函数里面调用这个组件的时候，我们需要使用标签的形式来引用这个组件`<LoginForm/>`

在组件中也可以引入其他的组件

```js
import React from 'react';
import ReactDOM from 'react-dom';
function FormTitle(){
    return <h1>会员登录</h1>;
}
function FormUserName(){
    const template=(
        <p>
            <label>用户名:</label>
            <input type="text" name="userName"></input>
        </p>
    );
    return template; 
}
function FormPassword(){
    const template=(
        <p>
            <label>密码:</label>
            <input type="password" name="password"></input>
        </p>
    );
    return template;
}
function FormSubmit(){
    const template=(
        <p>
            <input type="submit" value="登录"></input>
        </p>
    );
    return template;
}
function LoginForm(){
    const template=(
        <div>
            <FormTitle></FormTitle>
            <FormUserName></FormUserName>
            <FormPassword></FormPassword>
            <FormSubmit></FormSubmit>
        </div>
    );
    return template;
}
const template=<LoginForm></LoginForm>
ReactDOM.render(template,document.getElementById('root'));
```

#### 1.2 类组件

类组件的创建语法

```js
class 组件名称 extends React.Component{
    render(){
        return <div>这是class创建的组件</div>
    }
}
```

具体使用案例

第一步：创建User.jsx文件

```js
import React from 'react'
class User extends React.Component{
    render(){
        const template=(
            <div>
                <ul>
                    <li>用户名：张三丰</li>
                    <li>年龄:120</li>
                    <li>特长：打太极</li>
                </ul>
            </div>
        );
        return template;
    }
}
export default User;
```

上面这段代码就是定义了类组件，我们使用了ES6的语法来定义，React.Component就是默认定义好的组件对象，继承这个对象就可以完成组件的定义，并且默认调用render函数完成组件调用。

```jsx
export default class User2 extends PureComponent {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}
```

\* Component是React App的基本构建的单位，也是React中的基本代码复用单位。

 \* PureComponent与Component在除了其shouldComponentUpdate方法的实现之外几乎完全相同。

 \* PureComponent已经替我们实现了shouldComponentUpdate方法

 \* 对于PureComponent而言，当其props或者state改变之时，新旧props与state将进行浅对比

第二步：在index.js文件中引入User.jsx组件

```js
import React from 'react';
import ReactDOM from 'react-dom';
import User from './User'
const template=(
    <div>
        <User></User>
    </div>
);
ReactDOM.render(template,document.getElementById('root'));
```

### 2. 组件的样式

组件的样式主要有三种：

1. 内联样式，主要通过style标签来渲染
2. 普通样式，通过className或者id属性来定义

接下来我们就演示一下内联样式的设计：

```js
class Button extends React.Component{
    render(){
        return <h1 style={{color:"red",fontSize:"20px"}}>蜗牛学院</h1>
    }
}
```

这种样式定义方式就是直接在jsx模板上面填写style属性来定义。外层的{}是jsx的模板语法，内层{}代表包裹样式。多个样式需要使用`，`来进行分割。

注意事项：

1. 多个属性之间需要使用逗号来分割，不能使用分号，这是跟css样式的区别。
2. 属性中不能出现`-`需要采用驼峰命名法来设计。
3. 样式中的key可以不用引号，但是value需要使用引号括起来。

普通样式的设计：

普通样式设计主要就是通过外部css样式来设计。我们可以先在项目中src目类创建一个css文件夹，接着创建一个base.css文件。

```css
.as {
    width: 100px;
    height: 100px;
    background-color: red;
}

#show {
    border-radius: 10px;
}
```

在app.jsx组件中引入这个样式文件

```js
import React from "react";
//引入样式代码
import "./css/base.css"

class Button extends React.Component{
    render(){
        return (
            <div>
                <h1 style={{color:"red",fontSize:"20px"}}>蜗牛学院</h1>
                <div className="as" id="show"></div>
            </div>
        )
    }
}
```

在上面代码中，我们要使用外部文件中的class样式，组件里面需要使用className来表示class属性，这是jsx中需要注意的一个地方。

如果是普通样式，最终渲染出来的结果，样式会在页面的头部出现

### 3.组件中的图片

在react中要引入图片资源我们不能直接跟之前一样，src=”相对路径“

有两种方案：

1. 将图片作为模块导入到react组件中

    ```
    // 方法1可以将图片导入进来
    import imgsrc from "../../assets/images/ic_tab_profile_active.png"
    <img src={imgsrc} alt="" />
    ```

2. 使用require将图片加载到组件中

    ```
    // 方法2使用require来引入
    // require返回一个ES模块而不是字符串。这是因为在file-loader中，esModule选项是默认启用的
    const img = require("../../assets/images/ic_tab_profile_active.png").default;
    <img src={img} alt="" />
    
    或者
    <img src={require("../../assets/images/ic_tab_profile_active.png").default} alt="" />
    ```

3. 如果要用图片来设置背景

    ```html
    <div style={
         { 
             width: "200px",
             height: "200px", 
             backgroundImage: `url(${require("../../assets/images/ic_tab_profile_active.png").default})` ,
             border:"1px solid red"
         }
    }></div>
    ```

### 2.组件的事件处理

#### 2.1 React的事件绑定

React 元素的事件处理和 DOM 元素的很相似，但是有一点语法上的不同：

- React 事件的命名采用小驼峰式（camelCase），而不是纯小写。
- 使用 JSX 语法时你需要传入一个函数作为事件处理函数，而不是一个字符串。

```js
import React from 'react';
class Welcome extends React.Component{
    clickMe(){
        console.log('我被点击了');
        console.log(this);
    }
    render(){
        return <h1 onClick={this.clickMe}>Hello World</h1>;
    }
}
export default Welcome;;
```

#### 2.2 关于this指向问题

在组件中绑定事件，其中需要注意一个问题就是this指向的问题。

```js
clickMe(){
    console.log('我被点击了');
    console.log(this);
}
```

如果直接在clickMe中输出this，那输出的值为undefined，因为在普通函数里面this执行由调用的时候来确定的。那我们如果要将this执行组件本身，解决方法有两种

第一种方法：将普通函数改为箭头函数。

```js
clickMe=()=>{
    console.log('我被点击了');
    console.log(this);
}
```

使用箭头函数，我们输出this的时候指向就是Welcome组件。

第二种方法: this.函数().bind(this)

这种方式是ES5的处理办法，这种方式还是比较麻烦，建议使用ES6的箭头函数进行处理

可以在调用的时候编写

```js
import React, { Component } from 'react'

export default class Hello extends Component {
    clickeMe(){
        console.log("我被单击了...")
        console.log(this)
    }
    render() {
        return (
            <div>
                <div onClick={this.clickeMe.bind(this)}>Hello</div>
            </div>
        )
    }
}
```

或者在构造函数的内部绑定

```js
import React, { Component } from 'react'

export default class Hello extends Component {
    constructor(){
        super();
        this.clickeMe=this.clickeMe.bind(this);
    }
    clickeMe(){
        console.log("我被单击了...")
        console.log(this)
    }
    render() {
        return (
            <div>
                <div onClick={this.clickeMe}>Hello</div>
            </div>
        )
    }
}

```



#### 2.3 组件中如何给函数传递参数

由于事件调用函数的时候，后面不能写this.函数(),只能this.函数名，但是传递参数的时候必须要使用小括号将参数传递进去，所以这里如果要处理可以使用如下格式

()=>this.函数名(参数值)

```js
import React, { Component } from 'react'

export default class Hello extends Component {
    constructor(){
        super();
    }
    clickeMe=(params)=>{
      console.log(params);
    }
    render() {
        return (
            <div>
                <div onClick={()=>this.clickeMe(123)}>Hello</div>
            </div>
        )
    }
}
```









