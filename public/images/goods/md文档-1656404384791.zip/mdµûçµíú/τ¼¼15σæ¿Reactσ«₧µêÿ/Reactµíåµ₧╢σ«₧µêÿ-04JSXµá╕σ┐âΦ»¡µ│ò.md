## jiJSX核心语法

​		通过上面的代码，大家可以清晰的看到使用JSX方式创建虚拟DOM的方式更加简单，而且还有一个很奇怪的写法就是在js中可以直接写HTML代码，而且不使用双引号的方式作为字符串来括起来，这个是我们之前所学的知识无法实现的，但是在React中就可以这么做，这种语法我们称为JSX语法。

### 1.什么是JSX

​		JSX=JavaScript+XML，可以说是JavaScript的一种扩展语法，他结合了JavaScript和xml的语法，JSX 可以很好地描述 UI 应该呈现出它应有交互的本质形式。JSX 可能会使人联想到模版语言，但它具有 JavaScript 的全部功能。

​		React 认为渲染逻辑本质上与其他 UI 逻辑内在耦合，比如，在 UI 中需要绑定处理事件、在某些时刻状态发生变化时需要通知到 UI，以及需要在 UI 中展示准备好的数据。

使用JSX语法的优点：

- JSX 执行更快，因为它在编译为 JavaScript 代码后进行了优化
- JSX 是类型安全的，在编译过程中就能发现错误
- 使用 JSX 编写模板更简单快速

### 2.JSX表达式

**2.1 JSX嵌入表达式**

我们声明了一个名为 name 的变量，然后在 JSX 中使用它，并将它包裹在大括号中：

```js
const name="蜗牛学院";
const template=<div>欢迎来到{name}</div>
ReactDOM.render(template,document.getElementById('root'));
```

在上面的代码中，我们在h1模板里面创建了一个大括号，并且引用了name这个变量，那最终渲染的时候，就会将变量的值放在模板中一起渲染出结果。

最终在渲染的时候，遇到`<>`标签就解析为html代码，遇到`{}`就按照JavaScript来解析，这就是我们的规则。

**2.2 算数表达式**

```js
let firstNum=10;
let secondNum=20;
const template=<div>结果为:{firstNum+secondNum}</div>
ReactDOM.render(template,document.getElementById('root'));
```

**2.3 条件表达式**

```js
let age=12;
const template=<div>是否成年:{age>=18?'成年':'未成年'}</div>
ReactDOM.render(template,document.getElementById('root'));
```

**2.4 JSX对象表达式**

```js
const user={
       username:'Giles',
       school:'蜗牛学院西安校区',
}
const template=<h1>我是{user.school}的{user.username}</h1>
ReactDOM.render(template,document.getElementById('root'));
```

**2.5 JSX函数表达式**

甚至在括号中，我们调用函数也是可以的

```js
const user={
    username:'Giles',
    school:'蜗牛学院西安校区',
}
function introduce(user){
    return "我是"+user.school+"的"+user.username;
}
const template=<h1>{introduce(user)}</h1>
ReactDOM.render(template,document.getElementById('root'));
```

**2.6 JSX数组表达式**

```js
import React from 'react';
import ReactDOM from 'react-dom';
const students=['张晓华','王明','黄森'];
const template=(
    <div>
        <h2>学生列表</h2>
        {students}
    </div>
);
ReactDOM.render(template,document.getElementById('root'));
```

如上操作显示数组中的内容，如果要遍历这个数组代码如下所示

```js
import React from 'react';
import ReactDOM from 'react-dom';
const students=['张晓华','王明','黄森'];
const studentsDom=students.map((item,index)=>{
    return <li key={index}>{item}</li>
});
const template=(
    <div>
        <h2>学生列表</h2>
        <ul>
            {studentsDom}
        </ul>
    </div>
);
ReactDOM.render(template,document.getElementById('root'));
```

### **2.7 JSX防止注入攻击**

```jsx
const template  = <script> alert() </script>

ReactDOM.render(
  template,
  document.getElementById('root')
);
```

React DOM 在渲染所有输入内容之前，默认会进行转义。它可以确保在你的应用中，永远不会注入那些并非自己明确编写的内容。所有的内容在渲染之前都被转换成了字符串。这样可以有效地防止 XSS（cross-site-scripting, 跨站脚本）攻击。

​		上面的代码中，我们在模板中写了alert()函数，最终在解析的时候，会将alert函数看成是字符串来解析。

### 3.JSX中的样式

**3.1 行内样式**

```js
import React from 'react';
import ReactDOM from 'react-dom';
const students=['张晓华','王明','黄森'];
const studentsDom=students.map((item,index)=>{
    return <li key={index} style={{listStyleType:'circle'}}>{item}</li>
});
const template=(
    <div>
        <h2>学生列表</h2>
        <ul>
            {studentsDom}
        </ul>
    </div>
);
ReactDOM.render(template,document.getElementById('root'));
```

注意：行内样式要使用style={{key:value}}的形式

**3.2 外部样式**

首先，在src中新建index.css文件，代码如下

```css
.studentList{
    list-style-type:square;
}
```

其次，在index.js中导入并使用className进行引入

```js
import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
const students=['张晓华','王明','黄森'];
const studentsDom=students.map((item,index)=>{
    return <li key={index} className='studentList'>{item}</li>
});
const template=(
    <div>
        <h2>学生列表</h2>
        <ul>
            {studentsDom}
        </ul>
    </div>
);
ReactDOM.render(template,document.getElementById('root'));
```

注意：样式的类名指定使用className,切记不要写成class

### 4.JSX包含多个子元素

如果我们定义的标签有多个，这个时候我们需要一个根标签来包裹内容，这是JSX中默认的一个规范，否则代码将无法解析运行，如下所示

```js
const template = <h1>这是标题1</h1><h2>这是标题2</h2>

ReactDOM.render(
  template,
  document.getElementById('root')
);
```

这种写法在编译的过程中就会报错，因为h1和h2这两个标签没有根标签来进行包裹。我们可以将代码改为如下：

```js
const template = <div><h1>这是标题1</h1><h2>这是标题2</h2></div>
```

如果遇到模板包含的内容比较多，我们建议使用`()`将内容包裹起来

```js
const template = (
		<div>
			<h1>这是标题1</h1>
			<h2>这是标题2</h2>
		</div>
)
```

### 5.JSX中的注释

我们在JSX语法中也可以加入注释，可以帮助我们更方便的看代码

```js
const conatiner=(
    <div>
        {/*这里是JSX注释*/} 
        <h1>Hello React</h1>
        <h1>Hello Woniuxy</h1>
        <h1>Hello Giles</h1>
     </div>
)
```

如果你使用的是vscode工具，那你可以使用ctrl+/快捷键快速的创建注释。

