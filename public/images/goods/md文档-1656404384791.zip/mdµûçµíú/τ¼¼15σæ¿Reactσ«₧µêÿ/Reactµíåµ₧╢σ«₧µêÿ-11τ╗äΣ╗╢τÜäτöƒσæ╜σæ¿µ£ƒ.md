## 三.组件的生命周期

生命周期指的就是从组件的加载初始化-数据的改变-组件的卸载阶段。描述的就是组件从创建到死亡的阶段，react的生命周期中提供了很多个生命周期钩子函数来方便我们操作。

react的生命周期主要分为以下的几个步骤：

1. 挂载阶段：组件数据的初始化，及组件数据的渲染
2. 运行阶段：这个节点是最长的阶段，主要用户对组件的数据进行修改，状态改变以及重绘
3. 卸载阶段：这个阶段也是销毁阶段，组件运行完成后，或者从页面中移除，那么组件就应该被销毁。这个阶段我们可以执行一些资源的回收，性能优化的代码可以在这里设计。

组件的生命周期流程图



### 1.组件的挂载阶段

组件的挂载阶段也是组件创建-数据初始化-数据渲染的过程。接下来通过代码来演示执行的流程。

1.1 constructor构造器执行的阶段

构造执行那就意味着组件正在被创建，并且数据也可以在这里初始化。

```js
import React from 'react';
export default class LifeCycle extends React.Component{
    constructor(props){
        super(props);
        this.state={msg:'蜗牛学院'}
        console.log('====执行constructor组件正在创建和初始化');
    }
    static defaultProps={
        data:100
    }
    render(){
        console.log("====调用render方法开始执行数据渲染");
        return (
            <div>
                <h1>React生命周期全过程</h1>
                <h3 id="myprop">props传递的数据:{this.props.data}</h3>
                <h4 id="mydata">state组件内部数据:{this.state.msg}</h4>
            </div>
        );
    }
}
```

输出的结果为：

```js
====执行constructor组件正在创建和初始化
====调用render方法开始执行数据渲染
```

先执行constructor构造器将数据初始化，其中props和state的数据就会被加载。接着执行render函数来渲染。

1.2 componentDidMount函数执行

界面渲染完毕（DOM挂载完毕）的一个通知，类似于vue组件中的created,我们可以在这个生命周期做

很多事情。

- 获取DOM节点
- 发送请求获取后台数据
- 设置定时器、延时器等等
- 绑定全局事件，例如document的点击事件等等

```js
componentDidMount(){
    console.log('====componentDidMount');
}
```

### 2.组件的运行阶段

每当组件的props或者state变化之后，都会导致组件的更新，我们可以使用钩子函数在组件更新之前或者之后做一些逻辑操作。

2.1 在页面上增加一个按钮，绑定事件来修改state值

```js
changeData=()=>{
    this.setState({
       msg:'蜗牛创想'
    });
}
render(){
     return (
        <div>
            <h1>React生命周期全过程</h1>
            <button type='button' onClick={this.changeData}>更新组件中的数据</button>
            <h3 id="mydata">当前页面的数据:{this.state.msg}</h3>
        </div>
     );
}
```

我们点击按钮就会执行changeDate来修改数据。

2.2 创建shouldComponentUpdate钩子函数来拦截数据修改

```js
shouldComponentUpdate(){
     return false;
}
```

定义在重新render之前被调用，可以返回一个布尔值来决定一个组件是否更新， 如果返回false，那么前面的流程都不会被触发。这个方法默认的返回值都是true。

这里我们再来完成一个功能就是将外部传递进来的数据赋给内部变量data,当点击按钮的时候每次增加1

```js
import React from 'react';
export default class LifeCycle extends React.Component{
    constructor(props){
        super(props);
        this.state={msg:'蜗牛学院',data:props.data}
        console.log('====执行constructor组件正在创建和初始化');
    }
    static defaultProps={
        data:100
    }
    componentDidMount(){
        console.log('===调用componentDidMount');
        console.log(document.getElementById('mydata'));
    }
    shouldComponentUpdate(){
        console.log(this.state.data);
        return true;
    }
    changeData=()=>{
        console.log('更新组件中的数据');
        this.setState({
            msg:'蜗牛创想',
            data:this.state.data+1
        });
    }
    render(){
        console.log("====调用render方法开始执行数据渲染");
        return (
            <div>
                <h1>React生命周期全过程</h1>
                <button type='button' onClick={this.changeData}>更新组件中的数据</button>
                <h3 id="myprop">props传递的数据:{this.props.data}</h3>
                <h4 id="mydata">state组件内部数据:{this.state.msg}</h4>
            </div>
        );
    }
}
```

但是从控制台的显示结果来看，每次点击之后都是上次的数据（没有自增之前的数据），如果要想得到更改后的数据我们可以使用如下参数来解决这个问题

参数：nextProps代表更改后的props值；nextState代表更改过后的state值。我们可以获取到这个数据进行判断

```js
shouldComponentUpdate(nextProps,nextState){
    console.log(this.state.data+"---->"+nextState.data);
    return true;
}
```

控制台显示效果如下所示

![1608518622436](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1608518622436.png)

2.3 componentDidUpdate钩子函数来执行通知。

```js
componentDidUpdate(){
	console.log("数据修改成功");
}
```

### 3.组件的卸载阶段

componentWillUnmount，在组件被卸载和销毁之前调用的方法，可以在这里做一些清理的工作。我们要完成组件的卸载，那需要创建两个组件，在父组件中引入子组件，当条件为true的时候就加载组件，条件为false的时候就卸载组件。

```js
export default class ParentCom extends Component {
    state = {
        isShow:true
    }
    changePanel = ()=>{
        this.setState({
            isShow:false
        })
    }
    render() {
        return (
            <div>
                <h1>ParentComponent</h1>
                {this.state.isShow && <ChildCom/>}
                {/* {this.state.isShow && } */}
                <button type="button" onClick={this.changePanel}>点击切换</button>
            </div>
        )
    }
}
```

花括号中嵌入逻辑与 (&&) 运算符。它可以很方便地进行元素的条件渲染，&&是我们的短路运算符，一旦this.state.boo的值为false，那后面`<ChildCom>`的组件就不会渲染。

当点击按钮我们动态修改isShow的值，然后判断条件false组件就卸载。

```js
export default class ChildCom extends Component {
    render() {
        return (
            <div>
                <h2>ChildComponent</h2>
            </div>
        )
    }
    componentWillUnmount(){
        console.log("ChildCom组件正在卸载");
    }
}
```

一旦组件卸载那就执行componentWillUnmount钩子函数完成调用，那我们可以完成清理工作。

执行结果为：

```js
ChildCom组件正在卸载
```

### 4.资源清理

在componentWillUnmount钩子函数中我们可以执行一些资源清理工作。比如事件解绑，定时器清除等等工作。

先在ChildCom子组件里面定义事件和定时器等等代码。

```js
componentDidMount(){
    this.timer = setInterval(function(){
    	console.log("定时器执行");
    },1000);
}
```

在componentDidMount组件里面设置一个定时器，我们在父组件里面将组件卸载。但是定时器依然在执行所以，所以在组件卸载的时候我们需要清楚定时器。

```js
componentWillUnmount(){
    console.log("ChildCom组件正在卸载");
    clearInterval(this.timer);
}
```

 执行完组件的卸载，那定时器就被清除。