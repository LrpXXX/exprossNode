## 表单组件

在 React 里，HTML 表单元素的工作方式和其他的 DOM 元素有些不同，这是因为表单元素通常会保持一些内部的 state，如果你接触过vue那你应该知道v-model属性可以实现一个双向绑定。在react中我们也想操作表单，实现数据绑定的效果。

### 1.受控组件

​	在 HTML 中，表单元素（如<input>、 <textarea> 和 <select>）之类的表单元素通常自己维护 state，并根据用户输入进行更新。而在 React 中，可变状态（mutable state）通常保存在组件的 state 属性中，并且只能通过使用 setState()来更新。

​		我们可以把两者结合起来，使 React 的 state 成为“唯一数据源”。渲染表单的 React 组件还控制着用户输入过程中表单发生的操作。被 React 以这种方式控制取值的表单输入元素就叫做“受控组件”。

```js
import React from 'react';
export default class LoginCom extends React.Component{
    constructor(){
        super();
        this.state={
            username:'Giles',
            password:'000000'
        }
    }
    bindUserName=(e)=>{
      this.setState({
          username:e.target.value
      });
      console.log(this.state.username);
    }
    bindPassword=(e)=>{
        this.setState({
            password:e.target.value
        });
        console.log(this.state.password);
    }
    render(){
        return(
            <div>
                <p>
                    <label>用户名:</label>
                    <input type="text" onChange={this.bindUserName} value=       {this.state.username}/>
                </p>
                <p>
                    <label>密码:</label>
                    <input type="text" onChange={this.bindPassword} value={this.state.password}/>
                </p>
            </div>
        );
    }
}
```

1. 我们在input标签里面定义了value属性，这个属性就是文本框的值，将state对象里面的username绑定到文本框里面
2. onChange是必须要的，这个函数相当于绑定了一个事件，当数据发生变化的时候，可以执行你绑定的函数handler。
3. 定义bindUserName函数，将文本框的值动态绑定赋值给state对象

```js
bindUserName=(e)=>{
    this.setState({
        username:e.target.value
    });
    console.log(this.state.username);
}
```

参数e代表事件对象，可以通过e来获取到target目标对象，通过value值来获取文本框的值。

### 2.非受控组件

众所周知，React 通过声明式的渲染机制把复杂的 DOM 操作抽象成为简单的 state 与 props 操作，一时圈粉无数，一夜间将前端工程师从面条式的 DOM 操作中拯救出来。尽管我们一再强调在 React 开发中尽量避免 DOM 操作，但在一些场景中仍然无法避免。当然 React 并没有把路堵死，它提供了 ref 用于访问在 render 方法中创建的 DOM 元素或者是 React 组件实例。

​	有时使用受控组件会很麻烦，因为你需要为数据变化的每种方式都编写事件处理函数，并通过一个 React 组件传递所有的输入 state。当你将之前的代码库转换为 React 或将 React 应用程序与非 React 库集成时，这可能会令人厌烦。在这些情况下，你可能希望使用非受控组件, 这是实现输入表单的另一种方式。

​	 在大多数情况下，我们推荐使用 受控组件 来处理表单数据。在一个受控组件中，表单数据是由 React 组件来管理的。另一种替代方案是使用非受控组件，这时表单数据将交由 DOM 节点来处理。

​		要编写一个非受控组件，而不是为每个状态更新都编写数据处理函数，你可以 使用 ref 来从 DOM 节点中获取表单数据。

```js
import React from 'react';
export default class RegisterCom extends React.Component{
    constructor(){
        super();
        this.register=this.register.bind(this);
    }
    register(e){
        console.log('=====用户注册方法=====');
        console.log('用户名'+this.usernameEle.value);
        console.log('密码:'+this.passwordEle.value);
        e.preventDefault();
    }
    render(){
        return(
            <div>
                <form action="#" onSubmit={this.register}>
                    <p>
                        <label>用户名:</label>
                        <input type="text" ref={input=>this.usernameEle=input}/>
                    </p>
                    <p>
                        <label>密码:</label>
                        <input type="text" ref={input=>this.passwordEle=input}/>
                    </p>
                    <p>
                        <input type="submit" value='注册'/>
                    </p>
                </form>
            </div>
        );
    }
}
```

非受控组件的含义就是我们的表单组件不受state对象的影响，可以不用将这两个内容绑定在一起，但是依然可以获取到当前这个文本框的值。

我们采用ref属性来获取到当前的节点。在通过this.usernameEle.value来获取到当前节点的值。

如果你的ref引用的值为字符串，我们还可以通过refs来获取值

```jsx
<input type="text" ref="inputEle"/>

check = ()=>{
        console.log(this.usernameInput.value);
        // 不推荐使用
        console.log(this.refs.inputEle.value);
    }
```

如果refs这种方式，我们不推荐使用。

问题：当 ref 定义为 string 时，需要 React 追踪当前正在渲染的组件，在 reconciliation 阶段，React Element 创建和更新的过程中，ref 会被封装为一个闭包函数，等待 commit 阶段被执行，这会对 React 的性能产生一些影响。

当然我们还有第二种方案可以实现非受控组件

```js
import React from 'react';
export default class RegisterCom extends React.Component{
    constructor(){
        super();
        this.username=React.createRef();
        this.password=React.createRef();
        this.register=this.register.bind(this);
    }
    register(e){
        console.log('=====用户注册方法=====');
        console.log(this.username.current.value);
        console.log(this.password.current.value);
        e.preventDefault();
    }
    render(){
        return(
            <div>
                <form action="#" onSubmit={this.register}>
                    <p>
                        <label>用户名:</label>
                        <input type="text" ref={this.username}/>
                    </p>
                    <p>
                        <label>密码:</label>
                        <input type="text" ref={this.password}/>
                    </p>
                    <p>
                        <input type="submit" value='注册'/>
                    </p>
                </form>
            </div>
        );
    }
}
```

其中我们在constructor里面通过React.createRef这个函数来获取到一个ref对象，这个对象包含了一个current属性，属性指向了绑定的原生或者组件对象。

## 五.练习:完成todoList

```js
import React, { Component } from 'react'
import './todolist.css'
export default class Todolist extends Component {
    state={
        list:[
            {id:0,task:'学习vue',status:'done'},
            {id:1,task:'学习react',status:'undone'}
        ],
        curBtn:"all",//all,done,undone
    }
    get showedList(){
        const {list,curBtn}=this.state;
        switch(curBtn){
            case "all":
               return list;
            case "done":
               return list.filter(item=>item.status==="done");
            case "undone":
                return list.filter(item=>item.status==="undone");
            default:
                return list; 
        }
    }
    //增加任务
    addTask=()=>{
        this.setState(({list})=>{
            //1.获取输入的数据
            let task=this.taskInput.value;
            //2.构建数据中的元素
            const taskObj={id:list.length,task,status:'undone'};
            //3.向数据中添加元素
            list.unshift(taskObj);
            return {
                list
            }
        })
    }
    //切换任务状态
    toggleTaskStatus=(e)=>{
      const {list}=this.state;
      const liEle=e.target;
      const id=liEle.getAttribute('data-id');
      for(const o of list){
         if(Number(id)===o.id){
            o.status=o.status==='done'?"undone":"done";
            this.setState({list});
            break;
         }
      }
    }
    clickBtn=(e)=>{
        const curBtn=e.target.getAttribute("data-btn");
        this.setState({curBtn});
    }
    render() {
        const { list,curBtn}=this.state;
        return (
            <div>
                <input type="text" ref={input=>this.taskInput=input} 
						placeholder="请输入任务"></input>
                <button onClick={this.addTask}>添加任务</button>
                <ul onClick={this.toggleTaskStatus}>
                    {
                       this.showedList.map((item,index)=>{
                           return  <li data-id={item.id} 
                           				key={item.id} 
                           				className={item.status}>{item.task}
                           			</li>;
                       })
                    }
                </ul>
                <div onClick={this.clickBtn}>
                    <button data-btn="all" 
							className={curBtn==="all"?"activeBtn":""}>全部</button>
                    <button data-btn="done" 
							className={curBtn==="done"?"activeBtn":""}>已完成</button>
                    <button data-btn="undone" 
							className={curBtn==="undone"?"activeBtn":""}>未完成</button>
                </div>
            </div>
        )
    }
}
```

## 六. 面试题

### js数据类型有哪些？有什么区别

ECMAScript中有5中简单数据类型（也称为基本数据类型）: Undefined、Null、Boolean、Number和String。还有1中复杂的数据类型————Object，Object本质上是由一组无序的名值对组成的。

其中Undefined、Null、Boolean、Number都属于基本类型。Object、Array和Function则属于引用类型，String有些特殊，具体的会在下面展开分析。

#### Undefined

Undefined类型只有一个值，即特殊的undefined。在使用var声明变量但未对其加以初始化时，这个变量的值就是undefined。不过，一般建议尽量给变量初始化，但是在早期的js版本中是没有规定undefined这个值的，所以在有些框架中为了兼容旧版浏览器，会给window对象添加undefined值。

#### Null

Null类型是第二个只有一个值的数据类型，这个特殊的值是null。从逻辑角度来看，null值表示一个空对象指针，而这也正是使用typeof操作符检测null时会返回object的原因,定义一个对象的时候，建议用null来初始化。

undefined值是派生自null值的，因此ECMA-262规定对它们的相等性测试要返回true

```
console.log(undefined == null); //true
```

#### String

string类型有些特殊，因为字符串具有可变的大小，所以显然它不能被直接存储在具有固定大小的变量中。由于效率的原因，我们希望JS只复制对字符串的引用，而不是字符串的内容。但是另一方面，字符串在许多方面都和基本类型的表现相似，而字符串是不可变的这一事实（即没法改变一个字符串值的内容），因此可以将字符串看成行为与基本类型相似的不可变引用类型

### 谈一下你对作用域的理解

定义:规定了某个变量的可见性和生命周期。分类:根据变量作用域的不同我们将作用域分为了函数作用域和全局作用域。

全局作用域:定义在全局作用域的变量是整个当前 JavaScript 程序都可以访问。

函数作用域:定义在函数中的变量是在定义函数中使用。

为什么要有作用域: 避免变量定义混乱。因为很多时候，我们需要一个整个程序都要用到的变量，而有时我们需要一个同名的局部变量，仅仅只在某个范围内有效，比如函数中有效。

早期的JavaScript是没有块作用域的，直到ES6提出了let 和const才有了块作用域

```js
function b(){
    var myVar;
    console.log(myVar);
}
function a(){
    var myVar=2;
    console.log(myVar);
    b();
}
var myVar=1;
    console.log(myVar);
a();

1
2
undefined
```

解决这个问题我们需要冲洗你考虑执行上下文了。

首先全局执行上下文创建，因此函数外部的变量被放到了内存中 myVar=1；
a()函数执行，在a函数变量环境中myVar=2，被放到内存，执行b函数;
b函数执行，上下文发生变化，由a转到b函数执行上下文中，此时myVar的值是undefined。

1.确定this

官方的称呼为This Binding，在全局执行上下文中，this总是指向全局对象，例如浏览器环境下this指向window对象。

而在函数执行上下文中，this的值取决于函数的调用方式，如果被一个对象调用，那么this指向这个对象。否则this一般指向全局对象window或者undefined（严格模式）。

### 作用域链

```
function b(){
    console.log(myVar);
}
function a(){
    var myVar=2;
    b();
}
var myVar=1;
a();//结果是：1
```

因为在b函数中我们没有声明任何变量。所以b函数执行上下文变量环境中没有myVar。

但是当我们请求一个变量时，当我们对变量进行处理时，JS会做更多的事。

只需查看当前正在执行的上下文的可变环境就行。

```
function a(){
    var myVar=2;
    function b(){
        console.log(myVar);
    }
}
var myVar=1;
a();
b();//此时 我们不能够直接执行b函数
```

因为b函数在a函数内，b（）却在全局执行上下文中，但是声明b函数在a函数内部，全局执行上访问不到b函数

### 谈一下你对原型的理解

访问原型的两种方式：

```js
function A(){};
var a = new A();
console.log(a.__proto__ === A.prototype);
```

Don't BB！ Show me the code！

```js
function Person(name, age){
    this.name = name;
    this.age = age;
    
    this.getInfo = function(){
        console.log(this.name + " is " + this.age + " years old");
    };
}

var will = new Person("Will", 28);
```

![593627-20151030202437185-69808437](https://woniumd.oss-cn-hangzhou.aliyuncs.com/web/xuchaobo/20210808220506.png)



### 什么是闭包

闭包就是可以访问其他函数中变量的函数。即能使用其他函数内部变量的函数。内部函数总是可以访问其所在的外部函数中声明的参数和变量，即使在其外部函数被返回（寿命终结）了之后。

当然如果上面的语句你不好理解，你可以理解为，函数A里面定义了一个函数B,B函数可以使用A函数的变量或者值，那我们就将这种情况称为闭包。

```
/**
 * 函数闭包：在一个函数内部定义一个函数，内部函数使用外部函数的数据。
 */
function f1() {
    var number = 10;
    function f2() {
        console.info(number);
    }
    f2();
}
f1()
```

 \* 闭包的作用

 \* 优点：闭包可以缓存数据，延长作用域链。

 \* 缺点：一旦用了闭包，局部变量就不能被及时的释放，会造成对象一直占用内存空间

《JavaScript高级编程》书中建议：由于闭包会携带包含它的函数的作用域，因为会比其他函数占用更多内容，过度使用闭包，会导致内存占用过多。

### 如何修改函数的this指向，这些方法之间有什么区别？

https://www.cnblogs.com/echolun/p/11962610.html

![1213309-20191130222018574-765662402](Z:\xuchaobo\work\第四阶段\React\资料\md文档\第15周React实战\image\1213309-20191130222018574-765662402.png)

#### this默认绑定

this默认绑定我们可以理解为函数调用时无任何调用前缀的情景，它无法应对我们后面要介绍的另外四种情况，所以称之为默认绑定，默认绑定时this指向全局对象（非严格模式）

```js
function fn1() {
    let fn2 = function () {
        console.log(this); //window
        fn3();
    };
    console.log(this); //window
    fn2();
};

function fn3() {
    console.log(this); //window
};

fn1();
```

这个例子中无论函数声明在哪，在哪调用，由于函数调用时前面并未指定任何对象，这种情况下this指向全局对象window。

但需要注意的是，在严格模式环境中，默认绑定的this指向undefined

#### this的隐式绑定

什么是隐式绑定呢，如果函数调用时，前面存在调用它的对象，那么this就会隐式绑定到这个对象上

```
function fn() {
    console.log(this.name);
};
let obj = {
    name: '听风是风',
    func: fn
};
obj.func() //听风是风
```

如果函数调用前存在多个对象，this指向距离调用自己最近的对象

```js
function fn() {
    console.log(this.name);
};
let obj = {
    name: '行星飞行',
    func: fn,
};
let obj1 = {
    name: '听风是风',
    o: obj
};
obj1.o.func() //行星飞行
```

#### 显示绑定this

显式绑定是指我们通过call、apply以及bind方法改变this的行为，相比隐式绑定，我们能清楚的感知 this 指向变化过程

```js
let obj1 = {
    name: '听风是风'
};
let obj2 = {
    name: '时间跳跃'
};
let obj3 = {
    name: 'echo'
}
var name = '行星飞行';

function fn() {
    console.log(this.name);
};
fn(); //行星飞行
fn.call(obj1); //听风是风
fn.apply(obj2); //时间跳跃
fn.bind(obj3)(); //echo
```

在js中，当我们调用一个函数时，我们习惯称之为函数调用，函数处于一个被动的状态；而call与apply让函数从被动变主动，函数能主动选择自己的上下文，所以这种写法我们又称之为函数应用

#### new创建对象

```
function Fn(){
    this.name = '听风是风';
};
let echo = new Fn();
echo.name//听风是风
```

在上方代码中，构造调用创建了一个新对象echo，而在函数体内，this将指向新对象echo上（可以抽象理解为新对象就是this）。

#### this绑定的优先级

我们先介绍前四种this绑定规则，那么问题来了，如果一个函数调用存在多种绑定方法，this最终指向谁呢？这里我们直接先上答案，this绑定优先级为c

> 显式绑定 > 隐式绑定 > 默认绑定

>  new绑定 > 隐式绑定 > 默认绑定

```js
//new>隐式
obj = {
    name: '时间跳跃',
    fn: function () {
        this.name = '听风是风';
    }
};
let echo = new obj.fn();
echo.name;//听风是风

//显式>隐式
let obj = {
    name:'行星飞行',
    fn:function () {
        console.log(this.name);
    }
};
obj1 = {
    name:'时间跳跃'
};
obj.fn.call(obj1);// 时间跳跃
```

#### 箭头函数this

ES6的箭头函数是另类的存在，为什么要单独说呢，这是因为箭头函数中的this不适用上面介绍的四种绑定规则。

箭头函数的this指向取决于外层作用域中的this，外层作用域或函数的this指向谁，箭头函数中的this便指向谁。有点吃软饭的嫌疑，一点都不硬朗

```js
function fn() {
    return () => {
        console.log(this.name);
    };
}
let obj1 = {
    name: '听风是风'
};
let obj2 = {
    name: '时间跳跃'
};
let bar = fn.call(obj1); // fn this指向obj1
bar.call(obj2); //听风是风
```

### 事件委托或者事件代理的原理是什么？

事件委托（事件代理）原理：简单的说就是将事件交由别人来执行，就是将子元素的事件通过冒泡的形式交由父元素来执行。

-在JavaScript中，添加到页面上的事件处理程序数量将直接关系到页面的整体运行性能，因为需要不断的与dom节点进行交互，访问dom的次数越多，引起浏览器重绘与重排的次数也就越多，就会延长整个页面的交互就绪时间

比如我们有100个li，每个li都有相同的click点击事件，可能我们会用for循环的方法，来遍历所有的li，然后给它们添加事件

如果用事件委托，就会将所有的操作放到js程序里面，与dom的操作就只需要交互一次，这样就能大大的减少与dom的交互次数，提高性能

Event对象提供了一个属性叫target，可以返回事件的目标节点，我们成为事件源，也就是说，target就可以表示为当前的事件操作的dom，但是不是真正操作dom

```html
<ul id="oul">
    <li>蜗牛</li>
    <li>凡云</li>
    <li>马特里卡</li>
</ul>
<script>
    const oul = document.getElementById("oul")
    oul.onclick = function(e){
        console.log(e.target.innerHTML);
    }
</script>
```

### 事件冒泡和事件捕获的区别是什么？

