## 一.账户分页实现

### 1.列表实现

1.在src/apis/users.js中定义查询账户的列表api

```js
import axios from 'axios';
axios.defaults.baseURL="http://jacklv.cn";
//获取账户列表信息
export const getAccountListApi=(params={pageNumber:1,pageSize:10})=>axios.post('/users/getAccountList',params);
```

2.在Accounts.js中componentDidMount()方法中调用查询账户列表的方法

```js
state={
        data:[]
}
componentDidMount() {
    this.getAccountList();
}
getAccountList=async(params={pageNumber:1,pageSize:10})=>{
    this.setState({loading:true});
    const {data,pageSize,pageNumber,totalCount}=await getAccountListApi(params);
    console.log('data',data);
    this.setState({data});
}
```

3.在render(）渲染方法中显示列表

```js
 render() { 
        const {data}=this.state;
        const columns = [
            {
                title: '账号',
                dataIndex: 'account'
            },
            {
                title: '角色',
                dataIndex: 'userGroup'
            },
            {
                title: '创建时间',
                dataIndex: 'createDate',
                render:(text)=>{
                    return moment(text).format('YYYY-MM-DD HH:mm:ss');
                }
            },
            {
                title: '操作',
                render: (text, record) => (
                    <Button type="primary">删除</Button>
                ),
            },
        ];
        return (
           
            <div>
                <Table columns={columns} dataSource={data}></Table>
            </div>
        )
    }
```

### 2.实现分页显示功能

1) 在state中定义total

```js
 state={
        data:[],
        total:0
}
```

2 ) 在getAccountList中更新state中的total状态值

```js
getAccountList=async(params={pageNumber:1,pageSize:10})=>{
        this.setState({loading:true});
        const {data,pageSize,pageNumber,totalCount}=await getAccountListApi(params);
        console.log('data',data);
        this.setState({data,total:totalCount});
 }
```

3）在render()中引入total

```js
 const {data,total}=this.state;
```

4）定义pagination对象，然后在<Table>标签中给pagination赋值

```js
const pagination={
       total:total,
       onChange:this.onChange
 }
return (
      <div>
          <Table pagination={pagination} 
                 columns={columns} 
                 dataSource={data}>
           </Table>
       </div>
)
```

### 3.实现点击分页按钮跳转功能

1）在pagination对象中添加onChange属性，该属性用于实现页码改变的回调，参数是改变后的页码及每页条数 

```js
const pagination={
      total:total,
      onChange:this.onChange
}
```

2）定义onChange函数,并在该方法中实现请求查询账户列表功能

```js
onChange=(pageNumber,pageSize)=>{
    this.getAccountList({pageNumber,pageSize});
}
```

### 4.实现loading加载功能

1）在state内部状态中定义loading属性

```js
state={
        data:[],
        total:0,
        loading:false
}
```

2）在getAccountList函数中使用this.setState()更新loading的状态值

分为两步

第一步：在发送请求之前将loading的装填设置为true,这样的效果就是让loading效果出现

第二步：正完成请求以后，再次将loading的值设置为false,loading旋转效果消失

```js
getAccountList=async(params={pageNumber:1,pageSize:10})=>{
        this.setState({loading:true});
        const {data,pageSize,pageNumber,totalCount}=await getAccountListApi(params);
        console.log('data',data);
        this.setState({data,total:totalCount,loading:false});
    }
```

3）在render()渲染方法中，首先使用解构方式提取出loading的值，如下所示

```js
 render() { 
        const {data,total,loading}=this.state;
 }
```

4）在<Table>标签中引入loading这个属性并赋值

```js
<Table 
     loading={loading}  //再次处加入代码
     pagination={pagination} 
     columns={columns} 
     dataSource={data}>
 </Table>
```

### 5.解决列表的key值问题

如上页面已经正常显示，但是查看控制台的时候，会报如下错误

![1610900785498](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1610900785498.png)

这个问题非常经典，是由于在列表循环的时候，没有加入key属性出现的，那么在antd的Table中专门提供了一个rowKey这个属性来解决该问题，rowKey 表示表格行 key 的取值，那么这里边应该写上列表中元素对象的_id值即可

```js
<Table 
     rowKey="_id"  //再次处加入代码
     loading={loading} 
     pagination={pagination} 
     columns={columns} 
     dataSource={data}>
 </Table>
```

## 二.添加账号

### 1.添加用户账号基本实现

1）首先在Accounts.js页面中添加增加账户按钮

```js
<Button type="primary" onClick={this.showAccountModal}>添加账户</Button>
```

2）定义内部数据,在内部数据中增加isModalVisible属性，用于控制弹框的显示和隐藏，定义spingloading用于显示或隐藏增加时候的旋转效果

```js
 state = {
      data: [],
      total: 0,
      loading: false,
      isModalVisible: false,
      spingloading:false
}
```

3）并在页面中添加Modal弹框组件

```js
 <Modal title="提示"
        visible={isModalVisible}
        onOk={this.handleOk}
        onCancel={this.hidenAccountModal}>
              <Form
                   labelCol={5}
                   name="basic"
                   onFinish={this.onFinish}
                   onFinishFailed={this.onFinishFailed}
                   initialValues={{ userGroup: '普通管理员' }}
                   ref={c => this.formInstance = c}
               >
                    <Form.Item
                       label="账户"
                       name="account"
                       rules={[{ required: true, message: '请输入账户!' }]}
                     >
                         <Input />
                    </Form.Item>

                    <Form.Item
                         label="密码"
                         name="password"
                         rules={[{ required: true, message: '请输入密码!' }]}
                    >
                         <Input.Password />
                    </Form.Item>
                    <Form.Item name="userGroup" label="角色" 
                          rules={[{ required: true }]}>
                        <Select
                            placeholder="请选择角色"
                        >
                              <Option value="超级管理员">超级管理员</Option>
                              <Option value="普通管理员">普通管理员</Option>
                        </Select>
                    </Form.Item>
                 </Form>
          </Spin>
  </Modal>
```

2）showAccountModal方法中,当点击按钮，显示弹框

```js
 showAccountModal = () => {
     this.setState({ isModalVisible: true });
 }
```

3）点击弹框的确认按钮，提交表单信息

```js
//点击确认按钮
handleOk = () => {
    this.formInstance.submit();
}
```

如上使用的是FormInstance表单实例中submit()方法来实现提交表单，与点击表单中对象中的submit按钮效果同样的功能，此时就交给了Form组件中的onFinish或onFinishFailed来实现

首先先在apis/users.js中添加增加账号的api方法

```js
import axios from 'axios';
axios.defaults.baseURL="http://jacklv.cn";
//增加账户的操作
export const addAccountApi=(params)=>axios.post('/users/addOrEditAccount',params);
```

然后再在onFinish中调用

```js
//完成表单提交
onFinish = async (values) => {
    console.log('values', values);
    this.setState({spingloading:true});
    const data = await addAccountApi(values);
    this.setState({spingloading:false});
    //隐藏窗口显示
    this.hidenAccountModal();
    //刷新列表
    this.getAccountList();
}
//提交表单失败的回调
onFinishFailed = () => {

}
```

### 2.拆分组件

如上的操作Account.js组件中的内容太多太混乱了，下来我们将弹框拆分一个新的组件

Accounts.js

```js
import React, { Component } from 'react'
import { Table, Button} from 'antd';
import { getAccountListApi, delAccountApi} from '../../apis/users';
import moment from 'moment';
import AddModal from './components/AddModal'

export default class Accounts extends Component {
    state = {
        data: [],
        total: 0,
        loading: false,
        isModalVisible: false
    }
    componentDidMount() {
        this.getAccountList();
    }
    getAccountList = async (params = { pageNumber: 1, pageSize: 10 }) => {
        this.setState({ loading: true });
        const { data, pageSize, pageNumber, totalCount }
                       = await getAccountListApi(params);
        console.log('data', data);
        this.setState({ data, total: totalCount, loading: false });
    }
    onChange = (pageNumber, pageSize) => {
        this.getAccountList({ pageNumber, pageSize });
    }
    //显示弹框
    showAccountModal = () => {
        this.setState({ isModalVisible: true });
    }
   
    //单击取消按钮
    hidenAccountModal = () => {
        this.setState({ isModalVisible: false });
    }
    
   
    render() {
        const { data, total, loading, isModalVisible} = this.state;
        const columns = [
            {
                title: '账号',
                dataIndex: 'account'
            },
            {
                title: '角色',
                dataIndex: 'userGroup'
            },
            {
                title: '创建时间',
                dataIndex: 'createDate',
                render: (text) => {
                    return moment(text).format('YYYY-MM-DD HH:mm:ss');
                }
            },
            {
                title: '操作',
                render: (text, record) => (
                    <Button type="primary" onClick={() => 
                             this.deleteAccountOper(record)}>删除</Button>
                ),
            },
        ];
        const pagination = {
            total: total,
            onChange: this.onChange
        }
        return (

            <div>
                <Button type="primary" onClick={this.showAccountModal}>添加账户</Button>
                <Table rowKey="_id" 
                       loading={loading} 
          			   pagination={pagination} 
                       columns={columns} 
         			   dataSource={data}></Table>
                <AddModal 
                    isModalVisible={isModalVisible} 
                    hidenAccountModal={this.hidenAccountModal}
                    afterOk={this.getAccountList}></AddModal>
            </div>
        )
    }
}
```

AddModal.js

```js
import React, { Component } from 'react';
import {Modal, Form, Input, Select, Spin } from 'antd';
import {addAccountApi } from '../../../apis/users';
import MyPropTypes from 'prop-types';
const Option = Select.Option;


export default class AddModal extends Component {
   
    static defaultProps={
        isModalVisible:false,
        hidenAccountModal:()=>{},
        afterOk:()=>{}
    }
    static propTypes={
        isModalVisible:MyPropTypes.bool,
        hidenAccountModal:MyPropTypes.func,
        afterOk:MyPropTypes.func
    }
    state={
        spingloading:false
    }
    //完成表单提交
    onFinish = async (values) => {
        console.log('values', values);
        this.setState({spingloading:true});
        const data = await addAccountApi(values);
        this.setState({spingloading:false});
        //隐藏窗口显示
        this.props.hidenAccountModal();
        //刷新列表
        this.props.afterOk();
    }
    //提交表单失败的回调
    onFinishFailed = () => {

    }
     //点击确认按钮
     handleOk = () => {
        this.formInstance.submit();
    }
    render() {
        const {isModalVisible,hidenAccountModal}=this.props;
        const {spingloading}=this.state;
        return (
            <Modal title="提示"
                visible={isModalVisible}
                onOk={this.handleOk}
                onCancel={hidenAccountModal}>
                <Spin spinning={spingloading}>
                    <Form
                        labelCol={5}
                        name="basic"
                        onFinish={this.onFinish}
                        onFinishFailed={this.onFinishFailed}
                        initialValues={{ userGroup: '普通管理员' }}
                        ref={c => this.formInstance = c}
                    >
                        <Form.Item
                            label="账户"
                            name="account"
                            rules={[{ required: true, message: '请输入账户!' }]}
                        >
                            <Input />
                        </Form.Item>

                        <Form.Item
                            label="密码"
                            name="password"
                            rules={[{ required: true, message: '请输入密码!' }]}
                        >
                            <Input.Password />
                        </Form.Item>
                        <Form.Item name="userGroup" 
                              label="角色" rules={[{ required: true }]}>
                            <Select
                                placeholder="请选择角色"
                            >
                                <Option value="超级管理员">超级管理员</Option>
                                <Option value="普通管理员">普通管理员</Option>
                            </Select>
                        </Form.Item>
                    </Form>
                </Spin>
            </Modal>
        )
    }
}
```



## 三.国际化配置

在index.js页面中配置

```js
import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import './apis/interceptor'
import {ConfigProvider } from 'antd'  #引入ConfigProvider
import zhCN from 'antd/lib/locale/zh_CN'; #引入zhCN

ReactDOM.render(
  <ConfigProvider locale={zhCN}>    #使用<ConfigProvider>包裹<App/>
    <App />
  </ConfigProvider>
   ,
  document.getElementById('root')
);
```

## 四.删除账号

1.在apis/users.js中添加删除的api方法

```js
import axios from 'axios';
axios.defaults.baseURL="http://jacklv.cn";
//删除账号操作
export const delAccountApi=(id)=>axios.delete('/users/delAccount?id='+id);
```

2.修改账号列表中的“操作“项,添加气泡确认框

```js
  render() {
        const columns = [
            {
                title: '账号',
                dataIndex: 'account'
            },
            {
                title: '角色',
                dataIndex: 'userGroup'
            },
            {
                title: '创建时间',
                dataIndex: 'createDate',
                render: (text) => {
                    return moment(text).format('YYYY-MM-DD HH:mm:ss');
                }
            },
            {
                title: '操作',
                render: (text, record) => (
                    <Popconfirm                
                        title="您确定要删除吗?"
                        onConfirm={()=>this.deleteAccount(record)}
                        onCancel={this.delCancel}
                    >
                    <Button type="primary">删除</Button>
                    </Popconfirm>
                ),
            },
        ];
```

3.编写删除方法

```js
deleteAccount = async (record) => {
    const result = await delAccountApi(record._id);
    console.log('result', result)
    //刷新页面
    this.getAccountList();
}
delCancel=()=>{

}
```































