## cReact框架实战-04脚手架搭建

脚手架: 用来帮助程序员快速创建一个基于库的模板项目

1.  包含了所有需要的配置

2.  指定好了所有的依赖

3.  可以直接安装/编译/运行一个简单效果

react提供了一个用于创建react项目的脚手架库: create-react-app

1. 项目的整体技术架构为:  react + webpack + es6 + eslint

2. 使用脚手架开发的项目的特点: 模块化, 组件化, 工程化

### create-react-app

搭建react脚手架有几种方式，接下来就给大家介绍一下各种方式：

1. 全局安装脚手架工具

    ```bash
    //全局安装脚手架工具
    npm install -g create-react-app
    //使用脚手架工具创建项目
    create-react-app reactdemo
    ```

    使用全局安装的方式来创建脚手架工具，这种方式一旦使用，那后续就可以使用本地的脚手架来创建项目。但是需要注意，脚手架工具一旦更新后，全局安装的工具需要自己更新一下

2. npx临时安装脚手架

    ```bash
    npx create-react-app reactdemo
    ```

    使用npx来创建脚手架工具，会临时在创建`create-react-app工具`,当项目创建完毕后，会立即删除`create-react-app`工具,这种方式创建项目可能会慢一些，但是你能保证你使用的是最新的脚手架工具来创建项目

3. yarn包管理安装脚手架

    ```bash
    yarn xxx
    ```

使用脚手架创建完我们的项目后，我们会看到如下的一些信息。

```bash
  npm start
    Starts the development server.

  npm run build
    Bundles the app into static files for production.

  npm test
  
    Starts the test runner.

  npm run eject
    Removes this tool and copies build dependencies, configuration files
    and scripts into the app directory. If you do this, you can’t go back!

We suggest that you begin by typing:

  cd react02-cli
  npm start
```

- npm start :启动项目的命令，在项目package.json文件中配置的信息
- npm run build：完成项目的构建和打包
- npm test：测试当前项目
- npm run eject：在react中`react-scripts `是 `create-react-app` 的一个核心包，一些脚本和工具的默认配置都集成在里面，比如webpack配置文件，babel的配置文件等等信息。eject 命令执行后会将封装在 `create-react-app `中的配置全部反编译到当前项目，这样用户就能完全取得 webpack 文件的控制权。

接下来我们将项目导入到vscode中使用，目录结果如下图所示：

![image-20200908232941406](https://woniumd.oss-cn-hangzhou.aliyuncs.com/web/xuchaobo/20210808152424.png)



- node_modules:项目依赖包的文件夹
- public：存放静态资源文件的目录
    - index.html：当前项目默认模板文件
- src：源代码的存放位置
    - index.js：项目的入口文件
    - app.js：项目的跟组件，相当于vue中的app.vue 文件
- .gitignore：git提交的时候，配置需要忽略的文件