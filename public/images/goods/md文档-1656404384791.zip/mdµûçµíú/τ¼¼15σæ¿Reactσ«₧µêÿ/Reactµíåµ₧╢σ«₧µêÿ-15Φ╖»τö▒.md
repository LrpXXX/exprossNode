## 一.路由配置

### 路由的基本概念

在开发中如果你接触到node或者vue那肯定听到过路由的概念，如果对这个概念理解不够本节就继续给大家讲解路由的概念，以及react中路由的配置和使用。

​	路由器在生活中经常出现，路由器的功能用一句话概括就是：数据从一个网络到另一个网络就是靠路由来完成的[当然路由器的功能不仅仅于此。

​	我们说的程序开发中的路由不是指路由器和网络协议中的路由，但是基本思想是一样的。而路由又可以分为前端路由和后端路由。

​	接下来我们用一个流程图来给大家介绍路由的概念：

![image-20201019144011387](https://woniumd.oss-cn-hangzhou.aliyuncs.com/web/xuchaobo/20210809231121.png)



### 后端路由

​		在学习nodejs开发的时候我们就自己封装过路由，将不同的资源和不同的访问地址对应起来，通过路由来进行分发。比如我们的访问地址为：

```js
http://example:com/index.html
http://example:com/details/show.html
http://example:com/login
```

 当我们访问http://example:com/index.html地址的时候，服务器根据这个地址将请求分发给对应的程序来处理。

```js
router.get('/', function(req, res, next) {
    console.log("主页", req.session);
    res.render('index', { title: 'Express' });
});

router.post('/login', function (req, res, next) {
  const obj = req.body;
  res.send({success:isLogin,msg:"登录成功"});
});
```

不同的请求地址对应不同的路由解析。

### 前端路由

前端路由和后端路由的实现原理是差不过，实现技术上有一些差别，H5 的 history Api 之前，前端的路由功能都是使用通过 hash「散列值得」 来实现的。 hash　能兼容低版本的浏览器。比如：

```js
http://example:com/#/index.html
http://example:com/#/web/show.html
http://example:com/#/java.html
```

由于 web 服务不会解析 # 后面的东西，可是 js 是可以拿到 # 后面的东西的，有一个方法就是 window.location.hash 来读取，通过这个方法来匹配不同的功能上。

```js
浏览器访问地址：
http://example:com/#/home
js代码解析
window.location.hash  ----> #home
```

通过hash获取到的就是#后面的访问路径。这个hash只会和浏览器进行交互，不会发送给服务器。

接下来我们通过hash的方式来自己设计一个路由。

```js
<h3>自定义路由测试</h3>
<nav>
    <ul>
    <li><a href="#hash1">#hash1</a></li>
    <li><a href="#hash2">#hash2</a></li>
    <li><a href="#hash3">#hash3</a></li>
    <li><a href="#hash4">#hash4</a></li>
</ul>
</nav>
<div id="myhash" style="color:blue">
	显示hash的地方
</div>
```

页面布局设计，我们有4个超链接，点击过后分别跳转不同的地址。

```js
<script type="text/javascript">
    window.addEventListener("hashchange", function() {
        //变化后输出当前地址栏中的值
        document.getElementById("myhash").innerHTML = location.hash;
        console.log(window.location.hash);
    });
</script>
```

我们给window对象绑定了一个hashchange事件，只要页面里面的值发生变化我们就可以获取到hash值显示到容器里面。

自己来完成一个导航路由的切换

1. 定义导航的样式

    ```js
    <div id="nav">
    <ul>
        <li><a href="#/index.html">首页</a></li>
        <li><a href="#/server">服务</a></li>
        <li><a href="#/mine">我的</a></li>
    </ul>
    </div>
    <div id="result"></div>
    ```

    在上面的路由里面，每个超链接的href就要跳转的地址。

2. 封装路由对象，完成函数的设计

    ```js
    //自定义一个路由规则
    function CustomRouter() {
        this.routes = {};
        this.curUrl = '';
    
        this.route = function(path, callback) {
        	this.routes[path] = callback || function() {};
        };
    
        this.refresh = function() {
        this.curUrl = location.hash.slice(1) || '/';
            if (this.curUrl.indexOf('/') != -1) { //这里粗略的把 hash 过滤掉
            	this.routes[this.curUrl]();
            }
        };
    
        this.init = function() {
            window.addEventListener('load', this.refresh.bind(this), false);
            window.addEventListener('hashchange', this.refresh.bind(this), false);
        }
    }
    ```

    在CustomRouter对象中，我们定义了route函数用于匹配访问路径和函数，后续要设置路由那我们就可以调用route将访问的路由和执行的函数绑定在一起。

3. 实现路由的切换

    ```js
    //使用路由规则
    var R = new CustomRouter();
    R.init();
    var res = document.getElementById('result');
    R.route('/index.html', function() {
        res.style.height = '150px';
        res.style.width = '300px';
        res.style.background = 'green';
        res.innerHTML = '首页';
    });
    R.route('/server', function() {
        res.style.height = '150px';
        res.style.width = '300px';
        res.style.background = 'orange';
        res.innerHTML = '评论';
    });
    R.route('/mine', function() {
        res.style.background = 'red';
        res.style.height = '150px';
        res.style.width = '300px';
        res.innerHTML = '更多服务';
    });
    ```

    首先创建一个路由对象，调用route方法，将匹配的路径和function传递过去。一旦访问的地址和route里面定义的一致，那就执行function函数完成逻辑处理。

除了上面的hash可以实现路由的跳转和设计，window 的 history也 提供了对浏览器历史记录的访问功能，并且它暴露了一些方法和属性，让你在历史记录中自由的前进和后退，并且在 H5 中还可以操作历史记录中的数据。

常见的方法如下：

```js
void go(optional long delta);
void back();
void forward();
void push()
void replace()
//h5 引进以下两个方法
void pushState(any data, DOMString title, optional DOMString? url = null);
void replaceState(any data, DOMString title, optional DOMString? url = null);
```

history.push 这个方法会向history栈里面添加一条新记录，这个时候用户点击浏览器的回退按钮可以回到之前的路径。

history.replace 跟 history.push 很像，唯一的不同就是，它不会向 history 添加新记录，而是跟它的方法名一样 —— 替换掉当前的 history 记录。

其中pushState可以改变网址(存在跨域限制)而不刷新页面，这个强大的特性后来用到了单页面应用如：vue-router，react-router-dom中。

注意：仅改变网址,网页不会真的跳转,也不会获取到新的内容,本质上网页还停留在原页面!

语法为：

```js
window.history.pushState(data, title, targetURL);
@状态对象：传给目标路由的信息,可为空
@页面标题：目前所有浏览器都不支持,填空字符串即可
@可选url：目标url，不会检查url是否存在，且不能跨域。如不传该项,即给当前url添加data
```

接下来重点说 h5 的 pushState，完全代替 hash 并且更优雅。

1. 先定义布局结构

    ```js
    <ul>
        <li><a onclick="home()">首页</a></li>
        <li><a onclick="about()">关于</a></li>
        <li><a onclick="mine()">我的</a></li>
    </ul>
    <div id="showContent" style="height:250px;width:200px;background:green">home</div>
    ```

    每个超链接就是一个导航，点击后进行模块加载。

2. 路由脚本的设计

    ```js
    function home() {
        history.pushState({
            name: 'home',
            id: 1
            }, null, "?page=home");
        showCard("home");
    }
    
    function about() {
        history.pushState({
            id: 2,
            name: "about"
            }, null, "?page=about");
        showCard("about");
    }
    
    function mine() {
        history.pushState({
            id: 3,
            name: "mine"
            }, null, "?name=chen&age=30");
        showCard("mine");
    }
    
    function showCard(name) {
    	document.getElementById("showContent").innerHTML = name;
    }
    
    //点击返回键盘的时候显示历史
    window.onpopstate = function(event) {
        var content = "";
        if (event.state) {
        	content = event.state.name;
        }
        showCard(content);
    }
    ```

    popstate事件会在点击后退、前进按钮(或调用history.back()、history.forward()、history.go()方法)时触发。当点击每一个链接过后我们执行对应的函数完成逻辑跳转。

    ### react路由

    React 官方没有给出一个明确的组件，推荐使用三方的一个叫 React Router 的组件。「当然我们不使用 React Router 也可以完成路由功能，比如传统的　hash 功能，没有问题，但是用了它就非常方便和好用」。

    ​	 React Router也是一个组件，在代码中引入来完成路由跳转。接下来我们就基于 React Route来完成一个简单的SPA应用。访问地址为:https://reactrouter.com/web/api/Redirect

    1. 先下载路由

        ```js
        npm install react-router-dom
        yarn add react-router-dom
        ```

        以上两种方式都可以在项目中下载路由。

    2. 在项目中引入react-router-dom来完成，打开App.jsx组件

        ```js
        import {Route, Link, BrowserRouter, Switch,Redirect } from 'react-router-dom';
        import Home from "./component/Home"
        import About from "./component/About"
        ```

        在项目中引入react-router-dom，并将需要的组件结构出来。比如Route，Link，BrowserRouter等等，在后续我们会详细给大家介绍这些组件的作用。

    3. 在render方法里面设置路由跳转链接

        ```js
        render(){
                return (
                    <BrowserRouter>
                        <div>
                            <h1>App</h1>
                            <ul>
                                <li><Link to="/home">首页</Link></li>
                                <li><Link to="/about">关于我</Link></li>
                            </ul>
                        </div>
                    </BrowserRouter>
                )
            } 
        ```

        在上面的代码中我们在render方法里面定义了一个BrowserRouter组件，这个一个路由器，必须放在最外面，在路由器里面我们使用Link标签来定义了导航的链接。其实在页面上最终渲染出来的结果就是两个a标签。

        ![image-20201019200819366](https://woniumd.oss-cn-hangzhou.aliyuncs.com/web/xuchaobo/20210809231140.png)

        点击超链接后我们要进行相应的路由跳转，接下来就配置路由匹配组件

        ```js
        <BrowserRouter>
            <div>
                <h1>App</h1>
                <ul>
                    <li><Link to="/home">首页</Link></li>
                    <li><Link to="/about">关于我</Link></li>
                </ul>
            </div>
            <Switch>
                <Redirect exact from="/" to="/home"></Redirect>
                <Route path={"/home"}>
                	<Home/>
              	</Route>
                <Route path={"/about"}>
                	<About/>
                </Route>
            </Switch>
        </BrowserRouter>
        ```

        Switch是路由匹配组件，就类似于js中的switch语句，进行判断，你浏览器访问的地址如何和Route的path属性重叠，那我们就可以进行路由匹配，加载对应的组件。

        其中Redirect组件代表重定向，如果用户第一次访问的路径为/，那就默认定位到/home路径。exact关键字代表精确匹配，这个不能省略，不然你无法匹配到Route。

        ![image-20201019201345391](https://woniumd.oss-cn-hangzhou.aliyuncs.com/web/xuchaobo/20210809231148.png)

        页面加载完毕后，你默认看法哦的访问结果就是/home，这是因为我们有重定向操作。

        案列我们演示完毕后，接下来就要给大家去解析以下我们刚刚用到的组件分别有什么作用，React Router中的组件主要分为三类：

        1. 路由器，例如<BrowserRouter>和<HashRouter>
        2. 路由匹配器，例如<Route>和<Switch>
        3. 导航，例如<Link>，<NavLink>和<Redirect>

        

    #### 路由器

    ​		每个React Router应用程序的核心应该是路由器组件。对于Web项目，react-router-dom提供<BrowserRouter>和<HashRouter>路由器。两者之间的主要区别在于它们存储URL和与Web服务器通信的方式。我们来列举以下区别：

    - <BrowserRouter>使用常规URL路径。 这些通常是外观最好的网址，但它们要求您的服务器配置正确。 具体来说，您的Web服务器需要在所有由React Router客户端管理的URL上提供相同的页面。Create React App在开发中即开即用地支持此功能，并附带有关如何配置生产服务器的说明。
    - <HashRouter>将当前位置存储在URL的哈希部分中，因此URL看起来类似于http://example.com/#/your/page。 由于哈希从不发送到服务器，因此这意味着不需要特殊的服务器配置。

    要使用路由器，只需确保将其渲染在元素层次结构的根目录下即可，比如我们上面的案列中，在App.jsx组件里面我们先加载了BrowserRouter组件。

    ```js
    <BrowserRouter>
        <Switch>
            <Redirect exact from="/" to="/home"></Redirect>
            <Route path={"/home"}>
            	<Home/>
          	</Route>
            <Route path={"/about"}>
            	<About/>
            </Route>
        </Switch>
    </BrowserRouter>
    ```

    也就说你要使用Switch，Route这些组件，那就必须在外面包含BrowserRouter路由器。

    当然我们也可以使用HashRouter来实现路由跳转

    ```js
    render() {
            return (
                <div>
                    <HashRouter>
                        <ul>
                            <li><Link to="/home">首页</Link></li>
                            <li><Link to="/about">关于我</Link></li>
                        </ul>
                        <Switch>
                            <Route path="/home" component={Home}></Route>
                            <Route path="/about" component={About}></Route>
                        </Switch>
                    </HashRouter>
                </div>
            )
        }
    ```

    使用了HashRouter来控制路由跳转，在页面上显示的效果如下：

    ![image-20201019202737973](https://woniumd.oss-cn-hangzhou.aliyuncs.com/web/xuchaobo/20210809231157.png)

    在浏览器地址里面，你会发现有#的存在。证明我们的路由就是使用了hash模式。

    #### 路径匹配器

    ​		有两个路径匹配组件：Switch和Route。渲染<Switch>时，它会搜索其子元素<Route>，以查找其路径与当前URL匹配的元素。当找到一个时，它将渲染该<Route>并忽略所有其他路由。这意味着您应该将<Route>包含更多特定路径（通常较长）的路径放在不那么特定路径之前。

    ​		如果没有<Route>匹配，则<Switch>不渲染任何内容（null）。

    Switch在匹配的过程中需要注意，一旦匹配成功那就不会在继续匹配后面的路由，比如：

    ```js
    <Switch>
        <Route path="/" component={Home}></Route>
        <Route path="/home" component={Home}></Route>
        <Route path="/about" component={About}></Route>
    </Switch>
    ```

    如果我们的路径为：http://127.0.0.1:3000/about那匹配到的组件永远是Home，因为<Route path="/" >这个路径已经匹配成功，后续就不再匹配。从这个结果中我们也能发现Switch是模糊匹配。如果要精确匹配到指定的路由组件，我们可以如下操作：

    1. 将常的路由放在最前面

        ```js
        <Switch>
            <Route path="/home" component={Home}></Route>
            <Route path="/about" component={About}></Route>
            <Route path="/" component={Home}></Route>
        </Switch>
        ```

        这样就能先匹配/home在匹配/about最后在匹配/

    2. 当然我们也可以在Route上面加上关键字exact来代表精确匹配

        ```js
        <Switch>
        	<Route exact path="/" component={Home}></Route>
            <Route path="/home" component={Home}></Route>
            <Route path="/about" component={About}></Route>
        </Switch>
        ```

        以上就是我们的Switch匹配规则。

    对于Route来说，我们使用他来匹配我们想要的路径，要渲染的组件可以有两种方式

    ```js
    方式一：
    <Route exact path="/" component={Home}></Route>
    方式二：
    <Route exact path="/" >
    	<Home/>
    </Route>
    ```

    两种方式都可以加载组件。

    #### 导航

    React Router提供了一个<Link>组件来在您的应用程序中创建链接。 无论在何处渲染<Link>，锚点都将渲染在HTML文档中。

    <NavLink>是<Link>的一种特殊类型，当其prop与当前位置匹配时，可以将其自身设置为“active”。最终导航都被渲染为超链接；

    我们在代码中使用NavLink来设置导航，并添加默认样式：

    ```js
    <HashRouter>
        <ul>
            <li><NavLink to="/home" activeClassName="hurray">React</NavLink></li>
            <li><NavLink to="/about" activeClassName="hurray">关于我</NavLink></li>
        </ul>
        <Switch>
            <Route exact path="/" component={Home}></Route>
            <Route path="/home" component={Home}></Route>
            <Route path="/about" component={About}></Route>
        </Switch>
    </HashRouter>
    ```

    NavLink提供了一个activeClassName属性，对应的值是一个字符串，这是一个class选择器，你可以自己添加样式

    ```css
    .hurray {
        color: red;
    }
    ```

    带来的效果就是你被选中的导航默认会显示为红色，点击切换颜色也会变化。

    <Redirect>组件就是设置重定向的组件,你可以指定一个匹配路径,在定义一个要默认跳转的路径.

    ```js
    <Redirect exact from="/" to="/home"></Redirect>
    ```

    代表如果请求路径是/那就默认跳转到/home路径.

    当然我们在代码中,如果要设置代码跳转,除了使用Link或者NavLink以外,我们还可以自定义脚本来实现.

    ```js
    import {withRouter,BrowserRouter, Switch} from 'react-router-dom' 
    import React from "react"
    
    class WithRouterComp extends React.Component{ 
        forward = ()=>{ 
            //经过widthRouter包装之后，该组件就具有了history属性 
            // this.props.history.push('/login');
            console.log(this.props);
        }
        render(){ 
            return(
                <div> 
                    <button onClick={this.forward}>点我跳转到登录</button>
                </div> 
            )
        } 
    }
            
    export default WithRouterComp
    
    ```

    高阶组件中的withRouter, 作用是将一个组件包裹进Route里面, 然后react-router的三个对象history, location, match就会被放进这个组件的props属性中.

    基本的实现原理如下:

    ```js
    // withRouter实现原理: 
    // 将组件包裹进 Route, 然后返回
    // const withRouter = () => {
    //     return () => {
    //         return <Route component={Nav} />
    //     }
    // }
     
    // 这里是简化版
    const withRouter = ( Component ) => () => <Route component={ Component }/>
    ```

    我们可以在react中使用button,span等等标签来进行跳转.

### react路由

React 官方没有给出一个明确的组件，推荐使用三方的一个叫 React Router 的组件。「当然我们不使用 React Router 也可以完成路由功能，比如传统的　hash 功能，没有问题，但是用了它就非常方便和好用」。

​	 React Router也是一个组件，在代码中引入来完成路由跳转。接下来我们就基于 React Route来完成一个简单的SPA应用。访问地址为:https://reactrouter.com/web/api/Redirect

1. 先下载路由

    ```js
    npm install react-router-dom
    yarn add react-router-dom
    ```

    以上两种方式都可以在项目中下载路由。

2. 在项目中引入react-router-dom来完成，打开App.jsx组件

    ```js
    import {Route, Link, BrowserRouter, Switch,Redirect } from 'react-router-dom';
    import Home from "./component/Home"
    import About from "./component/About"
    ```

    在项目中引入react-router-dom，并将需要的组件结构出来。比如Route，Link，BrowserRouter等等，在后续我们会详细给大家介绍这些组件的作用。

3. 在render方法里面设置路由跳转链接

    ```js
    render(){
            return (
                <BrowserRouter>
                    <div>
                        <h1>App</h1>
                        <ul>
                            <li><Link to="/home">首页</Link></li>
                            <li><Link to="/about">关于我</Link></li>
                        </ul>
                    </div>
                </BrowserRouter>
            )
        } 
    ```

    在上面的代码中我们在render方法里面定义了一个BrowserRouter组件，这个一个路由器，必须放在最外面，在路由器里面我们使用Link标签来定义了导航的链接。其实在页面上最终渲染出来的结果就是两个a标签。

    ![image-20201019200819366](https://woniumd.oss-cn-hangzhou.aliyuncs.com/web/xuchaobo/20210809231209.png)

    点击超链接后我们要进行相应的路由跳转，接下来就配置路由匹配组件

    ```js
    <BrowserRouter>
        <div>
            <h1>App</h1>
            <ul>
                <li><Link to="/home">首页</Link></li>
                <li><Link to="/about">关于我</Link></li>
            </ul>
        </div>
        <Switch>
            <Redirect exact from="/" to="/home"></Redirect>
            <Route path={"/home"}>
            	<Home/>
          	</Route>
            <Route path={"/about"}>
            	<About/>
            </Route>
        </Switch>
    </BrowserRouter>
    ```

    Switch是路由匹配组件，就类似于js中的switch语句，进行判断，你浏览器访问的地址如何和Route的path属性重叠，那我们就可以进行路由匹配，加载对应的组件。

    其中Redirect组件代表重定向，如果用户第一次访问的路径为/，那就默认定位到/home路径。exact关键字代表精确匹配，这个不能省略，不然你无法匹配到Route。

    ![image-20201019201345391](https://woniumd.oss-cn-hangzhou.aliyuncs.com/web/xuchaobo/20210809231218.png)

    页面加载完毕后，你默认看法哦的访问结果就是/home，这是因为我们有重定向操作。

    案列我们演示完毕后，接下来就要给大家去解析以下我们刚刚用到的组件分别有什么作用，React Router中的组件主要分为三类：

    1. 路由器，例如<BrowserRouter>和<HashRouter>
    2. 路由匹配器，例如<Route>和<Switch>
    3. 导航，例如<Link>，<NavLink>和<Redirect>

    

#### 路由器

​		每个React Router应用程序的核心应该是路由器组件。对于Web项目，react-router-dom提供<BrowserRouter>和<HashRouter>路由器。两者之间的主要区别在于它们存储URL和与Web服务器通信的方式。我们来列举以下区别：

- <BrowserRouter>使用常规URL路径。 这些通常是外观最好的网址，但它们要求您的服务器配置正确。 具体来说，您的Web服务器需要在所有由React Router客户端管理的URL上提供相同的页面。Create React App在开发中即开即用地支持此功能，并附带有关如何配置生产服务器的说明。
- <HashRouter>将当前位置存储在URL的哈希部分中，因此URL看起来类似于http://example.com/#/your/page。 由于哈希从不发送到服务器，因此这意味着不需要特殊的服务器配置。

要使用路由器，只需确保将其渲染在元素层次结构的根目录下即可，比如我们上面的案列中，在App.jsx组件里面我们先加载了BrowserRouter组件。

```js
<BrowserRouter>
    <Switch>
        <Redirect exact from="/" to="/home"></Redirect>
        <Route path={"/home"}>
        	<Home/>
      	</Route>
        <Route path={"/about"}>
        	<About/>
        </Route>
    </Switch>
</BrowserRouter>
```

也就说你要使用Switch，Route这些组件，那就必须在外面包含BrowserRouter路由器。

当然我们也可以使用HashRouter来实现路由跳转

```js
render() {
        return (
            <div>
                <HashRouter>
                    <ul>
                        <li><Link to="/home">首页</Link></li>
                        <li><Link to="/about">关于我</Link></li>
                    </ul>
                    <Switch>
                        <Route path="/home" component={Home}></Route>
                        <Route path="/about" component={About}></Route>
                    </Switch>
                </HashRouter>
            </div>
        )
    }
```

使用了HashRouter来控制路由跳转，在页面上显示的效果如下：

![image-20201019202737973](https://woniumd.oss-cn-hangzhou.aliyuncs.com/web/xuchaobo/20210809231226.png)

在浏览器地址里面，你会发现有#的存在。证明我们的路由就是使用了hash模式。

#### 路径匹配器

​		有两个路径匹配组件：Switch和Route。渲染<Switch>时，它会搜索其子元素<Route>，以查找其路径与当前URL匹配的元素。当找到一个时，它将渲染该<Route>并忽略所有其他路由。这意味着您应该将<Route>包含更多特定路径（通常较长）的路径放在不那么特定路径之前。

​		如果没有<Route>匹配，则<Switch>不渲染任何内容（null）。

Switch在匹配的过程中需要注意，一旦匹配成功那就不会在继续匹配后面的路由，比如：

```js
<Switch>
    <Route path="/" component={Home}></Route>
    <Route path="/home" component={Home}></Route>
    <Route path="/about" component={About}></Route>
</Switch>
```

如果我们的路径为：http://127.0.0.1:3000/about那匹配到的组件永远是Home，因为<Route path="/" >这个路径已经匹配成功，后续就不再匹配。从这个结果中我们也能发现Switch是模糊匹配。如果要精确匹配到指定的路由组件，我们可以如下操作：

1. 将常的路由放在最前面

    ```js
    <Switch>
        <Route path="/home" component={Home}></Route>
        <Route path="/about" component={About}></Route>
        <Route path="/" component={Home}></Route>
    </Switch>
    ```

    这样就能先匹配/home在匹配/about最后在匹配/

2. 当然我们也可以在Route上面加上关键字exact来代表精确匹配

    ```js
    <Switch>
    	<Route exact path="/" component={Home}></Route>
        <Route path="/home" component={Home}></Route>
        <Route path="/about" component={About}></Route>
    </Switch>
    ```

    以上就是我们的Switch匹配规则。

对于Route来说，我们使用他来匹配我们想要的路径，要渲染的组件可以有两种方式

```js
方式一：
<Route exact path="/" component={Home}></Route>
方式二：
<Route exact path="/" >
	<Home/>
</Route>
```

两种方式都可以加载组件。

#### 导航

React Router提供了一个<Link>组件来在您的应用程序中创建链接。 无论在何处渲染<Link>，锚点都将渲染在HTML文档中。

<NavLink>是<Link>的一种特殊类型，当其prop与当前位置匹配时，可以将其自身设置为“active”。最终导航都被渲染为超链接；

我们在代码中使用NavLink来设置导航，并添加默认样式：

```js
<HashRouter>
    <ul>
        <li><NavLink to="/home" activeClassName="hurray">React</NavLink></li>
        <li><NavLink to="/about" activeClassName="hurray">关于我</NavLink></li>
    </ul>
    <Switch>
        <Route exact path="/" component={Home}></Route>
        <Route path="/home" component={Home}></Route>
        <Route path="/about" component={About}></Route>
    </Switch>
</HashRouter>
```

NavLink提供了一个activeClassName属性，对应的值是一个字符串，这是一个class选择器，你可以自己添加样式

```css
.hurray {
    color: red;
}
```

带来的效果就是你被选中的导航默认会显示为红色，点击切换颜色也会变化。

<Redirect>组件就是设置重定向的组件,你可以指定一个匹配路径,在定义一个要默认跳转的路径.

```js
<Redirect exact from="/" to="/home"></Redirect>
```

代表如果请求路径是/那就默认跳转到/home路径.

当然我们在代码中,如果要设置代码跳转,除了使用Link或者NavLink以外,我们还可以自定义脚本来实现.

```js
import {withRouter,BrowserRouter, Switch} from 'react-router-dom' 
import React from "react"

class WithRouterComp extends React.Component{ 
    forward = ()=>{ 
        //经过widthRouter包装之后，该组件就具有了history属性 
        // this.props.history.push('/login');
        console.log(this.props);
    }
    render(){ 
        return(
            <div> 
                <button onClick={this.forward}>点我跳转到登录</button>
            </div> 
        )
    } 
}
        
export default WithRouterComp

```

高阶组件中的withRouter, 作用是将一个组件包裹进Route里面, 然后react-router的三个对象history, location, match就会被放进这个组件的props属性中.

基本的实现原理如下:

```js
// withRouter实现原理: 
// 将组件包裹进 Route, 然后返回
// const withRouter = () => {
//     return () => {
//         return <Route component={Nav} />
//     }
// }
 
// 这里是简化版
const withRouter = ( Component ) => () => <Route component={ Component }/>
```

我们可以在react中使用button,span等等标签来进行跳转.

>对于路由跳转，我们在配置路由的时候需要采用<Route path="/home" component={Home}>的方式来进行跳转

如果你在配置路由的时候，组件采用下面这种方式来进行加载，js跳转会报错

```jsx
Route path={"/login"}>
    <Login></Login>
</Route>
```

### 3.路由跳转

#### 3.1 通过Link组件跳转

如上只是进行了路由的配置，如果要进行路由跳转可以通过<Link>标签的方式进行跳转

```jsx
import React, { Component } from 'react'
import {Link} from 'react-router-dom'

export default class Login extends Component {
    render() {
        return (
            <div>
                <Link to='/home'>跳转到首页</Link>
                <div>
                    登录
                </div>
            </div>
        )
    }
}
```

#### 3.2.通过js跳转

除了使用Link跳转外,我们还可以自定义脚本来实现.

```jsx
import React, { Component } from 'react'

export default class Login extends Component {
    goHome=()=>{
        this.props.history.push('/home');
    }
    render() {
        return (
            <div>
                <button onClick={this.goHome}>跳转到首页</button>
                <div>
                    登录
                </div>
            </div>
        )
    }
}
```

下面我们给Login.js添加一个子组件Child.js

```js
import React, { Component } from 'react'

export default class Child extends Component {
    goHomeChild=()=>{
        console.log(this);
        this.props.history.push('/home');   
    }
    render() {
        return (
            <div>
                <div>
                    Child子页面
                </div>
                <button onClick={this.goHomeChild}>child页面中的->跳转到首页</button>
            </div>
        )
    }
}

```

然后这个时候需要在Login.js中引入

```js
import React, { Component } from 'react'
import Child from './Child'

export default class Login extends Component {
    goHome=()=>{
        this.props.history.push('/home');
    }
    render() {
        return (
            <div>
                <button onClick={this.goHome}>跳转到首页</button>
                <div>
                    登录
                </div>
                <Child></Child>
            </div>
        )
    }
}

```

如果我们在Child.js中需要跳转到首页，此时会报错

![1610437878565](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1610437878565.png)

 此时，我们在Child.js的跳转的方法中输出this

```js
goHomeChild=()=>{
        console.log(this);
        //this.props.history.push('/home');   
}
```

![1610437958866](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1610437958866.png)

通过如上控制台输出的效果，我们会发现props中并没有history这个对象，此时如果要想跳转需要在父组件中传递过来

```js
import React, { Component } from 'react'
import Child from './Child'

export default class Login extends Component {
    goHome=()=>{
        this.props.history.push('/home');
    }
    render() {
        return (
            <div>
                <button onClick={this.goHome}>跳转到首页</button>
                <div>
                    登录
                </div>
                <Child {...this.props}></Child>
            </div>
        )
    }
}
```

但这样做是在是很麻烦，我们可以通过高阶组件中的withRouter, 作用是将一个组件包裹进Route里面, 然后react-router的三个对象history, location, match就会被放进这个组件的props属性中,如果不使用withRouter，那么props属性中将没有history,location,match属性的内容。

```js
import React, { Component } from 'react'
import {withRouter} from 'react-router-dom'
class Child extends Component {
    goHomeChild=()=>{
        console.log(this);
        this.props.history.push('/home');   
    }
    render() {
        return (
            <div>
                <div>
                    Child子页面
                </div>
                <button onClick={this.goHomeChild}>child页面中的->跳转到首页</button>
            </div>
        )
    }
}
export default withRouter(Child)
```

这样我们就不需要再在父组件（Login.js）中通过{...this.props}的方式传递到子组件中了

```js
import React, { Component } from 'react'
import Child from './Child'

export default class Login extends Component {
    goHome=()=>{
        this.props.history.push('/home');
    }
    render() {
        return (
            <div>
                <button onClick={this.goHome}>跳转到首页</button>
                <div>
                    登录
                </div>
                <Child></Child>
            </div>
        )
    }
}
```

当你在非路由组件里面要进行js跳转的时候，这个时候就需要用withRoute来对当前路由进行包装。

>总结：
>
>1. 默认情况下必须是经过路由匹配渲染的组件才存在this.props，才拥有路由参数，才能使用编程式导航的写法，执行this.props.history.push('/ ')跳转到对应路由的页面
>2. 高阶组件中的withRouter, 作用是将一个组件包裹进Route里面, 然后react-router的三个对象history, location, match就会被放进这个组件的props属性中.此时这个组件就具备了路由的属性

```jsx
// withRouter实现原理: 
// 将组件包裹进 Route, 然后返回
// const withRouter = (Nav) => {
//     return () => {
//         return <Route component={Nav} />
//     }
// }
 
// 这里是简化版
const withRouter = ( Component ) => () => <Route component={ Component }/>
```

上面代码是withRoute的大概实现原理。

### 4.路由懒加载

有两种方式可以实现路由懒加载

#### 4.1 使用react-loadable插件

这种方式是一种比较旧的方式，不建议使用，不过需要同学们要了解，下面我们来看一下这种方式

1） 下载路由懒加载插件

```bash
npm install react-loadable
或
yarn add react-loadable
```

2) 在配置路由的时候，把我们要用于配置在component属性上面的组件用react-loadable包装一次即可

```jsx
import React, { Component } from 'react'
import {HashRouter,Switch,Route,Redirect} from 'react-router-dom'
import Loadable from 'react-loadable';

const Login=Loadable({
    loader:()=>import('./Login'),
    loading:()=><div>加载中...</div>
});
const Reg=Loadable({
    loader:()=>import('./Reg'),
    loading:()=><div>加载中...</div>
});
const Home=Loadable({
    loader:()=>import('./Home'),
    loading:()=><div>加载中...</div>
});
export default class App extends Component {
    render() {
        return (
            <HashRouter>
                <Switch>
                    <Redirect from='/' to='/login' exact></Redirect>
                    <Route path='/login' component={Login}></Route>
                    <Route path='/reg' component={Reg}></Route>
                    <Route path='/home' component={Home}></Route>
                </Switch>
            </HashRouter>
        )
    }
}
```

#### 4.2 使用react官方推荐的方式

```js
import React, { Component } from 'react'
import {HashRouter,Switch,Route,Redirect} from 'react-router-dom'

class Loading extends Component{
    render(){
        return <div>记载中...</div>
    }
}
export default class App extends Component {
    render() {
        return (
            <React.Suspense fallback={<Loading></Loading>}>
                <HashRouter>
                    <Switch>
                        <Redirect from='/' to='/login' exact></Redirect>
                        <Route path='/login' 
                               component={React.lazy(()=>import('./Login'))}></Route>
                        <Route path='/reg' 
                               component={React.lazy(()=>import('./Reg'))}></Route>
                        <Route path='/home' 
                               component={React.lazy(()=>import('./Home'))}></Route> 
                    </Switch>
                </HashRouter>
            </React.Suspense>
        )
    }
}
```

>react打包的时候默认会将所有要加载的组件打包为chunk.js，如果组件很多的情况下，这个文件加载就非常的慢，所以我们可以使用Loadable来将chunk.js拆分为多个chunk.js文件。

### 5. 路由传参

在进行路由跳转的时候，我们有时候需要传递参数，这个时候可以采用下面的一些方式：

1. params来进行参数传递

    ```js
    <Route path='/path/:name' component={Path}/>
    <link to="/path/2">xxx</Link>
    this.props.history.push({pathname:"/path/" + name});
    读取参数用:this.props.match.params.name
    ```

    优势 ： 刷新地址栏，参数依然存在
    缺点:只能传字符串，并且，如果传的值太多的话，url会变得长而丑陋。

2. query

    ```js
    <Route path='/query' component={Query}/>
    <Link to={{ path : ' /query' , query : { name : 'sunny' }}}>
    this.props.history.push({pathname:"/query",query: { name : 'sunny' }});
    读取参数用: this.props.location.query.name
    ```

    优势：传参优雅，传递参数可传对象；
    缺点：刷新地址栏，参数丢失

3. state

    ```js
    <Route path='/sort ' component={Sort}/>
    <Link to={{ path : ' /sort ' , state : { name : 'sunny' }}}> 
    this.props.history.push({pathname:"/sort ",state : { name : 'sunny' }});
    读取参数用: this.props.location.query.state 
    ```

    优缺点同query

4. search

    ```js
    <Route path='/web/departManange ' component={DepartManange}/>
    <link to="web/departManange?tenantId=12121212">xxx</Link>
    this.props.history.push({pathname:"/web/departManange?tenantId" + row.tenantId});
    读取参数用: this.props.location.search
    ```

    优缺点同params

5. js跳转的时候传递参数

    ```
    
    ```

    

### 5.二级路由

```js
import React, { Component } from 'react'
import {NavLink,Switch,Route,Redirect} from 'react-router-dom'

export default class Home extends Component {
    render() {
        return (
            <div style={{display:'flex'}}>
                <div style={{width:200,height:300,backgroundColor:'yellow'}}>
                    <div>
                        <NavLink to='/home/person' 
                                 activeStyle={{color:'red'}}>人员管理</NavLink>
                    </div>
                    <div>
                        <NavLink to='/home/order' 
                                 activeStyle={{color:'red'}}>订单管理</NavLink>
                    </div>
                </div>
                <div style={{flex:1,backgroundColor:'red'}}>
                    <Switch>
                        <Redirect from='/home' to='/home/person' exact></Redirect>
                        <Route path='/home/person' 
                               component={React.lazy(()=>import('./Person'))}></Route>
                        <Route path='/home/order' 
                               component={React.lazy(()=>import('./Order'))}></Route>
                    </Switch>
                </div>
            </div>
        )
    }
}
```

之前使用Link组件进行跳转，这种组件不能添加样式，我们可以使用NavLink添加样式，NavLink和Link的用法一样，它扩展了Link组件的功能，可以添加样式，使用activeClassName添加外部样式，使用activeStyle添加行内样式

二级路由不需要有<HashRouter>和<React.Suspense>，只需添加<Switch>就可以了

### 6.react插槽

 位于组件标签之间的内容就是插槽内容，要显示插槽内容需要在组件内部通过this.props.children渲染 

```js
import React, { Component } from 'react'
import SlotComp from './SlotComp'

export default class App extends Component {
    render() {
        return (
            <div>
                <SlotComp>A</SlotComp>
                <SlotComp>B</SlotComp>
                <SlotComp>C</SlotComp>
            </div>
        )
    }
}
```

```js
import React, { Component } from 'react'

export default class SlotComp extends Component {
    render() {
        return (
            <div style={{width:250,height:200,borderStyle:'solid',
                        borderWidth:1,borderColor:'gray',position:'relative',margin:10}}>
                <div style={{width:250,height:50,backgroundColor:'red',
                            textAlign:'center',color:'white',}}>头部信息</div>
                <div>
                    {
                      this.props.children
                    }
                </div>
                <div style{{width:250,height:50,backgroundColor:'red',textAlign:'center',
                            color:'white',position:'absolute',bottom:0}}>底部信息</div>
             </div>
        )
    }
}
```



### 面试题

#### js的事件循环

![bg2014100802](/Volumes/[C] windows.hidden/Users/xuchaobo/Desktop/bg2014100802.png)

浏览器内核有多种线程在工作。

- GUI 渲染线程:
  - 负责渲染页面，解析 HTML，CSS 构成 DOM 树等，当页面重绘或者由于某种操作引起回流都会调起该线程。
  - 和 JS 引擎线程是互斥的，当 JS 引擎线程在工作的时候，GUI 渲染线程会被挂起，GUI 更新被放入在 JS 任务队列中，等待 JS 引擎线程空闲的时候继续执行。
- JS 引擎线程:
  - 单线程工作，负责解析运行 JavaScript 脚本。
  - 和 GUI 渲染线程互斥，JS 运行耗时过长就会导致页面阻塞。
- 事件触发线程:
  - 当事件符合触发条件被触发时，该线程会把对应的事件回调函数添加到任务队列的队尾，等待 JS 引擎处理。
- 定时器触发线程:
  - 浏览器定时计数器并不是由 JS 引擎计数的，阻塞会导致计时不准确。
  - 开启定时器触发线程来计时并触发计时，计时完成后会被添加到任务队列中，等待 JS 引擎处理。
- http 请求线程:
  - http 请求的时候会开启一条请求线程。
  - 请求完成有结果了之后，将请求的回调函数添加到任务队列中，等待 JS 引擎处理。



promise和setTimeout区别

回顾JavaScript事件循环并发模型，我们了解了setTimeout和Promise调用的都是异步任务，这一点是它们共同之处，也即都是通过任务队列进行管理／调度。那么它们有什么区别吗？
任务队列
前文已经介绍了任务队列的基础内容和机制，可选择查看，本文对任务队列进行拓展介绍。JavaScript通过任务队列管理所有异步任务，而任务队列还可以细分为

MacroTask Queue和MicoTask Queue两类。 

1. MacroTask Queue MacroTask Queue（宏任务队列）主要包括setTimeout,setInterval, setImmediate,
   requestAnimationFrame, NodeJS中的`I/O等。 MicroTask Queue MicroTask
2. Queue（微任务队列）主要包括两类： 独立回调microTask：如Promise，其成功／失败回调函数相互独立；
   复合回调microTask：如 Object.observe, MutationObserver 和NodeJs中的
   process.nextTick ，不同状态回调在同一函数体； 
3. MacroTask和MicroTask
   JavaScript将异步任务分为MacroTask和MicroTask，那么它们区别何在呢？ 
4. 依次执行同步代码直至执行完毕；
   - 检查MacroTask 队列，若有触发的异步任务，则取第一个并调用其事件处理函数，然后跳至第三步，若没有需处理的异步任务，则直接跳至第三步；
   - 检查MicroTask队列，然后执行所有已触发的异步任务，依次执行事件处理函数，直至执行完毕，然后跳至第二步，若没有需处理的异步任务中，则直接返回第二步，依次执行后续步骤；
     最后返回第二步，继续检查MacroTask队列，依次执行后续步骤； 如此往复，若所有异步任务处理完成，则结束；









