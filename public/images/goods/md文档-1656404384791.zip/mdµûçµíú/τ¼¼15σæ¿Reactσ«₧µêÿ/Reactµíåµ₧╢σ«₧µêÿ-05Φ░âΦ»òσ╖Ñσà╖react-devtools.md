## React框架实战-05调试工具react-devtools

在使用组件开发的时候，我们如果想要在chrome浏览器里面查看组件结构，或者查看组件的数据信息，我们需要安装一个调试工具react-devtools，接下来就列举以下这个工具的安装步骤和使用流程。

1. 打开github获取到插件项目，并现在到本地

    插件的地址为：https://github.com/facebook/react-devtools/tree/v3，从这个地址里面找到DownloadZIP，将项目现在到本地。

    ![image-20201023093727864](https://woniumd.oss-cn-hangzhou.aliyuncs.com/web/xuchaobo/20210808173406.png)

2. 解压项目，并安装依赖。

    下载的zip文件解压到本地的目类里面。接着进入react-devtools-3目录，在控制台使用npm install命令将当前工程的依赖现在到本地。

3. 指定命令打包生成插件

    再进入到react-devtools-3\shells\chrome切换到chrome目录下，运行node build.js，当前目录下会生成build目录 这个build目录下的unpacked目录就是chrome中所需react-devtools的工具扩展程序包。

    ![image-20201023094120283](https://woniumd.oss-cn-hangzhou.aliyuncs.com/web/xuchaobo/20210808173415.png)

4. 打开chrome浏览器，配置插件

    打开谷歌浏览器，网址输入chrome://extensions/，选择`加载已解压的程序`，选择我们上一步生成的unpacked文件夹，这样就把插件安装成功。

    ![image-20201023094340008](https://woniumd.oss-cn-hangzhou.aliyuncs.com/web/xuchaobo/20210808173421.png)

    这个时候你在chrome加载插件栏里面就可以看到React Developer Tools插件。

    接着我们运行代码，就可以在浏览器中选择react来查看组件。

    ![image-20201023094635170](https://woniumd.oss-cn-hangzhou.aliyuncs.com/web/xuchaobo/20210808173428.png)

##  