## 一.项目准备工作

### 0.准备工作

**0.1.安装 ES7 React/Redux/GraphQL/React-Native snippets插件**

1）安装

在插件管理搜索框中输入:react

选择 ES7 React/Redux/GraphQL/React-Native snippets插件进行安装

2）该插件的常用操作

2.1）生成类组件的操作：rcc

2.2）生成函数式组件操作:rfc

2.3）生成文档注释：cmmb

2.4）生成console.log:  clg

### 1.使用脚手架搭建项目

```bash
npx create-react-app my-store    //下载模板项目
cd my-store
yarn start
```

访问:http://localhost:3000

### 2.项目的结构设计

2.1 清除脚手架不相干的文件

将src下除index.js和App.js文件之外的所有文件删除，并将App.js文件改为类组件

App.js

```js
import React, { Component } from 'react'
import './assets/styles/index.scss';
export default class App extends Component {
  render() {
    return (
      <div>
        App
      </div>
    )
  }
}

```

2.2 基本结构设计

![1610511583346](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1610511583346.png)

| 资源       | 说明         |
| ---------- | ------------ |
| api        | ajax相关     |
| assets     | 公共资源     |
| components | 组件         |
| config     | 配置         |
| pages      | 路由组件     |
| utils      | 工具模块     |
| App.jsx    | 应用根组件   |
| index.js   | 入口js文件   |
| consts.js  | 常量的js文件 |

### 3.在项目中使用scc编写样式

首先删除项目中的node_modules，删除package.json中的中的"devDependencies"节点中的node-sass节点

```js
 "devDependencies": {
     
  }
```

然后安装node-sass

```js
yarn add node-sass@4.x --registry=https://registry.npm.taobao.org --disturl=https://npm.taobao.org/dist --sass-binary-site=http://npm.taobao.org/mirrors/node-sass -D
```

### 4.引入重置样式reset.css

百度搜索reset.css

 https://meyerweb.com/eric/tools/css/reset/ 

在src/assets/styles目录下新建reset.css,将如下代码复制进去

```scss
/* http://meyerweb.com/eric/tools/css/reset/ 
   v2.0 | 20110126
   License: none (public domain)
*/

html, body, div, span, applet, object, iframe,
h1, h2, h3, h4, h5, h6, p, blockquote, pre,
a, abbr, acronym, address, big, cite, code,
del, dfn, em, img, ins, kbd, q, s, samp,
small, strike, strong, sub, sup, tt, var,
b, u, i, center,
dl, dt, dd, ol, ul, li,
fieldset, form, label, legend,
table, caption, tbody, tfoot, thead, tr, th, td,
article, aside, canvas, details, embed, 
figure, figcaption, footer, header, hgroup, 
menu, nav, output, ruby, section, summary,
time, mark, audio, video {
	margin: 0;
	padding: 0;
	border: 0;
	font-size: 100%;
	font: inherit;
	vertical-align: baseline;
}
/* HTML5 display-role reset for older browsers */
article, aside, details, figcaption, figure, 
footer, header, hgroup, menu, nav, section {
	display: block;
}
body {
	line-height: 1;
}
ol, ul {
	list-style: none;
}
blockquote, q {
	quotes: none;
}
blockquote:before, blockquote:after,
q:before, q:after {
	content: '';
	content: none;
}
table {
	border-collapse: collapse;
	border-spacing: 0;
}
```

然后在src/assets/styles目录下新建index.scss，将reset.css引入

```scss
@import 'reset.css'
```

最后再在App.js中引入index.scss

```js
import React, { Component } from 'react'
import './assets/styles/index.scss';
export default class App extends Component {
  render() {
    return (
      <div>
        App
      </div>
    )
  }
}
```

### 5.引入antd design框架

1.安装antd

```bash
yarn add antd
```

2.在index.scss中引入antd全局样式 

```scss
@import 'reset.css';
@import '~antd/dist/antd.css';
```

3.在App.js中引入antd的组件进行测试

```js
import React, { Component } from 'react'
import './assets/styles/index.scss';
import {Button} from 'antd'
export default class App extends Component {
  render() {
    return (
      <div>
        App
        <Button type='primary'>按钮</Button>
      </div>
    )
  }
}
```

## 二.用户登录

### 1.设置路由

1.1 安装路由

```bash
yarn add react-router-dom
```

1.2 根据项目的分析，在pages下新建三个组件

Login.js

```js
import React, { Component } from 'react'

export default class Login extends Component {
    render() {
        return (
            <div>
                登录页面
            </div>
        )
    }
}
```

Nav.js

```js
import React, { Component } from 'react'

export default class NavPage extends Component {
    render() {
        return (
            <div>
                NavPage
            </div>
        )
    }
}
```

NotFound.js

```js
import React, { Component } from 'react'

export default class NotFound extends Component {
    render() {
        return (
            <div>
                对不起，您输入的路径有误！
            </div>
        )
    }
}
```

1.3 在App.jsx配置路由

```js
import React, { Component } from 'react'
import './assets/styles/index.scss';
import {HashRouter,Switch,Route,Redirect} from 'react-router-dom'

class Loading extends Component{
  render(){
      return <div>加载中...</div>
  }
}
export default class App extends Component {
  render() {
    return (
      <React.Suspense fallback={<Loading></Loading>}>
          <HashRouter>
              <Switch>
                  <Redirect from='/' to='/login' exact />
                  <Route path='/login' 
                         component={React.lazy(()=>import('./pages/Login'))}></Route>
                  <Route path='/nav' 
                         component={React.lazy(()=>import('./pages/NavPage'))}></Route>
                  <Route component={React.lazy(()=>import('./pages/NotFound'))}></Route>
              </Switch>
          </HashRouter>
      </React.Suspense>
    )
  }
}
```

### 2.用户登录页面

修改Login.js页面

```js
import React, { Component } from 'react'
import { Form, Input, Button } from 'antd';
const layout = {
    labelCol: { span: 8 },
    wrapperCol: { span: 16 },
};
const tailLayout = {
    wrapperCol: { offset: 8, span: 16 },
};

export default class Login extends Component {
    onFinish = (values) => {
        console.log('Success:', values);
    };

    onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };
    render() {
        return (
            <div className='login'>
                <Form
                    {...layout}
                    name="basic"
                    initialValues={{ remember: true }}
                    onFinish={this.onFinish}
                    onFinishFailed={this.onFinishFailed}

                >
                    <Form.Item
                        label={<div style={{ color: '#fff' }}>用户名</div>}
                        name="username"
                        rules={[{ required: true, message: '请输入用户名!' }]}
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item
                        label={<div style={{ color: '#fff' }}>密码</div>}
                        name="password"
                        rules={[{ required: true, message: '请输入密码!' }]}
                    >
                        <Input.Password />
                    </Form.Item>
                    <Form.Item {...tailLayout}>
                        <Button type="primary" htmlType="submit">
                            登录
                         </Button>
                    </Form.Item>
                </Form>
            </div>
        )
    }
}
```

在asseets/styles下，新建login.scss，内容如下

```js
.login{
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #001529;
    height: 100vh;
}
```

然后在assets/style/index.scss中引入login.scss

```scss
@import 'reset.css';
@import 'login.scss';
@import '~antd/dist/antd.css';
```

运行后的效果如下所示

![1610524082256](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1610524082256.png)

### 3.登录接口

**1.安装axios**

```bash
yarn add axios
```

**2.修改表单**

由于后端提供的接口如下

```js
path：`/users/login`

method：post

params：{account:string,password:string}
```

所以需要将表单中的用户名的name属性为account

```js
<Form.Item
        label={<div style={{ color: '#fff' }}>用户名</div>}
        name="account"
        rules={[{ required: true, message: '请输入用户名!' }]}
 >
```

**3.在Login.js中的onFinish函数中编写登录的关键代码**

```js
import axios from 'axios';//导入axios 
//onFinish函数的关键代码
onFinish = (values) => {
       axios.post('http://jacklv.cn/users/login',values)
       .then((res)=>{
           console.log('res',res);
           if(res.data.code===1){
             const {token,userInfo} = res.data.data;
             //将token和userInfo保存到localStorage
             localStorage.setItem('token',token);
             localStorage.setItem('userInfo',JSON.stringify(userInfo));
             //保存后进行路由跳转
             this.props.history.push('/nav');
           }
       }).catch((err)=>{
           console.log('err',err);
       });
  };
```

**4.loading特效的制作**

1）在内部数据中定义loading数据

```js
 state={
     loading:false
 }
```

2）在onFinish函数中分别设置loading的状态数据

```js
onFinish = (values) => {
       axios.post('http://jacklv.cn/users/login',values)
       .then((res)=>{
           this.setState({loading:true});//设置为true
           console.log('res',res);
           if(res.data.code===1){
             this.setState({loading:false});//设置为false
             const {token,userInfo} = res.data.data;
             //将token和userInfo保存到localStorage
             localStorage.setItem('token',token);
             localStorage.setItem('userInfo',userInfo);
             //保存后进行路由跳转
             this.props.history.push('/nav');
           }
       }).catch((err)=>{
           console.log('err',err);
       });
    };
```

3）在登录按钮上添加loading属性

```js
<Button type="primary" htmlType="submit" loading={this.state.loading}>
     登录
</Button>
```

**5.将发送请求的接口移到apis文件夹下**

在src/apis下新建users.js

```js
import axios from 'axios';
axios.defaults.baseURL="http://jacklv.cn";

export const loginApi=(params)=>axios.post('/users/login',params);
```

在Login.js中导入并优化之前的登录代码

```js
import {loginApi} from '../apis/users';

onFinish = (values) => {
        loginApi(values)
       .then((res)=>{
           this.setState({loading:true});
           console.log('res',res);
           if(res.data.code===1){
             this.setState({loading:false});
             const {token,userInfo} = res.data.data;
             //将token和userInfo保存到localStorage
             localStorage.setItem('token',token);
             localStorage.setItem('userInfo',userInfo);
             //保存后进行路由跳转
             this.props.history.push('/nav');
           }
       }).catch((err)=>{
           console.log('err',err);
       });
    };
```

**6.代码优化**

将之前Login.js中用于的布局的代码移到consts.js文件中,并在这些常量前面添加export进行暴露

```js
export const layout = {
    labelCol: { span: 8 },
    wrapperCol: { span: 16 },
};
export const tailLayout = {
    wrapperCol: { offset: 8, span: 16 },
};

```

然后在Login.js中引入就可以了

```js
import {layout,tailLayout} from '../consts'
```

### 4.拦截器

在src/apis下新建interceptor.js文件，将axios拦截器的代码编写在这里

```js
import axios from 'axios';
import { notification } from 'antd'
/*
    请求拦截器
    use方法有两个参数
    参数1：拦截成功的回调
       req:表示拦截的数据
    参数2：拦截失败的回调
 */
axios.interceptors.request.use((req) => {
    const token = localStorage.getItem('token');
    if (token) {
        req.headers.token = token;
    }
    return req;
}, err => Promise.reject(err));
/**
 * 响应拦截器
 * 参数1：拦截成功的回调：主要拦截响应码为200的响应
 * 参数2：拦截失败的回到：主要拦截响应码为非200的响应
 */
axios.interceptors.response.use((res) => {
    //数据的过滤，只把前端页面所需的数据给页面
    console.log('拦截器', res);
    if (res.data.code === 1) {
        return res.data.data;
    } else {
        notification.error({ message: res.data.msg });
        return Promise.reject(res);
    }
    return res;
}, (err) => {
    const response = err.response;
    if (response) {
        switch (response.status) {
            case 500:
                notification.error({message:"服务端后台出现500错误"});
                break;
            case 401:
                notification.error({message:"服务端后台出现401错误"});
                break;
            case 404:
                notification.error({message:"没有找到服务端相应资源"});
                break;
            default:
        }
        return Promise.reject(err);
    }
});
```

在index.js文件中引入，这样全局都可以访问到

```js
import './apis/interceptor'
```

修改Login.js文件中的代码

由于在拦截器响应部分编写了过滤代码，所以Login.js中的代码要进行更改，更改如下

```js
onFinish = (values) => {
        loginApi(values)
       .then((res)=>{
           this.setState({loading:true});
           console.log('res',res);
           /*
            添加拦截器后就需要这样写了
           if(res.data.code===1){
            this.setState({loading:false});
            const {token,userInfo} = res.data.data;
            //将token和userInfo保存到localStorage
            localStorage.setItem('token',token);
            localStorage.setItem('userInfo',userInfo);
            //保存后进行路由跳转
            this.props.history.push('/nav');
           }
           */
          this.setState({loading:false});
          const {token,userInfo} = res;
          localStorage.setItem('token',token);
          localStorage.setItem('userInfo',userInfo);
          this.props.history.push('/nav');
       }).catch((err)=>{
           console.log('err',err);
       });
    };
```

## 三.后台首页

### 1.后台首页布局设计

后台首页符合这样的布局

![1610604401042](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1610604401042.png)

我们将官方提供的这个布局的代码复制到src/pages/NavPage.js中并将高度设置成100%

```js
import React, { Component } from 'react'
import { Layout, Menu, Breadcrumb } from 'antd';
import { UserOutlined, LaptopOutlined, NotificationOutlined } from '@ant-design/icons';

const { SubMenu } = Menu;
const { Header, Content, Sider } = Layout;
export default class NavPage extends Component {
    render() {
        return (
            <Layout style={{display:'flex',height:'100vh'}}>
                <Header className="header">
                    <div className="logo" />
                    <Menu theme="dark" mode="horizontal" defaultSelectedKeys={['2']}>
                        <Menu.Item key="1">nav 1</Menu.Item>
                        <Menu.Item key="2">nav 2</Menu.Item>
                        <Menu.Item key="3">nav 3</Menu.Item>
                    </Menu>
                </Header>
                <Layout>
                    <Sider width={200} className="site-layout-background">
                        <Menu
                            mode="inline"
                            defaultSelectedKeys={['1']}
                            defaultOpenKeys={['sub1']}
                            style={{ height: '100%', borderRight: 0 }}
                        >
                            <SubMenu key="sub1" icon={<UserOutlined />} title="subnav 1">
                                <Menu.Item key="1">option1</Menu.Item>
                                <Menu.Item key="2">option2</Menu.Item>
                                <Menu.Item key="3">option3</Menu.Item>
                                <Menu.Item key="4">option4</Menu.Item>
                            </SubMenu>
                            <SubMenu key="sub2" icon={<LaptopOutlined />} title="subnav 2">
                                <Menu.Item key="5">option5</Menu.Item>
                                <Menu.Item key="6">option6</Menu.Item>
                                <Menu.Item key="7">option7</Menu.Item>
                                <Menu.Item key="8">option8</Menu.Item>
                            </SubMenu>
                            <SubMenu key="sub3" icon={<NotificationOutlined />} title="subnav 3">
                                <Menu.Item key="9">option9</Menu.Item>
                                <Menu.Item key="10">option10</Menu.Item>
                                <Menu.Item key="11">option11</Menu.Item>
                                <Menu.Item key="12">option12</Menu.Item>
                            </SubMenu>
                        </Menu>
                    </Sider>
                    <Layout style={{ padding: '0 24px 24px' }}>
                        <Breadcrumb style={{ margin: '16px 0' }}>
                            <Breadcrumb.Item>Home</Breadcrumb.Item>
                            <Breadcrumb.Item>List</Breadcrumb.Item>
                            <Breadcrumb.Item>App</Breadcrumb.Item>
                        </Breadcrumb>
                        <Content
                            className="site-layout-background"
                            style={{
                                padding: 24,
                                margin: 0,
                                minHeight: 280,
                            }}
                        >
                            Content
                        </Content>
                    </Layout>
                </Layout>
            </Layout>
        )
    }
}
```

在assets/styles文件夹下新建navPages.scss,将官方提供的样式复制进去

```scss
#components-layout-demo-top-side-2 .logo {
    float: left;
    width: 120px;
    height: 31px;
    margin: 16px 24px 16px 0;
    background: rgba(255, 255, 255, 0.3);
  }
  
  .ant-row-rtl #components-layout-demo-top-side-2 .logo {
    float: right;
    margin: 16px 0 16px 24px;
  }
  
  .site-layout-background {
    background: #fff;
  }
```

然后，再在assets/styles/index.scss中引入

```scss
@import 'navPages.scss';
```

### 2.后台首页组件拆分

我们通过NavPages.js中布局的代码可以分析出首页布局分为三个部分，我们可以将其做成三个组件

2.1 首页头部组件

在src/components中新建MyHeader.js组件

```js
import React, { Component } from 'react'
import { Layout, Menu } from 'antd';


const { Header } = Layout;
export default class MyHeader extends Component {
    render() {
        return (
            <Header className="header">
                <div className="logo" />
                <Menu theme="dark" mode="horizontal" defaultSelectedKeys={['2']}>
                    <Menu.Item key="1">nav 1</Menu.Item>
                    <Menu.Item key="2">nav 2</Menu.Item>
                    <Menu.Item key="3">nav 3</Menu.Item>
                </Menu>
            </Header>
        )
    }
}
```

2.2 首页左侧栏组件

在src/components中新建MySider.js组件

```js
import React, { Component } from 'react'
import { Layout, Menu } from 'antd';
import { UserOutlined, LaptopOutlined, NotificationOutlined } from '@ant-design/icons';

const { SubMenu } = Menu;
const { Content, Sider } = Layout;
export default class MySider extends Component {
    render() {
        return (
            <Sider width={200} className="site-layout-background">
                <Menu
                    mode="inline"
                    defaultSelectedKeys={['1']}
                    defaultOpenKeys={['sub1']}
                    style={{ height: '100%', borderRight: 0 }}
                >
                    <SubMenu key="sub1" icon={<UserOutlined />} title="subnav 1">
                        <Menu.Item key="1">option1</Menu.Item>
                        <Menu.Item key="2">option2</Menu.Item>
                        <Menu.Item key="3">option3</Menu.Item>
                        <Menu.Item key="4">option4</Menu.Item>
                    </SubMenu>
                    <SubMenu key="sub2" icon={<LaptopOutlined />} title="subnav 2">
                        <Menu.Item key="5">option5</Menu.Item>
                        <Menu.Item key="6">option6</Menu.Item>
                        <Menu.Item key="7">option7</Menu.Item>
                        <Menu.Item key="8">option8</Menu.Item>
                    </SubMenu>
                    <SubMenu key="sub3" icon={<NotificationOutlined />} title="subnav 3">
                        <Menu.Item key="9">option9</Menu.Item>
                        <Menu.Item key="10">option10</Menu.Item>
                        <Menu.Item key="11">option11</Menu.Item>
                        <Menu.Item key="12">option12</Menu.Item>
                    </SubMenu>
                </Menu>
            </Sider>
        )
    }
}

```

2.3 后侧内容组件

在src/components中新建MyContent.js组件

```js
import React, { Component } from 'react'
import { Layout, Breadcrumb } from 'antd';
const {Content} = Layout;
export default class MyContent extends Component {
    render() {
        return (
            <Layout style={{ padding: '0 24px 24px' }}>
                <Breadcrumb style={{ margin: '16px 0' }}>
                    <Breadcrumb.Item>Home</Breadcrumb.Item>
                    <Breadcrumb.Item>List</Breadcrumb.Item>
                    <Breadcrumb.Item>App</Breadcrumb.Item>
                </Breadcrumb>
                <Content
                    className="site-layout-background"
                    style={{
                        padding: 24,
                        margin: 0,
                        minHeight: 280,
                    }}
                >
                    Content
            </Content>
            </Layout>
        )
    }
}
```

2.2 在NavPage.js中引入三个组件

```js
import React, { Component } from 'react'
import MyHeader from '../components/MyHeader'
import MySider from '../components/MySider';
import MyContent from '../components/MyContent';

import { Layout } from 'antd'
export default class NavPage extends Component {
    render() {
        return (
            <Layout style={{display:'flex',height:'100vh'}}>
                
                <MyHeader></MyHeader>

                <Layout>
                    
                     <MySider></MySider> 
                     <MyContent></MyContent>
                  
                </Layout>
            </Layout>
        )
    }
}
```

这样NavPage.js较之前页面简洁很多

### 3.完成安全退出功能

3.1 改造顶部部栏页面

```js
import React, { Component } from 'react'
import { Layout, Menu } from 'antd';


const { Header } = Layout;
export default class MyHeader extends Component {
    render() {
        return (
            <Header className="header" style={{display:'flex',justifyContent:'space-between'}}>
                <div style={{color:'#fff',fontSize:40,fontWeight:'bold',fontStyle:'italic'}}>蜗牛商城</div>
                <Menu theme="dark" mode="horizontal">
                    <Menu.Item key="person-center">个人中心</Menu.Item>
                    <Menu.Item key="logout">安全退出</Menu.Item>
                </Menu>
            </Header>
        )
    }
}
```

效果如下所示

![1610606379302](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1610606379302.png)

3.2 安全退出

```js
import React, { Component } from 'react'
import { Layout, Menu,Modal } from 'antd';
import {withRouter} from 'react-router-dom'


const { Header } = Layout;
class MyHeader extends Component {
    state={
        isModalVisible:false
    }
    //显示弹框
    showModal=(event)=>{
        switch(event.key){
            case 'person-center':
                break;
            case 'logout':
                this.setState({isModalVisible:true})
                break;
            default:
        }
    }
    //点击确认按钮
    handleOk = () => {
        localStorage.removeItem('token');
        localStorage.removeItem('userInfo');
        //路由跳转
        this.props.history.replace('/login');
       this.setState({isModalVisible:false})
    }
    //单击取消按钮
    handleCancel = () => {
        this.setState({isModalVisible:false})
    }
    render() {
        const {isModalVisible}=this.state;
        return (
            <React.Fragment>
                <Header className="header" 
                        style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <div style={{ color: '#fff', fontSize: 40, 
                                fontWeight: 'bold', fontStyle: 'italic' }}>蜗牛商城</div>
                    <Menu theme="dark" mode="horizontal" onClick={this.showModal}>
                        <Menu.Item key="person-center">个人中心</Menu.Item>
                        <Menu.Item key="logout">安全退出</Menu.Item>
                    </Menu>
                </Header>
                <Modal title="提示" 
                       visible={isModalVisible} 
                       onOk={this.handleOk} 
                       onCancel={this.handleCancel}
                       okText='确认'
                       cancelText='取消'>
                   您确定要退出系统吗?
                </Modal>
            </React.Fragment>
        )
    }
}
export default withRouter(MyHeader)
```

### 4.侧边栏基本功能

4.1 侧边栏内容设计

修改components/MySider.js

```js
import React, { Component } from 'react'
import { Layout, Menu } from 'antd';
import { UserOutlined, HomeOutlined,AppstoreOutlined,EuroCircleOutlined,DollarOutlined} from '@ant-design/icons';

const { SubMenu } = Menu;
const { Content, Sider } = Layout;
export default class MySider extends Component {
    render() {
        return (
            <Sider width={200} className="site-layout-background">
                <Menu
                    mode="inline"
                    defaultSelectedKeys={['1']}
                    defaultOpenKeys={['sub1']}
                    style={{ height: '100%', borderRight: 0 }}
                >
                    <Menu.Item key="1" icon={<HomeOutlined />}>首页</Menu.Item>
                    <Menu.Item key="2"  icon={<UserOutlined />}>账户管理</Menu.Item>
                    <SubMenu key="3" icon={<AppstoreOutlined/>} title="商品管理">
                      <Menu.Item key="31" icon={<EuroCircleOutlined/>}>商品列表</Menu.Item>
                      <Menu.Item key="32" icon={<DollarOutlined/>}>添加商品</Menu.Item>
                    </SubMenu>
                </Menu>
            </Sider>
        )
    }
}
```

效果如下所示

![1610609978136](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1610609978136.png)



4.2 设置二级路由

1）在pages分别创建如下组件

pages/index.js---------------->首页组件

pages/accounts/accounts.js------------>账户组件

pages/products/ProductList.js---------->商品列表组件

pages/products/ProductAdd.js----------->添加商品组件

2）在components/MyContent.js中设置二级路由

```js
import {Switch,Route,Redirect} from 'react-router-dom'
//在<Content>标签之间的Conent位置完成如下配置
<Switch>
     <Redirect from='/nav' to='/nav/index' exact></Redirect>
     <Route path="/nav/index" 
            component={React.lazy(()=>import('../pages/Index'))}></Route>
     <Route path="/nav/accounts" 
            component={React.lazy(()=>import('../pages/accounts/Accounts'))}></Route>
     <Route path="/nav/productList" 
            component={React.lazy(()=>import('../pages/products/ProductList'))}></Route>
     <Route path="/nav/productAdd" 
            component={React.lazy(()=>import('../pages/products/ProductAdd'))}></Route>
</Switch>
```

4.3 侧边栏设置路由跳转

为了方便起见将Menu.Item节点中的key设置成跳转的路径，然后这里将MySider使用高阶函数withRouter包装起来，这样该组件的this.props中就有了history了

```js
import React, { Component } from 'react'
import { Layout, Menu } from 'antd';
import { UserOutlined, HomeOutlined,AppstoreOutlined,EuroCircleOutlined,DollarOutlined} from '@ant-design/icons';
import {withRouter} from 'react-router-dom'
const { SubMenu } = Menu;
const { Content, Sider } = Layout;
class MySider extends Component {
    clickMenu=(params)=>{
        console.log('params',params.key);
        this.props.history.replace(params.key);
    }
    render() {
        return (
            <Sider width={200} className="site-layout-background">
                <Menu
                    mode="inline"
                    defaultSelectedKeys={['1']}
                    defaultOpenKeys={['3']}
                    style={{ height: '100%', borderRight: 0 }}
                    onClick={this.clickMenu}
                >
                    <Menu.Item key="/nav/index" 
                               icon={<HomeOutlined />}>首页</Menu.Item>
                    <Menu.Item key="/nav/accounts"  
                               icon={<UserOutlined />}>账户管理</Menu.Item>
                    <SubMenu key="productManage" 
                             icon={<AppstoreOutlined/>} 
                             title="商品管理">
                        <Menu.Item key="/nav/productList" 
                              icon={<EuroCircleOutlined/>}>商品列表</Menu.Item>
                        <Menu.Item key="/nav/productAdd" 
                              icon={<DollarOutlined/>}>添加商品</Menu.Item>
                    </SubMenu>
                </Menu>
            </Sider>
        )
    }
}
export default withRouter(MySider);
```

如上实现了侧边栏点击跳转的功能，但是我们的功能并不完美，目前存在如下问题

4.4 默认选中功能

默认情况下当用户登录后，进入后台首页应该默认选择的菜单是首页菜单，这个时候，我们可以通过设置<Menu>节点的defaultSelectedKeys="/nav/index"来实现

```js
 <Menu
     mode="inline"
     defaultSelectedKeys={['/nav/index']}
     defaultOpenKeys={['3']}
     style={{ height: '100%', borderRight: 0 }}
     onClick={this.clickMenu}
 >
```

这样实现虽然能够实现登录后默认选择首页菜单项，但是当用户点击其他Menu.Item选项后，如果不小心刷新了后台页面，会发现此时不会默认选择点击的Menu.Item,而是又会回到首页Menu.item,这是因为我们在设置的时候为defaultSelectKeys设置的是固定值"nav/index"，显然我们不能这样做，为了实现此功能，我们可以这样做

```js
render() {
        const {location}=this.props; //从this.props中解构出location对象
        console.log('location',location);
        return (
            <Sider width={200} className="site-layout-background">
                <Menu
                    mode="inline"
                    defaultSelectedKeys={[location.pathname]}  //location.pathname
                    defaultOpenKeys={['3']}
                    style={{ height: '100%', borderRight: 0 }}
                    onClick={this.clickMenu}>
                   //....省略
                </Menu>
            </Sider>
        )
    }
```

下面还有一个问题就是，当选择了二级菜单项的时候，应该让让其菜单展开，实现思路如下

1）单击菜单的时候，将SubMenu的key值保存到localStorage中

```js
clickMenu=(params)=>{
        console.log('params',params);
        const {key,keyPath}=params;
        const subMenuKey=keyPath[1];
        console.log('subMenuKey',subMenuKey);
        if(subMenuKey){
            localStorage.setItem('subMenuKey',subMenuKey);
        }
        this.props.history.replace(key);
 }
```

2）在render方法中从localStorage中取出该值

```js
render() {
        const subMenuKey=localStorage.getItem('subMenuKey');
    .......
```

3）在Menu的defaultOpenKeys中设置subMenuKey的内容

```js
<Menu
      mode="inline"
      defaultSelectedKeys={[location.pathname]}
      defaultOpenKeys={[subMenuKey]}   //将subMenuKey设置到defaultOpenKeys属性中
      style={{ height: '100%', borderRight: 0 }}
      onClick={this.clickMenu}
  >
```

4）当卸载组件后，从localStorage中清除subMenuKey

如上已经基本上实现了功能，但是还有一个问题，由于之前在localStorage中保存了subMenuKey,所以即使安全退出了系统，下次登录进来之前保存的subMenuKey还在，安全退出之前如果点击了二级菜单，那下次登录进来该二级菜单的父菜单就会被展开，这样会非常奇怪，所以，要想实现下次登录进来所以一级菜单都闭合，做法如下所示

```js
componentWillUnmount(){
     localStorage.removeItem('subMenuKey');
}
```

### 5.动态渲染侧边栏

5.1 首先在config文件夹下创建routes.js文件

```js
import { UserOutlined, HomeOutlined,AppstoreOutlined,EuroCircleOutlined,DollarOutlined} from '@ant-design/icons';
const routes=[
    {path:'/nav/index',icon:<HomeOutlined />,title:'首页'},
    {path:'/nav/accounts',icon:<UserOutlined />,title:'账户管理',roles:["超级管理员"]},
    {
        subMenuKey:'productManage',
        icon:<AppstoreOutlined/>,
        subMenuTitle:'商品管理',
        children:[
            {path:'/nav/productList',icon:<EuroCircleOutlined/>,title:'商品列表'},
            {path:'/nav/productAdd',icon:<DollarOutlined/>,title:'添加商品'}
        ]}
]
export default routes;
```

5.2 修改MySider.js文件

```js
import React, { Component } from 'react'
import { Layout, Menu } from 'antd';
import {withRouter} from 'react-router-dom'
import routes from '../config/routes';
const { Sider } = Layout;
const {SubMenu}=Menu;
class MySider extends Component {
    componentWillUnmount(){
        localStorage.removeItem('subMenuKey');
    }
    clickMenu=(params)=>{
        console.log('params',params);
        const {key,keyPath}=params;
        const subMenuKey=keyPath[1];
        console.log('subMenuKey',subMenuKey);
        if(subMenuKey){
            localStorage.setItem('subMenuKey',subMenuKey);
        }
        this.props.history.replace(key);
    }
    renderMenu=(routes)=>{
       console.log('routes',routes);
       //获取当前登录人的角色
       const {role}=JSON.parse(localStorage.getItem('userInfo'));
       console.log(role);
       console.log(routes);
       return routes.filter((item)=>!item.roles||item.roles.includes(role)).map((item)=>{
        const {path,title,subMenuKey,subMenuTitle,icon,children}=item;
        if(!subMenuKey){
           return <Menu.Item key={path} icon={icon}>{title}</Menu.Item>;
        }else{
            return <SubMenu key={subMenuKey} icon={icon} title={subMenuTitle}>
              {this.renderMenu(children)}
        </SubMenu>
        }
       });
       
    }
    render() {
        const {location}=this.props;
        const subMenuKey=localStorage.getItem('subMenuKey');
        return (
            <Sider width={200} className="site-layout-background">
                <Menu
                    mode="inline"
                    defaultSelectedKeys={[location.pathname]}
                    defaultOpenKeys={[subMenuKey]}
                    style={{ height: '100%', borderRight: 0 }}
                    onClick={this.clickMenu}
                >
                    {
                        this.renderMenu(routes)
                    }
                </Menu>
            </Sider>
        )
    }
}
export default withRouter(MySider);
```

演示：分别以admin/123和1/1两个用户登录，你会发现登录后的左侧栏菜单是不同的

### 6.个人中心

6.1 创建个人中心组件，并设置二级路由

1）在src/pages下创建userCenter文件夹，在该文件夹下创建UserCenter.js文件

```js
import React, { Component } from 'react'

export default class UserCenter extends Component {
    render() {
        return (
            <div>
                UserCenter
            </div>
        )
    }
}
```

2）在components/MyContent.js中的二级路由部分添加个人中心

```js
 <Switch>
      <Redirect from='/nav' to='/nav/index' exact></Redirect>
      <Route path="/nav/index" 
             component={React.lazy(()=>import('../pages/Index'))}></Route>
      <Route path="/nav/accounts" 
             component={React.lazy(()=>import('../pages/accounts/Accounts'))}></Route>
      <Route path="/nav/productList" 
             component={React.lazy(()=>import('../pages/products/ProductList'))}></Route>
      <Route path="/nav/productAdd" 
             component={React.lazy(()=>import('../pages/products/ProductAdd'))}></Route>
      {/*添加个人中心*/}
      <Route path='/nav/userCenter' 
            component={React.lazy(()=>import('../pages/userCenter/UserCenter'))}></Route>
 </Switch>
```

3）在MyHeader.js中，设置路由跳转，当使用者单击了“个人中心” 就会跳转到个人中心页面中去

```js
showModal=(event)=>{
        switch(event.key){
            case 'person-center':
                ｛/*路由跳转到个人中心页面*/｝
                this.props.history.replace('/nav/userCenter');
                break;
            case 'logout':
                this.setState({isModalVisible:true})
                break;
            default:
        }
 }
```

6.2 发送后端请求，获取用户信息

1）在apis/users中添加api接口，实现获取用户信息

```js
import axios from 'axios';
axios.defaults.baseURL="http://jacklv.cn";

export const loginApi=(params)=>axios.post('/users/login',params);
{/*获取当前登录人的信息的接口*/}
export const userCenterApi=()=>axios.get('/users/getUserInfo');
```

2）在UserCenter.js的生命周期钩子函数componentDidMount中调用后端请求的方法

```js
//使用之前先要导入
import { userCenterApi } from '../../apis/users' 
componentDidMount() {
     this.getUserInfo();
 }
 //自定义函数主要功能是异步获取当前登录人的信息
 getUserInfo = async () => {
     const { account, userGroup, imgUrl } = await userCenterApi();
 }
```

3）将获取的用户信息添加Form表单对应的组件中去

这里使用FormInstance中的setFieldsValue属性来设置表单的值，前提是先要获取 FormInstance，这里使用不受控表单的方式来获取

```js
<Form
     name="basic"
     onFinish={this.onFinish}
     ref={f => this.fromIns = f}
>
```

然后再在getUserInfo函数中通过this.fromIns.setFieldsValue来设置

```js
getUserInfo = async () => {
     const { account, userGroup, imgUrl } = await userCenterApi();
     const fileList=[{uid:imgUrl,thumbUrl:'http://jacklv.cn/images/default.jpg'}];
     this.fromIns.setFieldsValue({ account, userGroup,imgUrl:fileList})
}
```

6.3 只显示一个图片

如上操作完成之后，图片会有两个，一个是显示图片，一个是选中图片

![1610694629064](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1610694629064.png)

为什么会出现如上效果，这是因为在“<Upload》“标签之间的“选择图片”这几个字产生的

```js
<Upload name="logo" action="/upload.do" listType="picture-card">
      选择图片
</Upload>
```

如果有图片的情况下，不出现选择图片图片框，做法如下

1）首先，定义状态值fileList,用来存储fileList

```js
state={
    fileList:[]
}
```

2）getUserInfo方法中更新状态值fileList

```js
 getUserInfo = async () => {
     const { account, userGroup, imgUrl } = await userCenterApi();
     const fileList=[{uid:imgUrl,thumbUrl:'http://jacklv.cn/images/default.jpg'}];
     //更新fileList
     this.setState({fileList});
     this.fromIns.setFieldsValue({ account, userGroup,imgUrl:fileList})
}
```

3）在渲染方法中解构出fileList

```js
render() {
     const {fileList}=this.state;
}
```

4）在“<Upload>”标签中通过条件渲染，是否显示“选择图片”

```js
<Upload name="logo" action="/upload.do" listType="picture-card">
       {!fileList.length&& "选择图片"}
 </Upload>
```

6.4 删除图片

目前这个功能还存在一个问题，当用户点击图片上的删除按钮，就会出现这个图片卡片就消失了，如下所示

![1610695564806](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1610695564806.png)

解决办法：在normFile函数中添加this.setState({fileList:e.fileList});

```js
 normFile = (e) => {
        console.log('Upload event:', e);
        if (Array.isArray(e)) {
          return e;
        }
        //添加如下代码可以解决当点击删除按钮，图片消失的情况
        this.setState({fileList:e.fileList});
        return e && e.fileList;
 };
```

解决后的效果如下：当点击删除图片上的删除按钮出现如下效果

![1610695749694](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1610695749694.png)

### 7.解决401问题

我们在操作这个系统的过程中，经常出现401

![1610696020744](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1610696020744.png)

这是由于token失效而导致的，解决这个问题的办法如下

interceptor.js的响应拦截器的err部分

```js
case 401:
     //删除localStoreage中登录后保存的token和userInfo的信息
     localStorage.removeItem('token');
     localStorage.removeItem('userInfo');
     window.location.hash="#/login";
     break;
```

这样当token失效后，当向服务端发起请求自动会清除localStorage中的相关信息，并且跳转到登录页面

### 8.上传图像

8.1 设置图片为动态获取

由于之前是为了测试，个人图片我们设置的是固定值default.jpg,下面先将其改成动态的

```js
getUserInfo = async () => {
     const { account, userGroup, imgUrl } = await userCenterApi();
     //将之前的http://jacklv.cn/images/default.jpg改为'http://jacklv.cn/images/'+imgUrl
     const fileList=[{uid:imgUrl,thumbUrl:'http://jacklv.cn/images/'+imgUrl}];
     this.setState({fileList});
     this.fromIns.setFieldsValue({ account, userGroup,imgUrl:fileList})
}
```

更改后，重新刷新页面效果如下所示

![1610696461112](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1610696461112.png)

8.2 上传图片

按照API接口的要求

name设置为avatar

action设置为http://jacklv.cn/users/uploadProfile

又由于此时发送请求是通过Upload标签中的action提交到后台的并没有使用axios，所以token信息不能携带到服务端，所以在Upload标签中为我们提供了headers属性，可以在这里设置token

```js
<Upload 
        name="avatar" 
        action="http://jacklv.cn/users/uploadProfile" 
        listType="picture-card"
        headers={{token:localStorage.getItem('token')}}>
          {!fileList.length&& "选择图片"}
</Upload>
```

8.3 保存当前登录人的个人信息

如上虽然成功的上传图片到服务端，但是并没有将此图片保存到服务端的数据库中，所以下次刷新页面依然还是上次的图片，具体做法如下

1）在apis/users.js中添加保存当前登录人的个人信息的方法

```js
import axios from 'axios';
axios.defaults.baseURL="http://jacklv.cn";

export const loginApi=(params)=>axios.post('/users/login',params);
export const userCenterApi=()=>axios.get('/users/getUserInfo');
//保存当前登录人的个人信息
export const saveUserInfoApi=(params)=>axios.post('/users/saveUserInfo',params);
```

2）在UserCenter.js中的onFinish方法中完成保存信息

```js
 onFinish = async(values) => {
        console.log('values',values);
        const params={
            account:values.account,
            userGroup:values.userGroup,
        }
        if(values.imgUrl[0].response){   
            params.imgUrl=values.imgUrl[0].response.data;
        }else{
            params.imgUrl=values.imgUrl[0].uid;
        }
        console.log('params',params);
        const data=await saveUserInfoApi(params);
        console.log('data',data);      
  }
```





