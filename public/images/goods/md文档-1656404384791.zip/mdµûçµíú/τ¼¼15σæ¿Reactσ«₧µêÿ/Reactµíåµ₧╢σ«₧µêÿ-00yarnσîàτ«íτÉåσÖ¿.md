## React框架实战-00yarn包管理器

### Yarn包管理工具

现在我们已经在本地安装了npm包管理器，当然你还可以在本地安装yarn包管理器工具，在很多官方文档里面都使用了yarn这个命令，接下来我们就来讲一下这两个包管理器的区别。

“Yarn是由Facebook、Google、Exponent 和 Tilde 联合推出了一个新的 JS 包管理工具 ，正如[官方文档](https://link.jianshu.com/?t=http%3A%2F%2Flink.zhihu.com%2F%3Ftarget%3Dhttps%3A%2F%2Fcode.facebook.com%2Fposts%2F1840075619545360)中写的，Yarn 是为了弥补 npm 的一些缺陷而出现的

npm的缺陷

1. npm下载镜像的时候非常的慢，国内可以安装淘宝镜像，但是有时候也很慢。
2. 同一个项目，安装的时候**无法保持一致性**。在package.json文件中版本号的特点有时候是不固定的，比如我们经常看到的`"~5.0.3"`表示安装5.0.X中最新的版本，那我们在不同的时间运行这个项目可能就会出现依赖包版本不一致导致项目报错。
3. 下载报错问题，安装的时候，包会在同一时间下载和安装，中途某个时候，一个包抛出了一个错误，但是npm会继续下载和安装包，那项目运气的过程中就会出现各种异常，导致我们不好定位。

yarn包管理器的特点：

1. 快速性，Yarn 缓存了每个下载过的包，所以再次使用时无需重复下载。 同时利用并行下载以最大化资源利用率，因此安装速度更快
2. 安全性，在执行代码之前，Yarn 会通过算法校验每个安装包的完整性。
3. 可靠性，使用详细、简洁的锁文件格式和明确的安装算法，Yarn 能够保证在不同系统上无差异的工作。
4. 像npm一样，yarn使用本地缓存。与npm不同的是，yarn无需互联网连接就能安装本地缓存的依赖项，它提供了离线模式。这个功能在2012年的npm项目中就被提出来过，但一直没有实现.
5. 并行安装：无论 npm 还是 Yarn 在执行包的安装时，都会执行一系列任务。npm 是按照队列执行每个 package，也就是说必须要等到当前 package 安装完成之后，才能继续后面的安装。而 Yarn 是同步执行所有任务，提高了性能。
6. 安装**版本统一**：为了防止拉取到不同的版本，Yarn 有一个锁定文件 (lock file) 记录了被确切安装上的模块的版本号。每次只要新增了一个模块，Yarn 就会创建（或更新）yarn.lock 这个文件
7. **更简洁的输出**：npm 的输出信息比较冗长。在执行 npm install <package> 的时候，命令行里会不断地打印出所有被安装上的依赖。相比之下，Yarn 简洁太多
8. **更简洁的输出**：npm 的输出信息比较冗长。在执行 npm install <package> 的时候，命令行里会不断地打印出所有被安装上的依赖。相比之下，Yarn 简洁太多

关于npm和yarn命令的区别，接下来我们用一个表格来对比：

| npm命令                              | yarn命令                 |
| ------------------------------------ | ------------------------ |
| npm install                          | yarn install             |
| npm install [package] --save         | yarn add [package]       |
| npm install [package] --save-dev     | yarn add [package] --dev |
| npm install [package]@1.1.1 --save   | yarn add [package]@1.1.1 |
| npm uninstall [package] --save(-dev) | yarn remove [package]    |
| npm update --save                    | yarn upgrade             |
| npm  init                            | yarn init                |

yarn的官方： https://yarn.bootcss.com/ 

### yarn下载

使用npm的下载yarn

```bash
npm install -g yarn
`
`查看版本：yarn --version
```

查看yarn的配置项

```bash
yarn config list // 显示所有配置项
```

yarn 淘宝源安装，分别复制粘贴以下代码行到黑窗口运行即可

```bash
yarn config set registry https://registry.npm.taobao.org -g
yarn config set sass_binary_site http://cdn.npm.taobao.org/dist/node-sass -g
```





### 4.Yarn包管理工具

4.1 yarn的官方： https://yarn.bootcss.com/ 

4.2 安装yarn

```bash
npm install -g yarn   //全局安装yarn
//查看yarn的镜像，默认是国外镜像 ，https://registry.yarnpkg.com
yarn config get registry
//yarn配置淘宝镜像
yarn config set registry https://registry.npm.taobao.org -g  
//查看yarn的版本
yarn --version  
```

4.3 yarn的命令的基本用法

1）初始化新项目

```bash
yarn init
```

2）添加依赖包

```bash
yarn add [package]
yarn add [package]@[version]
```

3）移除依赖包j

```bash
yarn remove [package]
```

常用的命令：

| npm命令                              | yarn命令                 |
| ------------------------------------ | ------------------------ |
| npm install                          | yarn add                 |
| npm install [package] --save         | yarn add [package]       |
| npm install [package] --save-dev     | yarn add [package] --dev |
| npm install [package]@1.1.1 --save   | yarn add [package]@1.1.1 |
| npm uninstall [package] --save(-dev) | yarn remove [package]    |
| npm update --save                    | yarn upgrade             |
| npm  init                            |                          |