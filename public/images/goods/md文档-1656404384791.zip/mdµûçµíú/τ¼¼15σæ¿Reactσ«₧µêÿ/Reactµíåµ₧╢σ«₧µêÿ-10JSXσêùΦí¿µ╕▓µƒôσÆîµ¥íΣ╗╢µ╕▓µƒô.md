## JSX列表渲染和条件渲染

### 1.JSX列表渲染

 通过所学的知识，完成如下案例

![image-20201220115049383](F:\WEB前端\笔记\第4阶段\第15周React实战\image\image-20201220115049383.png)

实现步骤

1.在public文件夹下创建images文件夹，并将四张课程的图片放进去

2.在src下创建css文件夹，并在该文件夹下创建course.css文件

```css
.seriesItemBox{
    margin: 10px;
    float: left;
    border:1px solid #ccc;
    padding: 10px;
    text-align: center;
    border-radius: 15px;
}
```

3.在src下创建components文件夹，该文件夹下存放的都是自定义的组件

课程列表组件

```js
import React from 'react';
import CourseItem from './CourseItem'
export default class CourseList extends React.Component{
    constructor(){
        super();
        this.state={
            courseList:[
                {
                    id:1,imgname:'../images/model1.jpg',
                    title:'Python实战开发',
                    content:'精通Python学习指南'
                },
                {
                    id:2,imgname:'../images/model2.jpg',
                    title:'Java实战开发',
                    content:'精通Java学习指南'
                },
                {
                    id:3,imgname:'../images/model3.jpg',
                    title:'H5实战开发',
                    content:'精通H5学习指南'
                },
                {
                    id:4,imgname:'../images/model4.jpg',
                    title:'测试框架开发',
                    content:'精通测试框架学习指南'
                }
            ]
        }
    }
    render(){
        const template=(
            <div>
                {this.state.courseList.map(item=><CourseItem {...item} key={item.id}></CourseItem>)}
            </div>
        );
        return template;
    }
}
```

课程列表项组件

```js
import React from 'react';
import './css/course.css'

export default class CourseItem extends React.Component{
    constructor(props){
        super(props);
        this.state={};
    }
    render(){
        console.log(this);
        const template=(
            <div className='seriesItemBox'>
                <img src={this.props.imgname} alt={this.props.title} width='160px' height='90px'></img>
                <h3>{this.props.title}</h3>
                <div>{this.props.content}</div>
            </div>
        );
        return template;
    }
}
```

4.在index.js页面张引入课程列表组件

```js
import React from 'react';
import ReactDOM from 'react-dom';
import CourseList from './components/CourseList'

ReactDOM.render(<CourseList></CourseList>,document.getElementById('root'));
```

### 2.JSX条件渲染

实现如下效果

![1610355796534](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1610355796534.png)

更改courseList数据，每个对象中添加isfree属性，用来表示课程是否免费

```js
import React from 'react';
import CourseItem from './CourseItem'
export default class CourseList extends React.Component{
    constructor(){
        super();
        this.state={
            courseList:[
                {
                    id:1,imgname:'../images/model1.jpg',
                    title:'Python实战开发',
                    content:'精通Python学习指南',
                    isfree:true
                },
                {
                    id:2,imgname:'../images/model2.jpg',
                    title:'Java实战开发',
                    content:'精通Java学习指南',
                    isfree:false},
                {
                    id:3,imgname:'../images/model3.jpg',
                    title:'H5实战开发',
                    content:'精通H5学习指南',
                    isfree:true
                },
                {
                    id:4,imgname:'../images/model4.jpg',
                    title:'测试框架开发',
                    content:'精通测试框架学习指南',
                    isfree:false
                }
            ]
        }
    }
    render(){
        const template=(
            <div>
                {this.state.courseList.map(item=><CourseItem {...item} key={item.id}></CourseItem>)}
            </div>
        );
        return template;
    }
}
```

在CourseItem.jsx中使用JSX的条件渲染

```js
import React from 'react';
import './css/course.css'

export default class CourseItem extends React.Component{
    constructor(props){
        super(props);
        this.state={};
    }
    render(){
        console.log(this);
        const template=(
            <div className='seriesItemBox'>
                <img src={this.props.imgname} alt={this.props.title} width='160px' 
                     height='90px'></img>
                <h3>{this.props.title}</h3>
                <div>{this.props.content}</div>
                {this.props.isfree && <button>免费试听</button>}
            </div>
        );
        return template;
    }
}
```

### 3.购物车实现

#### 3.1 购物车的基本实现

```js
import React, { Component } from 'react'

export default class ShopCart extends Component {
    state={
        list:[
            {id:1,name:'苹果',price:10,num:1},
            {id:2,name:'梨子',price:20,num:2},
            {id:3,name:'香蕉',price:15,num:1}
        ]
    }
    changeNum=(index,n)=>{
        const {list}=this.state;
        list[index].num+=n;
        this.setState({list});
    }
    deleteHandler=(index)=>{
        /*
        const {list}=this.state;
        list.splice(index,1);
        this.setState({list});
        */
       this.setState(({list})=>{
           list.splice(index,1);
           return{
               list
           }
       })
    }
    get total(){
        console.log("total重新计算了!")
        return this.state.list.reduce((t,curObj)=>{
            return t + curObj.price * curObj.num;
        },0);
    }
    render() {
        const {list}=this.state;
        console.log('render方法执行了!');
        return (
            <React.Fragment>
                <table>
                    <thead>
                        <tr>
                            <th>商品名称</th>
                            <th>价格</th>
                            <th>数量</th>
                            <th>小计</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                           list.map((item,index)=>{
                             return <tr key={item.id}>
                                <td>{item.name}</td>
                                <td>{item.price}</td>
                                <td>
                                    <button disabled={item.num===1} 
                                       onClick={()=>this.changeNum(index,-1)}>-</button>
                                        {item.num}
                                    <button 
                                        onClick={()=>this.changeNum(index,1)}>+</button>
                                </td>
                                <td>
                                    {item.price*item.num}
                                </td>
                                <td>
                                    <button 
                                      onClick={()=>this.deleteHandler(index)}>删除
                                    </button>
                                </td>
                            </tr>
                           })
                           
                        }
                       
                    </tbody>
                </table>
                总价:{this.total}
            </React.Fragment>
        )
    }
}
```

#### 3.2 购物车组件拆分之容器组件和展示组件

1）容器组件:容器组件只负责提供数据，以及数据的修改逻辑，它不负责界面的渲染

```js
import React, { Component } from 'react'
import ShopCartShow from './ShopCartShow'
/**
 * 什么是容器组件：
 * 容器组件只负责提供数据，以及数据的修改逻辑，它不负责界面的渲染
 * 什么是展示组件：
 * 展示组件不负责数据的提供和修改，只被动接收数据和方法，渲染界面
 */
export default class ShopCartContainer extends Component {
    state={
        list:[
            {id:1,name:'苹果',price:10,num:1},
            {id:2,name:'梨子',price:20,num:2},
            {id:3,name:'香蕉',price:15,num:1}
        ]
    }
    changeNum=(index,n)=>{
        const {list}=this.state;
        list[index].num+=n;
        this.setState({list});
    }
    deleteHandler=(index)=>{
        /*
        const {list}=this.state;
        list.splice(index,1);
        this.setState({list});
        */
       this.setState(({list})=>{
           list.splice(index,1);
           return{
               list
           }
       })
    }
    get total(){
        console.log("total重新计算了!")
        return this.state.list.reduce((t,curObj)=>{
            return t + curObj.price * curObj.num;
        },0);
    }
    render() {
        return (
            <div>
                <ShopCartShow list={this.state.list} 
                changeNum={this.changeNum}
                deleteHandler={this.deleteHandler}
                total={this.total}></ShopCartShow>
            </div>
        )
    }
}
```

2）展示组件:展示组件不负责数据的提供和修改，只被动接收数据和方法，渲染界面

```js
import React, { Component } from 'react'

export default class ShopCartShow extends Component {
    render() {
        const {list,changeNum,deleteHandler,total}=this.props;
        return (
            <div>
                <table>
                    <thead>
                        <tr>
                            <th>商品名称</th>
                            <th>价格</th>
                            <th>数量</th>
                            <th>小计</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                           list.map((item,index)=>{
                             return <tr key={item.id}>
                                <td>{item.name}</td>
                                <td>{item.price}</td>
                                <td>
                                    <button disabled={item.num===1} 
                                            onClick={()=>changeNum(index,-1)}>-</button>
                                        {item.num}
                                    <button onClick={()=>changeNum(index,1)}>+</button>
                                </td>
                                <td>
                                    {item.price*item.num}
                                </td>
                                <td>
                                    <button 
                                        onClick={()=>deleteHandler(index)}>删除</button>
                                </td>
                            </tr>
                           })
                           
                        }
                    </tbody>
                </table>
                总价:{total}
            </div>
        )
    }
}
```
