## 一.React数据管理redux

### 1.组件通讯

#### 1.1 父子组件通讯

##### 1.1.1 父组件向子组件传值

```js
import React, { Component } from 'react'
import Child from './Child'

export default class Parent extends Component {
    state={
        msg:'父组件中的信息'
    }
    render() {
        return (
            <div>
                父组件
                <Child msg={this.state.msg}></Child>
            </div>
        )
    }
}
```

```js
import React, { Component } from 'react'

export default class Child extends Component {
    render() {
        return (
            <div>
                子组件:{this.props.msg}
            </div>
        )
    }
}
```

##### 1.1.2 子组件向父组件传值

子组件

```js
import React, { Component } from 'react'

export default class Child extends Component {
    postMsgToParent=()=>{
        //向父组件传递数据
        this.props.callback("来自于子组件");
    }
    render() {
        return (
            <div>
                子组件:{this.props.msg}
                <button onClick={this.postMsgToParent}>点我</button>
            </div>
        )
    }
}

```

父组件

```js
import React, { Component } from 'react'
import Child from './Child'

export default class Parent extends Component {
    state={
        msg:'父组件中的信息',
        cmsg:''
    }
    getMsgFromChild=(params)=>{
        this.setState({
            cmsg:params
        })
    }
    render() {
        return (
            <div>
                父组件
                <Child msg={this.state.msg} callback={this.getMsgFromChild}></Child>
                <div>{this.state.cmsg}</div>
            </div>
        )
    }
}

```

#### 1.2 兄弟组件通讯

兄弟之间传递参数我们有多种方案，本节中我们就给大家带来两种处理方案。

##### 1.2.1 基于父-子(两个子组件为兄弟关系)

在项目中要让兄弟之间能传递值，我们依然将数据放在父组件，两个子组件分别从父组件获取数据，一旦某一个子组件改变了数据，另外一个兄弟也能接受到新数据达到更新的效果。

父组件的代码设计：

```js
import React, { Component } from 'react'
import Borther1 from './Borther1'
import Borther2 from './Borther2'

export default class Parent extends Component {
    state={
        className:'web01'
    }
    changeData=(param)=>{
        console.log(param)
        this.setState({
            className:param
        });
    }
    render() {
        return (
            <div>
                <h1>parentComponent</h1>
                <Borther1 className={this.state.className}></Borther1>
                <Borther2 className={this.state.className} eventLis={this.changeData}></Borther2>
            </div>
        )
    }
}
```

state中的数据分别传递给Borther1和Borther2，并且给Borther2传递一个事件函数，用于对数据的修改。

接下来在Brother2组件里面执行数据修改，一旦把父原生的state改变，Borther1组件也能获取到结果。

```js
import React, { Component } from 'react'

export default class Borther2 extends Component {
    changeData=()=>{
        this.props.eventLis('web03');
    }
    render() {
        return (
            <div>
                <h2>兄弟2</h2>
                <p>数据为:{this.props.className}</p>
                <button onClick={this.changeData}>修改数据</button>
            </div>
        )
    }
}
```

点击修改数据，两个兄弟组件的数据都会改变，这个适用于兄弟组件之间共享数据，一旦对数据进行修改后，另外一个组件也应该发生同步修改。

##### 1.2.2 基于事件总线的方式来设计

EventBus 又称为事件总线。在Vue中可以使用 EventBus 来作为沟通桥梁的概念，就像是所有组件共用相同的事件中心，可以向该中心注册发送事件或接收事件，所以组件都可以上下平行地通知其他组件，但也就是太方便所以若使用不慎，就会造成难以维护的灾难，因此才需要更完善的Vuex作为状态管理中心，将通知的概念上升到共享状态层次。

​		但在React中没有EventBus的概念，可以通过 node events模块进行模拟，在React中可以依赖一个使用较多的库 events 来完成对应的操作。

1）安装events

```bash
yarn add events
```

2）创建事件中心

新建一个文件MyEventListener.js文件用于作为事件中心。

```js
import { EventEmitter } from 'events';
export default new EventEmitter();
```

我们只需要引入EventEmitter对象，将这个对象实例化过后返回出去，调用的时候执行对应的API就可以完成事件的绑定和通知

events常用的API：

- 创建EventEmitter对象：eventBus对象；

- 发出事件：eventBus.emit("事件名称", 参数列表);
- 监听事件：eventBus.addListener("事件名称", 监听函数)；
- 移除事件：eventBus.removeListener("事件名称", 监听函数)；

3）监听事件

```js
import React, { Component } from 'react'
import MyEventListener from './MyEventListener'

export default class Borther1 extends Component {
    state={
        className:'web05'
    }
    //在组件完毕后就监听dataChange事件
    componentDidMount(){
        MyEventListener.addListener("dataChange",this.changeData);
    }
    //当组件卸载的时候就移除事件监听
    componentWillUnmount(){
        MyEventListener.removeListener('dataChange',this.changeData);
    }
    changeData=(params)=>{
        this.setState({
            className:params
        });
    }
    render() {
        return (
            <div>
                <h2>兄弟1</h2>
                <p>数据为:{this.state.className}</p>
            </div>
        )
    }
}
```

在生命周期函数里面绑定事件监听和移除事件监听，当事件中心里面加入了dataChange事件，当前组件就能监听到，接着执行我们绑定的changeData。

4）发送事件

在Brother2组件里面我们添加一个按钮，往事件中心发出一个dataChange事件，并将值传递给调用者

```js
import React, { Component } from 'react'
import MyEventListener from './MyEventListener'

export default class Borther2 extends Component {
    changeData=()=>{
        MyEventListener.emit("dataChange","web08");
    }
    render() {
        return (
            <div>
                <h2>兄弟2</h2>
                <button onClick={this.changeData}>修改数据</button>
            </div>
        )
    }
}
```

其中emit这个API就可以完成事件发送。这样就可以完成兄弟组件之间的参数传递，当然事件总线这种设计模式可以应用在任何组件之间。实现跨组件通信。

### 2.什么是Redux

​		redux是专门用于做状态管理的第三方JS库，并不是react的插件。组件之间传递参数我们可以使用以上的方案来实现，但如果遇到更加复杂的组件结构需要传递参数，那我们的代码实现起来就更加的麻烦。所以接下来我们专门研究redux来完美解决问题。c

​		redux可以对我们应用中的状态进行集中的管理（读/写）。不管在在vue、angular、react还是其他的框架都可以使用redux来提供一个统一的数据仓库完成状态管理。但是vue、angular一般都没有用redux来管理状态。

### 3.redux的安装

```bash
yarn add redux
```

### 4.redux的工作流程

![](F:\WEB前端\笔记\第4阶段\第15周React实战\image\timg-2.jpeg)

### 5.redux的核心概念

#### 5.1 store

1）概念： 数据仓库，存放组件数据的地方。一个项目一般只有一个数据仓库 

2）创建store

首先在src目录下创建store文件夹，在该文件夹下创建store.js文件，内容如下所示

```js
import {createStore} from 'redux'

const store=createStore(function(){});
console.log('store',store);
```

然后在src/index.js中通过import引入store

```js
import ReactDOM from 'react-dom'
import App from './App'
import './store/store'

ReactDOM.render(<App></App>,document.getElementById('root'))
```

然后执行在控制台打印出store对象，如下所示

![1609293012493](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1609293012493.png)

下面我们来输出一下store.getState()

```js
import {createStore} from 'redux'

const store=createStore(function(){});
console.log('state',store.getState());
```

输出的结果为undefined

创建一个仓库，createStore函数需要传递一个纯函数作为参数。这个纯函数返回的数据就是仓库要更新的数据，

如果没有return值那默认就是undefined

```js
//位置：src/store/store.jse
const store=createStore(function(state=0){
    console.log('state',state)
    return state;
});
```

store就是我们创建的仓库，也是一个对象，在仓库里面有一个默认的state值为0。

3）获取store中的数据

```js
// 获取到仓库中的数据
console.log("state:", store.getState());
```

#### 5.2 action

action是一个通知对象，里面必须有一个type属性，表示当前通知的类型，至于其他属性，你可以任意添加（一般是我们在最后计算新的值的时候，所需要的参数）
我们在修改store中数据的时候，唯一的方式，是向store派发action的通知对象

```js
const myAction={
    type:'addCount',
    num:2
}
```

2）更新仓库的数据

```js
// 更新仓库的数据
store.dispatch(myAction);
```

更新仓库的数据直接调用dispatch函数，这个函数的作用可以将你定义的修改规则和数据作用在仓库中的数据，但是只写这一步肯定还不能完成。不过你执行一次dispatch函数就会调用一次createStore的函数。

#### 5.3  reducer

现在store已经创建成功，Action对象也定义成功，那接下来要对store中的数据修改成功，我们还需要一个reducer，将action中的修改规则获取到，进行数据更新。

```js
function reducer(state=0,action){
    switch(action.type){
        case 'addCount':
            return state+action.num;
        default:
            return state;
    }
}
```

创建完成后接下来将reduce函数放在createStore函数里面去调用。

Reducers 指定了应用状态的变化如何响应 actions 并发送到 store 的，也就说我们store里面的数据要修改，就是通过reducer来修改的。你在createStore里面传递一个函数，这个函数就称为reducer。

```js
const store = createStore(reducer);
```

完整的代码如下所示

```js
import {createStore} from 'redux'

const store=createStore(reducer);


const myAction={
    type:'addCount',
    num:2
}
store.dispatch(myAction);

function reducer(state=0,action){
    switch(action.type){
        case 'addCount':
            return state+action.num;
        default:
            return state;
    }
}
console.log('state',store.getState());
```

## 二.redux中action和reducer的优化

通过上面的案列我们已经完成了最基础的代码设计，接下来我们需要优化一下代码。

项目中肯定不止一个数据，所以state的默认值应该是一个对象，而不是其他。而且除了默认值，每当case到一个条件，返回一个新的对象时，应该返回一个全新的对象，然后才是你要修改的数据（当然这些数据，如果是引用类型的话，应该修改其引用本身，否则界面可能不会更新，尽管数据发生变化了 

```js
function reducer(state={
    num:0
},action){
    switch(action.type){
        case 'addCount':
            return state.num+action.num;
        default:
            return state;
    }
}
```

如上的显示效果是正常的，但是我们不推荐这种做法，官方推荐如下方式

```js
function reducer(state={
    num:0
},action){
    switch(action.type){
        case 'addCount':
            return{
                ...state,
                num:state.num+=action.num
            }
        default:
            return state;
    }
}
```

注意： 我们一般会在页面里面修改数据，即，在页面里面调用store的dispatch方法。那就意味着action对象中的num字段很大可能是动态的，即不同的页面num字段可能是不同的，这样我们就不能把a写成一个死的对象，最好是封装成一个函数，执行过后返回一个action通知对象，然后num的值通过函数的参数来决定。这样的函数我们称之为action创建函数（action creator） 

```js
const myActionAC=(num)=>{
    return{
        type:'addCount',
        num
    }
}
store.dispatch(myActionAC(4));
```

## 三.组件如何订阅store中的数据

为了方便使用，Redux 的作者封装了一个 React 专用的库 React-Redux,这个库是可以选用的。实际项目中，你应该权衡一下，是直接使用 Redux，还是使用 React-Redux。后者虽然提供了便利，但是需要掌握额外的 API，并且要遵守它的组件拆分规范。

​		React-Redux 将所有组件分成两大类：UI 组件（presentational component）和容器组件（container component）。

UI组件：只负责 UI 的呈现，不带有任何业务逻辑，没有状态（即不使用this.state这个变量），所有数据都由参数（this.props）提供，不使用任何 Redux 的 API。

```js
<div>
    <h2>Brother2:{this.props.number}</h2>
    <button onClick={this.props.increment} type="button">增加数据</button>
    <button onClick={this.props.decrement} type="button">减少数据</button>
</div>
```

容器组件：负责管理数据和业务逻辑，不负责 UI 的呈现，每个组件带有内部状态，使用 Redux 的 API来完成数据传输。UI 组件负责 UI 的呈现，容器组件负责管理数据和逻辑。

如果一个组件既有UI，又需要业务逻辑那我们可以将这个组件拆分，外面是一个容器组件，里面包了一个UI 组件。前者负责与外部的通信，将数据传给后者，由后者渲染出视图。

```js
<Provider store={store}>
    <Brother1/>
    <Brother2/>
</Provider>
```

比如Provider就是我们的容器组件，不负责显示，更多负责数据的传输。

React-Redux 规定，所有的 UI 组件都由用户提供，容器组件则是由 React-Redux 自动生成。也就是说，用户负责视觉层，状态管理则是全部交给它。

在使用react-redux库的时候常用的API和组件：

1. <Provider> 组件：React-Redux 提供Provider组件，可以让容器组件拿到state，比如之前的代码，我们在Provider组件里面包含了Brother1和Brother2，这样做的好处就是Brother1组件和Brother2组件以及他们的子组件都可以获取到state数据。所以一般在根组件外面套一层Provider组件。这样所有的子组件都可以获取到state数据。

2. connect()函数：这个是React中的一个高阶函数，用于从 UI 组件生成容器组件，一旦使用connect将UI组件变成容器组件后，我们就可以接受外部数据，并调用dispatch来执行业务逻辑。

    connect方法接受两个参数：mapStateToProps和mapDispatchToProps。它们定义了 UI 组件的业务逻辑。前者负责输入逻辑，即将state映射到 UI 组件的参数（props），后者负责输出逻辑，即将用户对 UI 组件的操作映射成 Action。

### react-redux

 1.下载依赖

```js
yarn add react-redux
```

2.src/store/store.js

```js
import {createStore} from 'redux'

const store=createStore(reducer);

function reducer(state={
    num:0
},action){
    switch(action.type){
        case 'addCount':
            return{
                ...state,
                num:state.num+=action.num
            }
        default:
            return state;
    }
}
export default store;
```

3.src/store/actions.js

```js
export const myActionAC=(num)=>{
    return{
        type:'addCount',
        num
    }
}
```

4.容器类组件

```js
import React, { Component } from 'react'
import GrandMom from './GrandMom'
import {Provider} from 'react-redux'
import store from '../store/store'

export default class Container extends Component {
    render() {
        return (
            <Provider store={store}>
                <GrandMom/>
            </Provider>
        )
    }
}
```

5.GrandMoom组件

```js
import React, { Component } from 'react'
import Parent from './Parent'
import {connect} from 'react-redux'

class GrandMom extends Component {
    render() {
        return (
            <div>
                GrandMom:{this.props.count}
                <Parent/>
            </div>
        )
    }
}
/*
  形参state表示store里面的所有数据
*/
const mapStateToProps=(state)=>{
    console.log('state==',state)
    return{
       count:state.num
    }
}
export default connect(mapStateToProps)(GrandMom);

```

6.Parent组件

```js
import React, { Component } from 'react'
import Child from './Child'

export default class Parent extends Component {
    render() {
        return (
            <div>
                Parent
                <Child/>
            </div>
        )
    }
}
```

7.Child组件

```js
import React, { Component } from 'react'
import {connect} from 'react-redux'
import {myActionAC} from '../store/actions'

class Child extends Component {
    changeNum=()=>{
        this.props.dispatch(myActionAC(4))
    }
    render() {
        return (
            <div>
               Child:{this.props.count}
               <button onClick={this.changeNum}>修改num</button>
            </div>
        )
    }
} 
const mapStateToProps=(state)=>{
    console.log('====state',state)
    return{
        count:state.num
    }
}
export default connect(mapStateToProps)(Child)
```

#### 数据的修改

完成数据的修改功能

mapDispatchToProps是connect函数的第二个参数，用来建立 UI 组件的参数到store.dispatch方法的映射。它定义了哪些用户的操作应该当作 Action，传给 Store。它可以是一个函数，也可以是一个对象。

```js
// 如果要修改数据,那就需要在当前这个组件中调用dispatch方法
const mapDispatchtoProps=(dispatch)=>{
    return {
        increment:()=>{dispatch(increment())},
        decrement:()=>{dispatch(decrement())}
    }
}
export default connect(mapStateToProps,mapDispatchtoProps)(Brother2);
```

自定义一个函数mapDispatchtoProps里面接受dispatch参数，在返回值里面定义increment和decrement函数用于对数据的修改。

![image-20201023161555462](Z:\xuchaobo\work\第四阶段\React\资料\md文档\第15周React实战\image\image-20201023161555462.png)

完成以上操作后，你会发现我们props里面又新增了increment函数和decrement函数，这样我们就可以在UI组件中调用props里面的函数来完成数据的修改。

1. 调用props函数完成对store数据的修改。

    ```js
    class Brother2 extends Component {
        render() {
            return (
                <div>
                    <h2>Brother2:{this.props.number}</h2>
                    <button type="button" onClick={this.props.increment}>增加数据</button>
                    <button type="button" onClick={this.props.decrement}>减少数据</button>
                </div>
            )
        }
    }
    const mapStateToProps=(state)=>{
        return {
            number:state
        }
    }
    // 如果要修改数据,那就需要在当前这个组件中调用dispatch方法
    const mapDispatchtoProps=(dispatch)=>{
        return {
            increment:()=>{dispatch(increment())},
            decrement:()=>{dispatch(decrement())}
        }
    }
    export default connect(mapStateToProps,mapDispatchtoProps)(Brother2);
    ```

    在按钮上绑定事件调用increment和decrement来完成action的派发。

    同样的在Borther1里面我们也执行同样的代码逻辑。这样就可以达到，组件之间数据同步增加和减少。

    ![image-20201023161909340](Z:\xuchaobo\work\第四阶段\React\资料\md文档\第15周React实战\image\image-20201023161909340.png)

##### bindActionCreators函数

思考？在上面的代码中我们要实现数据传参，或者优化以下action，在代码中使用mapDispatchtoProps获取到dispatch过后，每个action我们都要自己在定义以下。

action中的代码

```js
export const Increment=(num)=>{
    return{
        type:'INCREMENT',
        num
    }
}
```

bindActionCreators是redux的一个自带函数，作用是将单个或多个ActionCreator转化为dispatch(action)的函数集合形式。开发者不用再手动dispatch(actionCreator(type))，而是可以直接调用方法。

```js
import * as actionCreator  from "./actions/quantifyAction"
import {bindActionCreators} from "redux"
const mapDispatchtoProps=(dispatch)=>{
    return {
        actionCreator:bindActionCreators(actionCreator,dispatch)
    }
}
export default connect(mapStateToProps,mapDispatchtoProps)(Brother2);
```

上面的代码中我们引入了bindActionCreators用于将quantifyAction文件中的多个action转化为bindActionCreators函数。

```html
<button type="button" onClick={()=>this.props.actionCreator.increment(10)}>增加数据</button>
<button type="button" onClick={()=>this.props.actionCreator.decrement(5)}>减少数据</button
```

我们在调用执行函数的时候就通过actionCreator.函数(参数)来完成参数的传递，以及多个action的合并操作。

## 四.课堂案例

### 1.redux+类组件方式实现购物车

1) store.js中

```js
import {createStore} from 'redux';

const store=createStore(redurce);

function redurce(state={
    shopcartList:[
        {id:1,name:'苹果',price:5.8,num:1},
        {id:2,name:'香蕉',price:3.8,num:1},
        {id:3,name:'葡萄',price:9.8,num:1}
    ]
},action){
    switch(action.type){
        case 'changeNum':
            state.shopcartList[action.index].num+=action.n;
            
            return{
                ...state,
                shopcartList:[...state.shopcartList]
            }
        default:
            return state;
    }
}
export const changeNumAc=(index,n)=>({
    type:"changeNum",
    index,
    n
})
export default store;
```

2）shopCart.js

```js
import React, {PureComponent} from 'react'
import { connect} from 'react-redux'
import {changeNumAc} from '../../store/store';

class ShopCart extends PureComponent {
    changeNum=(index,n)=>{
       this.props.dispatch(changeNumAc(index,n));
    }
    render() {
        const { list } = this.props;
        const total=list.reduce((t,cur)=>{
            return t+cur.num*cur.price;
        },0);
        return (
            <div>
                购物车
                <table style={{width:'100%'}}>
                    <thead>
                        <tr>
                            <th>名称</th>
                            <th>价格</th>
                            <th>数量</th>
                            <th>小计</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            list.map((item,index)=>{
                                return(
                                    <tr key={item.id}>
                                        <td>{item.name}</td>
                                        <td>{item.price}</td>
                                        <td>
                                            <button 
                                              onClick={()=>this.changeNum(index,-1)}>-                                               </button>
                                            {item.num}
                                            <button 
                                              onClick={()=>this.changeNum(index,1)}>+
                                            </button>
                                        </td>
                                        <td>{item.num*item.price}</td>
                                        <td>
                                            <button>删除</button>
                                        </td>
                                    </tr>
                                )
                            })
                        }
                    </tbody>
                </table>
                总价:{total}
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        list: state.shopcartList
    }
}
export default connect(mapStateToProps)(ShopCart)
```

其中注意，此组件继承了PureComponent

### 2.redux+函数组件方式实现购物车

```js
import React,{useMemo}from 'react'
import {useDispatch,useSelector} from 'react-redux'
import {changeNumAc} from '../../store/store'

export default function FunctionalShopCart() {
    const dispatch=useDispatch();
    const {list}=useSelector((state)=>{
        return{
            list:state.shopcartList
        }
    });
    const total=useMemo(() => {
        return list.reduce((t,cur)=>{
            return t+cur.price*cur.num;
        },0);
    }, [list]);
    function changeNum(index,n){
        dispatch(changeNumAc(index,n));
    }
    return (
        <div>
            <h2>购物车函数组件实现方式</h2>
            <table style={{ width: '100%' }}>
                <thead>
                    <tr>
                        <th>名称</th>
                        <th>价格</th>
                        <th>数量</th>
                        <th>小计</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        list.map((item, index) => {
                            return (
                                <tr key={item.id}>
                                    <td>{item.name}</td>
                                    <td>{item.price}</td>
                                    <td>
                                        <button onClick={() => changeNum(index, -1)}>-
                                            </button>
                                        {item.num}
                                        <button onClick={() => changeNum(index, 1)}>+
                                            </button>
                                    </td>
                                    <td>{item.num * item.price}</td>
                                    <td>
                                        <button>删除</button>
                                    </td>
                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>
            总价:{total}
        </div>
    )
}
```

### 3.redux+类组件方式实现todolist

ReduxTodolist.js

```js
import React, { Component } from 'react';
import {connect} from 'react-redux';
import './todolist.scss';
import {addTaskAc,toggleTaskStatusAc,changeCurBtnAc} from '../../store/store';
class ReduxTodolist extends Component {
    addTask=()=>{
        //获取文本框的内容
        const inputVal=this.inputInstance.value;
        this.props.dispatch(addTaskAc(inputVal));
    }
    toggleStatus=(event)=>{
        const dataId=event.target.getAttribute("data-id");
        this.props.dispatch(toggleTaskStatusAc(dataId));
    }
    clickBtn=(event)=>{
        const curBtn=event.target.getAttribute("data-btn");
        this.props.dispatch(changeCurBtnAc(curBtn));
    }
    get showedList(){
         const {list,curBtn}=this.props;
         switch(curBtn){
            case "all":
                return list;
            case "done":
                return list.filter(item=>item.status==="done");
            case "undone":
                return list.filter(item=>item.status==="undone");
         }   
    }
    render() {
        const {list,curBtn}=this.props;
        
        return (
            <div>
                <input placeholder="请输入任务" 
            			ref={input=>this.inputInstance=input}></input>
                <button onClick={this.addTask}>添加任务</button>
                <ul onClick={this.toggleStatus}>
                {
                    this.showedList.map((item,index)=>{
                        return(
                            <li data-id={item.id} key={item.id} className={item.status}>
                                {item.task}
                            </li>
                        )
                    })
                }
                </ul>
                <div onClick={this.clickBtn}>
                    <button data-btn="all" 
							className={curBtn==="all"?"activeBtn":""}>全部</button>
                    <button data-btn="done" 
                            className={curBtn==="done"?"activeBtn":""}>已完成</button>
                    <button data-btn="undone" 
							className={curBtn==="undone"?"activeBtn":""}>未完成</button>
                </div>
            </div>
        )
    }
}
const mapStateToProps=(state)=>{
    console.log('state',state);
    return{
        list:state.tasklist,
        curBtn:state.curBtn
    }
}
export default connect(mapStateToProps)(ReduxTodolist)
```

store.js

```js
import { createStore } from 'redux';

const store = createStore(redurce);

function redurce(state = {
    tasklist: [
        { id: 1, task: '学习react', status: 'undone' },
        { id: 0, task: '学习vue', status: 'done' }
    ],
    curBtn:"all"
}, action) {
    switch (action.type) {
        case "addTask":
            console.log('id', state.tasklist.length);
            state.tasklist.unshift({ id: state.tasklist.length, task: action.task, status: 'undone' });
            return {
                ...state,
                tasklist: [...state.tasklist]
            }
        case "toggleTaskStatus":
            console.log('dataId', action.dataId);
            state.tasklist.filter(item => item.id === Number(action.dataId))[0].status = state.tasklist.filter(item => item.id === Number(action.dataId))[0].status === "undone" ? "done" : "undone"
            return {
                ...state,
                tasklist: [...state.tasklist]
            }
        case "changeCurBtn":
            console.log('***',action.curBtn);
            state.curBtn=action.curBtn;
            console.log('&&&',state.curBtn);
            return{
                ...state,
                curBtn:{...state}.curBtn
            }
        default:
            return state;
    }
}
//添加任务的通知
export const addTaskAc = (val) => ({
    type: "addTask",
    task: val
})
//切换任务的状态
export const toggleTaskStatusAc = (val) => ({
    type: "toggleTaskStatus",
    dataId: val
})
//切换按钮的状态
export const changeCurBtnAc=(curBtn)=>({
    type:"changeCurBtn",
    curBtn
})
export default store;
```

### 4.redux+函数组件方式实现账号列表

AccountsFun()函数组件

```js
import React, {useEffect } from 'react'
import { Table, Button, Popconfirm } from 'antd';
import { getAccountListApi, delAccountApi } from '../../apis/users';
import moment from 'moment';
import AddModal from './components/AddModal'
import {useSelector,useDispatch} from 'react-redux'
import {changeLoadingAc,setAccountsDataAc,changeIsModalVisibleAc} from '../../store/store'

export default function AccountsFun() {
    const {data,total,loading,isModalVisible}=useSelector((state)=>({
        ...state.accounts
    }))
    const dispatch=useDispatch();
    useEffect(() => {
        getAccountList();
    }, []);
    async function getAccountList(params = { pageNumber: 1, pageSize: 10 }) {
        dispatch(changeLoadingAc(true))
        const { data, totalCount } = await getAccountListApi(params);
        dispatch(setAccountsDataAc(data,totalCount))
        dispatch(changeLoadingAc(false))
    }
    function onChange(pageNumber, pageSize) {
        getAccountList({ pageNumber, pageSize });
    }
    async function deleteAccount(record) {
        const result = await delAccountApi(record._id);
        console.log('result', result)
        //刷新页面
        getAccountList();
    }
    function delCancel() {

    }
    //显示弹框
    function showAccountModal() {
        dispatch(changeIsModalVisibleAc(true))
    }

    //单击取消按钮
    function hidenAccountModal() {
        dispatch(changeIsModalVisibleAc(false))
    }
    const columns = [
        {
            title: '账号',
            dataIndex: 'account'
        },
        {
            title: '角色',
            dataIndex: 'userGroup'
        },
        {
            title: '创建时间',
            dataIndex: 'createDate',
            render: (text) => {
                return moment(text).format('YYYY-MM-DD HH:mm:ss');
            }
        },
        {
            title: '操作',
            render: (text, record) => (
                <Popconfirm
                    title="您确定要删除吗?"
                    onConfirm={() => deleteAccount(record)}
                    onCancel={delCancel}
                >
                    <Button type="primary">删除</Button>
                </Popconfirm>
            ),
        },
    ];
    const pagination = {
        total: total,
        onChange: onChange
    }
    return (
        <div>

            <Button type="primary" onClick={showAccountModal}>添加账户</Button>
            <Table rowKey="_id" loading={loading} pagination={pagination} 
				   columns={columns} dataSource={data}></Table>
            { <AddModal
                isModalVisible={isModalVisible}
                hidenAccountModal={hidenAccountModal}
                afterOk={getAccountList}></AddModal>
            } 
        </div>
    )
}
```

store.js

```js
import { createStore } from 'redux';
const store = createStore(redurce);

function redurce(state = {
    accounts:{
        data:[],
        total:0,
        loading:false,
        isModalVisible:false
    }
}, action) {
    switch (action.type) {
        case "changeLoading":
            return{
                ...state,
                accounts:{
                    ...state.accounts,
                    loading:action.loading
                }
            }
        case "setAccountsData":
            return{
                ...state,
                accounts:{
                    ...state.accounts,
                    data:action.data,
                    total:action.total
                }
            }
        case "changeIsModalVisible":
            return{
                ...state,
                accounts:{
                    ...state.accounts,
                    isModalVisible:action.isModalVisible
                }
            }
        default:
            return state;
    }
}
export const changeNumAc = (index, n) => ({
    type: "changeNum",
    index,
    n
})
//添加任务的通知
export const addTaskAc = (val) => ({
    type: "addTask",
    task: val
})
//切换任务的状态
export const toggleTaskStatusAc = (val) => ({
    type: "toggleTaskStatus",
    dataId: val
})
//切换按钮的状态
export const changeCurBtnAc=(curBtn)=>({
    type:"changeCurBtn",
    curBtn
})
//账号列表
export const changeLoadingAc=(loading)=>({
    type:"changeLoading",
    loading,
})
export const setAccountsDataAc=(data,total)=>({
    type:"setAccountsData",
    data,total
})
export const changeIsModalVisibleAc=(isModalVisible)=>({
    type:"changeIsModalVisible",
    isModalVisible,
})
export default store;
```

## 五.reducer拆分

 当项目越来越大的时候，需要管理的数据也会越来越多，如果所有的数据都由一个reducer管理的话，则这个reducer肯定会变得非常的臃肿，且难以维护。所以有必要对reducer做一个拆分，不同功能模块的数据切片，由不同的reducer来管理。假设现在有两个模块，账户管理模块和商品管理模块，每个模块都有数据需要管理 

### 1.redurce拆分

```js
//管理账户模块数据切片的reducer
function accountsReducer(state = {}, action) {
      switch(action.type){
          //省略代码  
      }
    }
}
//管理购物车模块数据切片的reducer
function shopcartReduce(state = {}, action) {
     switch(action.type){
          //省略代码  
      }
}
//管理todolist模块的切片数据
function tasklistReduce(state = {}, action) {
   switch(action.type){
          //省略代码  
      }
}

//合并reducer
import {combineReducers} from 'redux';
//combineReducers执行过后会返回一个大的reducer,
const bigReducers  = combineReducers({
    //key(当前数据切片的名字):value（管理该数据切片的reducer）
    accounts:accountsReducer,
    shopcart:shopcartReduce,
    tasklist:tasklistReduce
})
//把bigReducer传入createStore
const store = createStore(bigReducers)
```

注意：调用时候需要使用使用到切片的名字才能访问到，比如

AccountsFun.js

```js
export default function AccountsFun() {
    const {data,total,loading,isModalVisible}=useSelector((state)=>({
        ...state.accounts.accounts    //...state.切片的key.accounts
    }))
```

ReduxTodolist.js

```js
const mapStateToProps=(state)=>{
    console.log('state',state);
    return{
        list:state.tasklist.tasklist,  //state.切片的key.tasklist
        curBtn:state.tasklist.curBtn
    }
}
```

shopcart.js

```js
export default function FunctionalShopCart() {
    const dispatch=useDispatch();
    const {list}=useSelector((state)=>{
        return{
            list:state.shopcart.shopcartList //state.切片的key.shopcartList
        }
});
```

### 2.文件拆分-扩展

如上将store.js中的redurce分成多个函数，在一定程度上使得程序结构变得清晰一些，但是store,redurce,action还是在一个文件上，在实际开发过程中应该将redurce、action,store分开

2.1 在store下创建reducer文件,按照功能分别创建accountsReducer.js、shopCartReducer.js、todolistReducer.js

```js
export default function accountsReducer(state = {
   //忽略代码
}
```

```js
export default function shopcartReduce(state = {
  //忽略代码
}
```

```js
export default function tasklistReduce(state = {
   //忽略代码
}
```

在store下创建index.js将这些代码汇总在一起

```js
import {combineReducers} from 'redux';
import accountsReducer from './accountsReducer';
import shopcartReduce from './shopcartReduce';
import tasklistReduce from './tasklistReduce';

export default combineReducers({
    accounts:accountsReducer,
    shopcart:shopcartReduce,
    tasklist:tasklistReduce
});
```

2.2 在store下创建action文件,按照功能分别创建accountsActions.js、shopCartActions.js、todolistActions.js

accountsActions.js

```js
//账号列表
export const changeLoadingAc = (loading) => ({
    type: "changeLoading",
    loading,
})
export const setAccountsDataAc = (data, total) => ({
    type: "setAccountsData",
    data, total
})
export const changeIsModalVisibleAc = (isModalVisible) => ({
    type: "changeIsModalVisible",
    isModalVisible,
})
```

shopCartActions.js

```js
export const changeNumAc = (index, n) => ({
    type: "changeNum",
    index,
    n
})
```

todolistActions.js

```js
//添加任务的通知
export const addTaskAc = (val) => ({
    type: "addTask",
    task: val
})
//切换任务的状态
export const toggleTaskStatusAc = (val) => ({
    type: "toggleTaskStatus",
    dataId: val
})
//切换按钮的状态
export const changeCurBtnAc = (curBtn) => ({
    type: "changeCurBtn",
    curBtn
})
```

在store/actions文件夹下创建index.js

```js
export {changeLoadingAc,setAccountsDataAc,changeIsModalVisibleAc} from './accountsActions';
export {changeNumAc} from './shopCartActions';
export {addTaskAc,toggleTaskStatusAc,changeCurBtnAc} from './todolistActions';
```

2.3 修改store/store.js

```js
import { createStore,combineReducers} from 'redux';
import bigReduces from './reducer/index';
const store = createStore(bigReduces);
export default store;
```

2.4 在需要通知的组件中引入，这里要改成store/actions/index.js文件的路径

```js
import {changeLoadingAc,setAccountsDataAc,changeIsModalVisibleAc} from '../../store/actions/index'
```

```js
import {changeNumAc} from '../../store/actions/index'
```

```js
import {addTaskAc,toggleTaskStatusAc,changeCurBtnAc} from '../../store/actions/index';
```

2.5  新建actionTypes.js

该文件中存放action通知的类型，将类型以常量的形式提供

```js
export const changeLoading="changeLoading";
export const setAccountsData="setAccountsData";
export const changeIsModalVisible="changeIsModalVisible";
export const changeNum="changeNum";
export const addTask="addTask";
export const toggleTaskStatus="toggleTaskStatus";
export const changeCurBtn="changeCurBtn";
```

在具体的action文件中引入

```js
import * as myTypes from '../actionTypes';
//账号列表
export const changeLoadingAc = (loading) => ({
    type: myTypes.changeLoading,
    loading,
})
export const setAccountsDataAc = (data, total) => ({
    type: myTypes.setAccountsData,
    data, total
})
export const changeIsModalVisibleAc = (isModalVisible) => ({
    type: myTypes.changeIsModalVisible,
    isModalVisible,
})
```

```js
import * as myTypes from '../actionTypes';
export const changeNumAc = (index, n) => ({
    type: myTypes.changeNum,
    index,
    n
})
```

```js
import * as myTypes from '../actionTypes';
//添加任务的通知
export const addTaskAc = (val) => ({
    type: myTypes.addTask,
    task: val
})
//切换任务的状态
export const toggleTaskStatusAc = (val) => ({
    type: myTypes.toggleTaskStatus,
    dataId: val
})
//切换按钮的状态
export const changeCurBtnAc = (curBtn) => ({
    type: myTypes.changeCurBtn,
    curBtn
})

```

## 六.课堂案例

### 1.redux实现登录信息的同步更新

**1.1 头部获取用户信息**

![1611192424482](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1611192424482.png)

用户登录后进入后台首页面，头部栏部分获取用户信息（用户名和头像），这些信息是用户登录后保存到状态机中，然后从状态机获取的信息，要想实现如上效果，具体实现步骤如下

1）定义reducer函数

在store/reducer文件夹下创建profileReducer.js

```js
export default function profileRedurce(state={
    account:'',
    imgUrl:''
},action){
    switch(action.type){
        case "saveUserInfo":
            console.log('userInfo...',action.userInfo);
            return{
                ...state,
                account:action.userInfo.account,
                imgUrl:action.userInfo.imgUrl
            }
        default:
            return state;
    }
}
```

在store/reducer/index.js中合并profileRedurce

```js
import {combineReducers} from 'redux';
import accountsReducer from './accountsReducer';
import shopcartReduce from './shopcartReduce';
import tasklistReduce from './tasklistReduce';
import profileRedurce from './profileReducer'

export default combineReducers({
    accounts:accountsReducer,
    shopcart:shopcartReduce,
    tasklist:tasklistReduce,
    userInfo:profileRedurce  //合并redurce
});
```

2)创建action creator

在store/actions文件夹下创建profileActions.js

```js
import * as myTypes from '../actionTypes';
export const saveUserInfoAc=(userInfo)=>{
   return{
        type:myTypes.saveUserInfo,
        userInfo,
   }
}
```

在actionTypes.js中添加常量saveUserInfo

```js
export const saveUserInfo="saveUserInfo";
```

在store/actions/index.js中添加如下代码

```js
export {saveUserInfoAc} from './profileActions'
```

3）用户登录方法中，当用户登录成功后，再跳转之前保存用户信息到localStorage和状态机中

```js
onFinish = (values) => {
        loginApi(values)
       .then((res)=>{
          this.setState({loading:true});
          this.setState({loading:false});
          const {token,userInfo} = res;
          localStorage.setItem('token',token);
          localStorage.setItem('userInfo',JSON.stringify(userInfo));
          //保存userInfo到redux状态机中
          this.props.dispatch(saveUserInfoAc(userInfo));
          this.props.history.push('/nav/index');
       }).catch((err)=>{
           console.log('err',err);
       });
    };
```

当然一定要保证这个Login.js类组件是被高阶函数connect函数处理过的，否则this.proops中将没有dispatch(),所以在使用之前务必完成如下操作

```js
import {connect} from 'react-redux';
class Login extends Component {
    //省略
}
export default connect()(Login);
```

4）MyHeader.js中获取状态机中的用户信息(用户名和图片信息)

```js
render() {
        const {userInfo}=this.props;
        return (
            <React.Fragment>
                <Header>
                    <Menu theme="dark" mode="horizontal">
                        <Menu.Item key="person-center1">
                            <span style={{color:'#fff'}}>欢迎{userInfo.account}登录</span>
                        </Menu.Item>
                        <Menu.Item key="person-center2">
                        <img style={{width:40,height:40,borderRadius:20}} 
                             src={"http://jacklv.cn/images/"+userInfo.imgUrl}></img>
                        </Menu.Item>
                    </Menu>
                </Header>
           
            </React.Fragment>
        )
    }
```

**1.2 修改用户图像和名称顶部栏信息同步**

在pages/userCenter/UserCenter.js文件的修改图片的方法中添加

```js
 onFinish = async(values) => {
        console.log('values',values);
        const params={
            account:values.account,
            userGroup:values.userGroup,
        }
        if(values.imgUrl[0].response){   
            params.imgUrl=values.imgUrl[0].response.data;
        }else{
            params.imgUrl=values.imgUrl[0].uid;
        }
        const data=await saveUserInfoApi(params);
        //保存用户信息到状态机
        this.props.dispatch(saveUserInfoAc({account:data.account,imgUrl:data.imgUrl}));
        //本地存储
        localStorage.setItem("userInfo",
                             JSON.stringify({account:data.account,imgUrl:data.imgUrl}));  
    }
```

当然一定要保证这个UserCenter.js类组件是被高阶函数connect函数处理过的，否则this.proops中将没有dispatch(),所以在使用之前务必完成如下操作

```js
import {connect} from 'react-redux';
class UserCenter extends Component {
    //省略
}
export default connect()(UserCenter);
```

**1.3 刷新页面用户图像和信息不丢失**

由于状态机中的数据不是持久化的，所以当用户刷新页面的时候会发现丢失，这是因为之前定义redurce初始信息的时候，设置的是空字符串值，如下所示

```js
export default function profileRedurce(state={
    account:'',
    imgUrl:''
},action){
    switch(action.type){
        case "saveUserInfo":
            console.log('userInfo...',action.userInfo);
            return{
                ...state,
                account:action.userInfo.account,
                imgUrl:action.userInfo.imgUrl
            }
        default:
            return state;
    }
}
```

所以当页面加载的时候，需要从localStorage中获取，所以我们需要在MyHeader.js中添加如下代码

```js
componentDidMount(){
     const userInfo=JSON.parse(localStorage.getItem("userInfo"));
  	 this.props.dispatch(
        saveUserInfoAc({account:userInfo.account,imgUrl:userInfo.imgUrl}));
    }
```

### 2.redux完整版的购物车+后端接口方式

1）在apis/shopcart.js

```js
import axios from 'axios';
axios.defaults.baseURL="http://jacklv.cn";
export const getshopcartListApi=()=>axios.get("/shopcart/getShopcartData");
export const changeNumApi=(params)=>axios.post("/shopcart/changeNum",params);
export const checkProductApi=(_id)=>axios.get('/shopcart/checkProducts?_id='+_id);
```

2) 在store/reducer/shopcartReduce.js

```js
export default function shopcartReduce(state = {
    shopcartList: [
    ]
}, action) {
    switch (action.type) {
        case 'changeNum':
            state.shopcartList[action.index].num += action.n;
            return {
                ...state,
                shopcartList: [...state.shopcartList]
            }
        case 'getShopCarList':
            return {
                ...state,
                shopcartList: action.shopcartlist
            }
        default: return state;
    }
}
```

3）在store/actions/shopCartActions.js

```js
import * as myTypes from '../actionTypes';
export const changeNumAc = (index, n) => ({
    type: myTypes.changeNum,
    index,
    n
})
export const getShopCarListAc=(shopcartlist)=>({
    type:myTypes.getShopCarList,
    shopcartlist,
})
```

4）在store/actions/index.js

```js
export {changeNumAc,getShopCarListAc} from './shopCartActions';
```

5）NewShopCart.js（关键代码）

```js
import React,{useEffect,useMemo} from 'react'
import {useSelector,useDispatch} from 'react-redux'
import {getshopcartListApi,changeNumApi,checkProductApi} from '../../apis/shopcart';
import {getShopCarListAc} from '../../store/actions/index'


export default function NewShopCart() {
    const dispatch=useDispatch();
    const list=useSelector((state)=>{
        return state.shopcart.shopcartList;
    });
    useEffect(()=>{
       getShopCartList();
    },[]);

    async function getShopCartList(){
        const list=await getshopcartListApi();
        dispatch(getShopCarListAc(list));
    }
    async function changeNum(_id,n){
        const params={
            _id,n
        }
        const list=await changeNumApi(params);
        getShopCartList();
    }
    //勾选复选框时触发
    async function checkItem(_id){
        console.log('_id',_id);
        const result=await checkProductApi(_id);
        getShopCartList();
    }
    const total=useMemo(() => {
        return list.filter(item=>item.checked===true).reduce((t,cur)=>t+cur.price*cur.num,0);
    }, [list]);
    return (
        <div>
            <h2>完整版购物车</h2>
            <table style={{width:'100%'}}>
                    <thead>
                        <tr>
                            <th><input type="checkbox"/></th>
                            <th>名称</th>
                            <th>价格</th>
                            <th>数量</th>
                            <th>小计</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            list.map((item,index)=>{
                                return(
                                    <tr key={item._id}>
                                        <td>
                                            <input 
												onChange={()=>checkItem(item._id)} 
												type="checkbox" 
												checked={item.checked}></input>
                                        </td>
                                        <td>{item.name}</td>
                                        <td>{item.price}</td>
                                        <td>
                                            <button 
												onClick={()=>changeNum(item._id,-1)}>-
    										</button>
                                            {item.num}
                                            <button onClick={()=>changeNum(item._id,1)}>+											 </button>
                                        </td>
                                        <td>{item.num*item.price}</td>
                                        <td>
                                            <button>删除</button>
                                        </td>
                                    </tr>
                                )
                            })
                        }
                    </tbody>
                </table>
                总价:{total}
        </div>
    )
}
```

## 七.redux中间件

 不使用中间件时，数据的修改流程：每当我们调用dispatch方法的时候，传递给dispatch的实参action通知对象，就会立即reducer函数接收，并执行reducer函数体内的代码，达到修改数据的目的。 

![1609395735786](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1609395735786.png)

 使用中间件时，数据的修改流程： 

![1609395762582](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1609395762582.png)

 由上图我们可以知道，如果使用了中间件，则从我们发起dispatch开始，传入其中的action对象，并不是直接交给reducer处理的，而是先经过了若干中间件链式处理过后，最后再由reducer处理。所以我们可以变相的认为redux中间就是强化dispatch方法的一种机制 

 使用中间件的好处：使用中间件可以对经过中间件的数据流做任何处理，非常灵活，比如让dispatch方法可以接受函数作为参数、或者每次执行dispatch方法的时候，打印出数据变化的日志。 

常用中间件

-  redux-thunk的作用：让dispatch方法能够接受函数作为参数 
-  redux-logger的作用：每次dispatch触发数据更新的时候，在控制台打印数据变化前后的值，该中间件只会在开发环境会用，生产环境不会用 

 接下来我们看一下，如何在项目里面集成这两个中间件 

 1）下载安装redux-thunk redux-logger 

```bash
yarn add redux-thunk redux-logger
```

2） 在创建store的时候配置redux中间件 

```js
import {createStore,applyMiddleware} from 'redux'
import thunk from 'redux-thunk'
import logger from 'redux-logger'
export default createStore(reducer,applyMiddleware(thunk,logger));
```

3） 使用中间件redux-thunk提供的的特性，即dispatch可以接受一个函数作为参数 

如上操作只要是执行了dispatcher操作，都会在控制台打印日志信息，如下所示

![1611199524447](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1611199524447.png)



## 八.课堂案例

### 1.使用redux-thunk中间件改造购物车功能

1）在shopCartActions.js中，定义action creator函数的返回值为函数，这样的函数可以做业务逻辑

```js
import * as myTypes from '../actionTypes';
import {getshopcartListApi,changeNumApi,checkProductApi} from '../../apis/shopcart';
export const changeNumAc = (index, n) => ({
    type: myTypes.changeNum,
    index,
    n
})
//返回值是对象
export const getShopCarListAc=(shopcartlist)=>({
    type:myTypes.getShopCarList,
    shopcartlist,
})
//返回值都是函数
export const getShopCartListFAc=()=>async(dispatch,getState)=>{
    const list=await getshopcartListApi();
    dispatch(getShopCarListAc(list));
}
//返回值都是函数
export const changeNumFAc=(_id,n)=>async(dispatch,getState)=>{
    const params={
        _id,n
    }
    await changeNumApi(params);
    dispatch(getShopCartListFAc());
}
//返回值都是函数
export const checkItemFAc=(_id)=>async(dispatch,getState)=>{
    await checkProductApi(_id);
    dispatch(getShopCartListFAc());
}
```

2）将这些action creator暴露出去

```js
export {getShopCartListFAc,changeNumFAc,checkItemFAc} from './shopCartActions';
```

3）购物车函数组件

```js
import React,{useEffect,useMemo} from 'react'
import {useSelector,useDispatch} from 'react-redux'
import {changeNumFAc,getShopCartListFAc,checkItemFAc} from '../../store/actions/index'


export default function NewShopCart() {
    const dispatch=useDispatch();
    const list=useSelector((state)=>{
        return state.shopcart.shopcartList;
    });
    useEffect(()=>{
       dispatch(getShopCartListFAc());
    },[]);

    async function changeNum(_id,n){
        dispatch(changeNumFAc(_id,n));
    }
    //勾选复选框时触发
    async function checkItem(_id){
        dispatch(checkItemFAc(_id));
    }
    const total=useMemo(() => {
        return list.filter(item=>item.checked===true).reduce((t,cur)=>t+cur.price*cur.num,0);
    }, [list]);
    return (
        <div>
            <h2>完整版购物车</h2>
            <table style={{width:'100%'}}>
                    <thead>
                        <tr>
                            <th><input type="checkbox"/></th>
                            <th>名称</th>
                            <th>价格</th>
                            <th>数量</th>
                            <th>小计</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            list.map((item,index)=>{
                                return(
                                    <tr key={item._id}>
                                        <td>
                                            <input onChange={()=>checkItem(item._id)} 													   type="checkbox" 
												   checked={item.checked}></input>
                                        </td>
                                        <td>{item.name}</td>
                                        <td>{item.price}</td>
                                        <td>
                                            <button 
											   onClick={()=>changeNum(item._id,-1)}>-	
                                             </button>
                                            {item.num}
                                            <button onClick={()=>changeNum(item._id,1)}>+											 </button>
                                        </td>
                                        <td>{item.num*item.price}</td>
                                        <td>
                                            <button>删除</button>
                                        </td>
                                    </tr>
                                )
                            })
                        }
                    </tbody>
                </table>
                总价:{total}
        </div>
    )
}
```

## 九.redux-saga

### 1.redux-thunk和redux-saga比较

1.1 共同点:都是处理异步的，可以提取某些公共逻辑

1.2 不同点：

- redux-thunk更加简单，但是功能比较少(redux-thunk让action这个概念变得不是那么纯粹--action creator)

- redux-saga用起来稍显复杂，但是功能更强大

1.3 取舍：

如果需要有复杂的数据管理功能，推荐用redux-saga,否则用redux-thunk，并且一般在项目中我们只会二选其一，不会两个同时使用

### 2.redux-saga的使用

这里使用redux-saga改造之前的购物车功能

2.1 安装redux-saga

```bash
yarn add redux-saga
```

2.2 在store/store.js

```js
import { createStore,applyMiddleware} from 'redux';
import bigReduces from './reducer/index';
import createSagaMiddleware from 'redux-saga';
import saga from './sagas/index';

const sagaMiddleware=createSagaMiddleware();//创建saga中间件

const store = createStore(bigReduces,applyMiddleware(sagaMiddleware));
sagaMiddleware.run(saga);
export default store;
```

2.3 store/saga/index.js

第一种写法

```js
import {call,put,takeEvery,all} from 'redux-saga/effects';
import * as myTypes from '../actionTypes';
import {getshopcartListApi,changeNumApi,checkProductApi} from '../../apis/shopcart'

function* getShopCartList(){
    const data=yield call(getshopcartListApi);    
    yield put({type:myTypes.getShopCarList,shopcartlist:data});
}
function* changeNum(action){
    const {_id,n}=action;
    yield call(changeNumApi,{_id,n});
    yield put({type:myTypes.watchSetShopcartData});
}
function* checkItem(action){
    const {_id}=action;
    yield call(checkProductApi,_id);
    yield put({type:myTypes.watchSetShopcartData});
}

export default function* index(){
    yield takeEvery(myTypes.watchcheckItem,checkItem);
    yield takeEvery(myTypes.watchChangeNum,changeNum);
    yield takeEvery(myTypes.watchSetShopcartData,getShopCartList);
}
```

第二种写法

```js
import {call,put,takeEvery,all} from 'redux-saga/effects';
import * as myTypes from '../actionTypes';
import {getshopcartListApi,changeNumApi,checkProductApi} from '../../apis/shopcart'

function* getShopCartList(){
    const data=yield call(getshopcartListApi);    
    yield put({type:myTypes.getShopCarList,shopcartlist:data});
}
function* changeNum(action){
    const {_id,n}=action;
    yield call(changeNumApi,{_id,n});
    yield put({type:myTypes.watchSetShopcartData});
}
function* checkItem(action){
    const {_id}=action;
    yield call(checkProductApi,_id);
    yield put({type:myTypes.watchSetShopcartData});
}
function* watchCheckItem(){
    yield takeEvery(myTypes.watchcheckItem,checkItem);
}

function* watchChangeNum(){
    yield takeEvery(myTypes.watchChangeNum,changeNum);
}
function* watchGetShopCartList(){
    yield takeEvery(myTypes.watchSetShopcartData,getShopCartList);
}
export default function* rootSaga(){
    yield all([
        call(watchChangeNum),
        call(watchGetShopCartList),
        call(watchCheckItem)
    ])
}
```

actionTypes中增加watchSetShopcartData

```js
export const watchSetShopcartData="watchSetShopcartData";
export const watchChangeNum="watchChangeNum";
export const watchcheckItem="watchcheckItem";
```

3）在NewsShopcart.js

```js
import React,{useEffect,useMemo} from 'react'
import {useSelector,useDispatch} from 'react-redux'
import * as myTypes from '../../store/actionTypes';

export default function NewShopCart() {
    const dispatch=useDispatch();
    const list=useSelector((state)=>{
        return state.shopcart.shopcartList;
    });
    useEffect(()=>{
       //使用redux-saga
       dispatch({type:myTypes.watchSetShopcartData});
    },[]);
    async function changeNum(_id,n){
        //使用redux-saga
        dispatch({type:myTypes.watchChangeNum,_id,n});
    }
    //勾选复选框时触发
    async function checkItem(_id){
        //使用redux-saga
        dispatch({type:myTypes.watchcheckItem,_id});
    }
    const total=useMemo(() => {
        return list.filter(item=>item.checked===true).reduce((t,cur)=>t+cur.price*cur.num,0);
    }, [list]);
    return (
        <div>
            <h2>完整版购物车</h2>
            //省略代码
        </div>
    )
}
```

## 十.Generator

