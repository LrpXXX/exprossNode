## Hooks

### 1.函数组件和类组件区别

 在react16.8以前函数组件只能被动接收外部数据，并且没有自己的生命周期钩子函数，函数内部也没有this可用 

### 2.hook的由来和作用

react16.8以后的新特性Hooks函数组件在react16.8以前函数组件只能被动接收外部数据，并且没有自己的生命周期钩子函数，函数内部也没有this可用新特性Hookhook推出的动机主要是因为类组件有一下几个不足 

-  组件之间复用公共逻辑比较麻烦，以前常见的提取组件公共逻辑的方式有高阶组件/renderProps等，但这些方式或多或少都对原有组件的代码组织方式有一定的破坏性 
-  复杂组件变得难以理解（例如相同的逻辑可能要写在不同的生命周期钩子函数里面） 
-  难以理解的class（比如对新手来见，class组件中的this不太好理解） 

 新特性hook出现之后，函数组件就可以完全替代类组件，但是这并不是说react官方会抛弃类组件，react官方文档中也表明了没有计划会在react中移除class组件。 

 注意：hook特性只能在函数组件中使用 

### 函数组件外部数据

```js
import React from 'react'
/**
 * 函数组件获取到外部数据props
 * @returns 
 */
export default function Demo01(props) {
    // 定义事件函数
    function updateProps(){
        // 在函数组件中，对于外部数据props只读
        // 修改会出现异常
        props.username="xiaofei";
    }
    return (
        <div>
            <p>
                {props.username}
            </p>
            <p>
                {props.age}
            </p>
            <p>
                {props.address}
            </p>
            <button onClick={updateProps}>点击修改</button>
        </div>
    )
}

```

对于函数组件来说，我们可以在函数参数里面获取到props，这个对象也是只读属性。

```js
// 函数组件也可以设置默认值
Demo01.defaultProps = {
    price: ['React', 'Vue']
}
```

我们也可以在函数组件中设置默认值。

### 3.hook之useState

外部组件

```js
import React from 'react'
import UserState from './userState';

export default function HookDemo() {
    return (
        <div>
            <UserState msg="hi msg"></UserState>
        </div>
    )
}
```

内部组件

```js
import React,{useState} from 'react'

export default function UserState({msg}) {
    /**
     * 定义内部数据使用
     * const[名称,改变数据的方法] =useState(数据)
     */
    const [name,setName]= useState('张三');
    const[obj,setObj]=useState({sex:'男'});
    
    function changeData(){
        setName('王二麻子');
        //改变内部数据的方式1
        /*
        obj.sex="女";
        setObj({
            ...obj,
        })
        */
       setObj((sex)=>{
         return{
             sex:'女'
         }
       });
    }
    return (
        <div>
            <div>
                外部数据:{msg}
            </div>
            <div>
                <div>
                    内部数据(基本类型):{name}
                </div>
                <div>
                    内部数据(引用类型):{obj.sex}
                </div>
                <button onClick={changeData}>改变内部数据</button>
            </div>
        </div>
    )
}
```

>useState总结：
>
>1. useState不适合复杂对象的更改，因为useState不能像setState那样进行合并更新，当使用useState第二个参数进行数据更新的时候，必须传入一个完整的结构，而不仅仅只是改变的那一部分
>2. useState异步回调的问题：当使用usestate对数据进行更新，并不能立刻获取到最新的数据

### 4.hook之useEffect

useEffect的作用是让函数组件具有自己的生命周期钩子函数 

useEffect可以看作是class组件中componentDidMount/componentDidUpdate/componentWillUnmount三个生命周期钩子函数的结合体 

useEffect可以接受两个参数，第一个参数是一个回调函数，这个函数，我们现在给他取个名字叫effect函数，这个effect函数里面还可以返回一个函数，我们暂时叫它清除函数，第二个参数是一个数组，表示当前useEffect的依赖项

 注意：以上三个俗语：effect函数、清除函数、依赖项，后续我们会用到，请记住各自代表的内容 

 4.1 当useEffect的依赖项传递的是一个空数组时，它就相当于componentDidMount,即effect函数仅会在DOM初始化渲染完毕之后执行一次 

```js
import React,{useEffect} from 'react'

export default function useEffectDemo() {
    useEffect(()=>{
        console.log('useEffect依赖项传递为[]数组----->componentDidMounted')
    },[]);
    return (
        <div>
            UseEffect
        </div>
    )
}
```

4.2  useEffect的依赖项，如果不传递，则effect函数，会在每次界面更新（包括初始渲染后）的时候执行，如果第依赖项传递了有限个依赖，则该函数仅仅会在这些依赖项发生变化时执行。（这种情况下useEffect就相当于componentDidMount和componentDidUpdate的结合体） 

```js
import React,{useEffect,useState} from 'react'

export default function useEffectDemo() {
    const[count,setCount]=useState(0);
    const[name,setName]=useState('张三');
    useEffect(()=>{
        console.log('useEffect依赖项传递为[]数组----->componentDidMounted')
    },[]);
    useEffect(()=>{
      console.log('useEffect依赖项没有------->componentDidUpdate'); 
    });
    useEffect(()=>{
        console.log('useEffect依赖项中带有name------->componentDidUpdate'+name); 
    },[name]);
    function addCount(){
        setCount((count)=>count+1);
    }
    function changeName(){
        setName("李四");
    }
    return (
        <div>
            {count} 
            <button onClick={addCount}>+1</button>
            <button onClick={changeName}>修改名字</button>
        </div>
    )
}
```

4.3  清除函数会在组件卸载的时候，以及effect函数执行（当然effect函数首次执行除外，因为这时清除函数还没有被返回呢！）之前执行

1）依赖项为空数组时

```js
import React,{useEffect,useState} from 'react'

export default function useEffectDemo2() {
    const [count,setCount] =useState(0);
    useEffect(()=>{
        console.log('useEffect依赖项传递为[]数组----->componentDidMounted')
        let timer=setInterval(()=>{
            setCount((count)=>count+1);
        },1000);
        return ()=>{
            console.log('清除函数执行了');
            clearInterval(timer);
        }
    },[]);//如果依赖项传递的是空数组，则effect函数只会执行一次，并且在组件卸载的时候，清除函数会执行一次
    return (
        <div>
            {count}
        </div>
    )
}
```

2）依赖项如果不传递或者在传递的数组中指定数据项

```js
import React,{useEffect,useState} from 'react'

export default function useEffectDemo2() {
   const [count,setCount] =useState(0);
   useEffect(()=>{
    console.log('useEffect依赖项中带有count------->componentDidUpdate'); 
    let timer=setInterval(()=>{
        setCount((count)=>count+1);
    },1000);
    return ()=>{
        console.log('清除函数执行了');
        clearInterval(timer);
    }
});//如果不传，则每次count改变清除函数和effect函数都会执行
    return (
        <div>
            {count}
        </div>
    )
}
```

或者

```js
import React,{useEffect,useState} from 'react'

export default function useEffectDemo2() {
   const [count,setCount] =useState(0);
   useEffect(()=>{
    console.log('useEffect依赖项中带有count------->componentDidUpdate'+count); 
    let timer=setInterval(()=>{
        setCount((count)=>count+1);
    },1000);
    return ()=>{
        console.log('清除函数执行了');
        clearInterval(timer);
    }
},[count]);
    return (
        <div>
            {count}
        </div>
    )
}
```



### 5.hook之useMemo

 useMemouseMemo的作用类似vue中的计算属性computed,即根据母体数据衍生出新的数据，一旦母体数据发生变化，则useMemo会自动执行

useMemo的第一个参数，必须有一个返回值，就像computed必须有返回值一样，并且在useMemo的第二个参数，也就是他的依赖项中，必须传递当前useMemo计算所依赖的数据（母体数据），useMemo执行过后会返回一个值，该值即使第一个参数（函数）执行过后的返回值，每当依赖项发生变化，该函数都会重新执行，useMemo返回值也就被更新了

 注意：useMemo的依赖项必须传递，否则，每个更新界面的时候useMemo都会重新计算，影响性能 

```js
import React,{useState,useMemo} from 'react'

export default function useMemoDemo() {
    const [firstName,setFirstName]=useState('张');
    const [lastName,setLastName]=useState('三');
    const name=useMemo(()=>{
        return firstName+""+lastName;
    },[firstName,lastName]);
    function changeFirstName(){
        setFirstName('赵');
    }
    return (
        <div>
            {name}
            <button onClick={changeFirstName}>修改姓</button>
        </div>
    )
}
```

### 6.hook之useRef

函数组件获取到文本框的值

```jsx
import React from 'react'

export default function Demo07() {
    function getData(){
        console.log(Demo07.InputElement.value);
    }
    return (
        <div>
            <input ref={node=>Demo07.InputElement=node} type="text"/>
            <button onClick={getData}>获取值</button>
        </div>
    )
}

```

第二种方式

```js
import React,{useRef} from 'react'

export default function useRefDemo() {
    const myInputRef=useRef(null);
    function getVal(){
        const val=myInputRef.current.value;
        console.log(val);
    }
    return (
        <div>
            <input ref={myInputRef}></input>
            <button onClick={getVal}>获取文本框数据</button>
        </div>
    )
}
```

### 7.使用hook实现购物车功能

```js
import React, { useState, useEffect,useMemo} from 'react'

export default function ShopCart() {
    const [list, setList] = useState([]);
    useEffect(() => {
        setTimeout(() => {
            setList([
                { name: '苹果', price: 5.8, num: 1 },
                { name: '香蕉', price: 3.8, num: 2 },
                { name: '葡萄', price: 9.5, num: 3 }
            ]);
        }, 1000);
    }, []);
    //实现计算属性的功能，当母数据变化以后随之变化
    const total=useMemo(()=>{
        return list.reduce((pre,next)=>{
            return pre+next.price*next.num;
        },0);
    },[list]);
    function changeNum(index, n) {
        list[index].num += n;
        //setList([...list]);
        setList((list)=>{
            list[index].num+=n;
            return [...list];
        });
    }
    return (
        <div>
            <table style={{ width: '100%' }}>
                <thead>
                    <tr>
                        <th>名称</th>
                        <th>价格</th>
                        <th>数量</th>
                        <th>小计</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        list.map((item, index) => {
                            return <tr key={index}>
                                <td>{item.name}</td>
                                <td>{item.price}</td>
                                <td>
                                    <button onClick={() => changeNum(index, -1)}>-
                                        </button>
                                    {item.num}
                                    <button onClick={() => changeNum(index, 1)}>+
                                        </button>
                                </td>
                                <td>
                                    {item.price * item.num}
                                </td>
                                <td>
                                    <button>删除</button>
                                </td>
                            </tr>
                        })
                    }
                </tbody>
            </table>
            总计：{total}
        </div>
    )
}
```

### 8.使用hook改造账户管理

AccountsFun

```js
import React, { Component, useState, useEffect } from 'react'
import { Table, Button, Popconfirm } from 'antd';
import { getAccountListApi, delAccountApi } from '../../apis/users';
import moment from 'moment';
import AddModal from './components/AddModal'

export default function AccountsFun() {
    const [data, setData] = useState([]);
    const [total, setTotal] = useState(0);
    const [loading, setLoading] = useState(false);
    const [isModalVisible, setIsModalVisible] = useState(false);
    useEffect(() => {
        getAccountList();
    }, []);
    async function getAccountList(params = { pageNumber: 1, pageSize: 10 }) {
        setLoading(true);
        const { data, pageSize, pageNumber, totalCount } = await getAccountListApi(params);
        console.log('data', data);
        setData([...data]);
        setTotal(totalCount);
        setLoading(false);
    }
    function onChange(pageNumber, pageSize) {
        getAccountList({ pageNumber, pageSize });
    }
    async function deleteAccount(record) {
        const result = await delAccountApi(record._id);
        console.log('result', result)
        //刷新页面
        getAccountList();
    }
    function delCancel() {

    }
    //显示弹框
    function showAccountModal() {
        setIsModalVisible(true);
    }

    //单击取消按钮
    function hidenAccountModal() {
        setIsModalVisible(false);
    }
    const columns = [
        {
            title: '账号',
            dataIndex: 'account'
        },
        {
            title: '角色',
            dataIndex: 'userGroup'
        },
        {
            title: '创建时间',
            dataIndex: 'createDate',
            render: (text) => {
                return moment(text).format('YYYY-MM-DD HH:mm:ss');
            }
        },
        {
            title: '操作',
            render: (text, record) => (
                <Popconfirm
                    title="您确定要删除吗?"
                    onConfirm={() => deleteAccount(record)}
                    onCancel={delCancel}
                >
                    <Button type="primary">删除</Button>
                </Popconfirm>
            ),
        },
    ];
    const pagination = {
        total: total,
        onChange: onChange
    }
    return (
        <div>

            <Button type="primary" onClick={showAccountModal}>添加账户</Button>
            <Table rowKey="_id" loading={loading} pagination={pagination} columns={columns} dataSource={data}></Table>
            <AddModal
                isModalVisible={isModalVisible}
                hidenAccountModal={hidenAccountModal}
                afterOk={getAccountList}></AddModal>
        </div>
    )
}
```

AddModalFun

```js
import React, { Component,useState,useRef} from 'react';
import { Modal, Form, Input, Select, Spin } from 'antd';
import { addAccountApi } from '../../../apis/users';
import MyPropTypes from 'prop-types';
const Option = Select.Option;

export default function AddModalFun({isModalVisible=false,hidenAccountModal=() => { },afterOk=() => { }}) {
    //规则设置
    AddModalFun.defaultProps={
        isModalVisible: MyPropTypes.bool,
        hidenAccountModal: MyPropTypes.func,
        afterOk: MyPropTypes.func
    }
    const[spingloading,setSpingloading]=useState(false);
    //完成表单提交
    async function onFinish(values){
        console.log('values', values);
        setSpingloading(true);
        const data = await addAccountApi(values);
        setSpingloading(false);
        //隐藏窗口显示
        hidenAccountModal();
        //刷新列表
        afterOk();
    }
    //提交表单失败的回调
    function onFinishFailed(){

    }
    const formInstance=useRef(null);
    //点击确认按钮
    function handleOk(){
        formInstance.current.submit();
    }
    return (
        <Modal title="提示"
            visible={isModalVisible}
            onOk={handleOk}
            onCancel={hidenAccountModal}>
            <Spin spinning={spingloading}>
                <Form
                    labelCol={5}
                    name="basic"
                    onFinish={onFinish}
                    onFinishFailed={onFinishFailed}
                    initialValues={{ userGroup: '普通管理员' }}
                    ref={formInstance}
                >
                    <Form.Item
                        label="账户"
                        name="account"
                        rules={[{ required: true, message: '请输入账户!' }]}
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item
                        label="密码"
                        name="password"
                        rules={[{ required: true, message: '请输入密码!' }]}
                    >
                        <Input.Password />
                    </Form.Item>
                    <Form.Item name="userGroup" label="角色" rules={[{ required: true }]}>
                        <Select
                            placeholder="请选择角色"
                        >
                            <Option value="超级管理员">超级管理员</Option>
                            <Option value="普通管理员">普通管理员</Option>
                        </Select>
                    </Form.Item>
                </Form>
            </Spin>
        </Modal>
    )
}
```

### 9.自定义hook

  自定义hook提取函数组件公共逻辑 

- 自定义hook的作用在于提取公共逻辑，所以一般不会返回一个JSX对象，而是会根据需要返回特定的数据或者方法   
- 自定义hook必须要以use开头 

假设现在有Test1和Test2两个函数组件，他们有一些公共逻辑需要提取，比如都要从后台获取一个列表数据，然后用户界面的渲染，则现在可以编写一个自定义hook来提取这部分公共逻辑，以避免重复写代码 

```js
import {useState,useEffect} from 'react'
export default function useData(){
    const [list,setList] = useState([]);
	useEffect(()=>{setTimeout(()=>{            
        const list = [1,2,3]            
        setList(list);        
    },200);},[]);
    return {list,}}
//Test1
import useData from '...'
function Test1(){
    const {list} = useData();
    return 
    div>
        {...用list渲染JSX}
    </div>
}
//Test2类似
```

### 10在函数组件redux

```js
import {useDispatch,useSelector} from "react-redux"
const dispatch = useDispatch()
const {list} = useSelector(state=>({
	list:state.cartList
}))
```









































