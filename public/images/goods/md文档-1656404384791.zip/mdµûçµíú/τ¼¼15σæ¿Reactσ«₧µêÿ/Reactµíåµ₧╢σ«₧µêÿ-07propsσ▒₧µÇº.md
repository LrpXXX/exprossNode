## 组件的props属性

​		在组件中数据是需要动态更新，数据的来源主要有两部分，第一部分是外部的数据props属性来获取，第二部分是内部数据state，不管是外部的数据还是内部的数据我们都可以获取到过后进行动态的渲染。

#### 3.1 函数式组件的props

```js
import React from 'react';
import ReactDOM from 'react-dom';
function LoginForm(props){
    return <h1>{props.title}登录</h1>;
}
const template=<LoginForm title='管理员'></LoginForm>
ReactDOM.render(template,document.getElementById('root'));
```

当然也可以自己在调用函数组件的时候指定其他的，比如下面这个例子输入会员，就会变成会员登录

```js
import React from 'react';
import ReactDOM from 'react-dom';
function LoginForm(props){
    return <h1>{props.title}登录</h1>;
}
const template=<LoginForm title='会员'></LoginForm>
ReactDOM.render(template,document.getElementById('root'));
```

下面我们再定义一个函数式组件，然后在这里边传递多个参数

```js
import React from 'react';
import ReactDOM from 'react-dom';

function UserInfo(props){
    console.log(props);
    const template=(
        <div>
            <ul>
                <li>姓名:{props.username}</li>
                <li>年龄:{props.age}</li>
                <li>特长:{props.specialty}</li>
            </ul>
        </div>
    );
    return template;
}
const template=(
    <div>
        <UserInfo username={'马保国'} age={56} specialty={'太极'}></UserInfo>
    </div>
);
ReactDOM.render(template,document.getElementById('root'));
```

显示效果如下所示，我们通过对控制台的观察，会发现props就是传递的JS对象的值

![1608275680489](C:\Users\Administrator\AppData\Roaming\Typora\typora-user-images\1608275680489.png)

如上给组件赋值除了赋常量外也可以传递变量，如下所示

```js
import React from 'react';
import ReactDOM from 'react-dom';

function UserInfo(props){
    const template=(
        <div>
            <ul>
                <li>姓名:{props.username}</li>
                <li>年龄:{props.age}</li>
                <li>特长:{props.specialty}</li>
            </ul>
        </div>
    );
    return template;
}
const u={
    username:'马保国',
    age:69,
    specialty:'打太极'
};
const template=(
    <div>
        <UserInfo username={u.username} age={u.age} specialty={u.specialty}></UserInfo>
    </div>
);
ReactDOM.render(template,document.getElementById('root'));
```

其实还有简写方式

```js
import React from 'react';
import ReactDOM from 'react-dom';

function UserInfo(props){
    const template=(
        <div>
            <ul>
                <li>姓名:{props.username}</li>
                <li>年龄:{props.age}</li>
                <li>特长:{props.specialty}</li>
            </ul>
        </div>
    );
    return template;
}
const u={
    username:'马保国',
    age:69,
    specialty:'打太极'
};
const template=(
    <div>
        <UserInfo {...u}></UserInfo>
    </div>
);
ReactDOM.render(template,document.getElementById('root'));
```

#### 3.2 类式组件的props

如上在React函数组件中，定义的javaScript函数式支持带参数的，那么在React类组件如何使用props参数呢？

如果是类组件，props属性是当前组件实例中的一个属性，如下所示

```js
import React from 'react'
class User extends React.Component{
    render(){
        console.log(this);
        const template=(
            <div>
                <ul>
                    <li>用户名:{this.props.username}</li>
                    <li>年龄:{this.props.age}</li>
                    <li>特长:{this.props.specialty}</li>
                </ul>
            </div>
        );
        return template;
    }
}
export default User;
```

构造函数中获取props

```jsx
constructor(props){
    super();
    this.data = props;
}
```

index.js中调用类组件

```js
import React from 'react';
import ReactDOM from 'react-dom';
import User from './User'

const u={
    username:'马保国',
    age:69,
    specialty:'打太极'
};

const template=(
    <div>
        <User {...u}></User>
    </div>
);
ReactDOM.render(template,document.getElementById('root'));
```

![1608277122412](C:\Users\Administrator\AppData\Roaming\Typora\typora-user-images\1608277122412.png)

#### 3.3 props默认值

首先，先来完成一个函数组件的默认值案例

```js
import React from 'react';
import ReactDOM from 'react-dom';

function UserInfo(props){
    const template=(
        <div>
            <ul>
                <li>姓名:{props.username}</li>
                <li>年龄:{props.age}</li>
                <li>特长:{props.specialty}</li>
            </ul>
        </div>
    );
    return template;
}
//设置默认值的语法 组件名.defaultProps
UserInfo.defaultProps={
    username:'无名氏',
    age:0,
    specialty:'无特长'
}
const template=(
    <div>
        <UserInfo username='张明理'></UserInfo>
    </div>
);
ReactDOM.render(template,document.getElementById('root'));
```

这里如果在调用组件的时候赋值，那么默认值就不会生效了，倘若，默认值就会生效。

在类组件中默认值的设置和上面函数组件相同

```js
import React from 'react';
class User extends React.Component{
    render(){
       const template=(
        <div>
            <ul>
                <li>姓名:{this.props.username}</li>
                <li>年龄:{this.props.age}</li>
                <li>特长:{this.props.specialty}</li>
            </ul>
        </div>
       );
       return template;
    }
}
User.defaultProps={
    username:'无名',
    age:20,
    specialty:'无特长'
}
export default User;
```

类组件中除了有如上方式外，其实还有一种更加简便的方式，如下所示

```js
import React from 'react';
class User extends React.Component{
    static defaultProps={
        username:'无名字',
        age:20,
        specialty:'无特长'
    }
    render(){
       const template=(
        <div>
            <ul>
                <li>姓名:{this.props.username}</li>
                <li>年龄:{this.props.age}</li>
                <li>特长:{this.props.specialty}</li>
            </ul>
        </div>
       );
       return template;
    }
}
export default User;
```

#### 3.4 props验证器

随着你的应用程序不断增长，你可以通过类型检查捕获大量错误，PropTypes 提供一系列验证器，可用于确保组件接收到的数据类型是有效的。

首先执行如下命令下载protypes

```bash
npm install --save prop-types
或者
yarn add prop-types
```

```js
import React from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';

function UserInfo(props){
    const template=(
        <div>
            <ul>
                <li>姓名:{props.username}</li>
                <li>年龄:{props.age}</li>
                <li>特长:{props.specialty}</li>
            </ul>
        </div>
    );
    return template;
}
UserInfo.propTypes={
    username:PropTypes.string.isRequired,
    age:PropTypes.number.isRequired,
    specialty:PropTypes.string
}
const template=(
    <div>
        <UserInfo age={'20岁'} specialty='打羽毛球'></UserInfo>
    </div>
);
ReactDOM.render(template,document.getElementById('root'));
```

页面显示不会出错，但是控制台会报如下错误提示

![image-20201218214307220](F:\WEB前端\笔记\第4阶段\第15周React实战\image\image-20201218214307220.png)

下面我们再来看以下类组件中如何设置props的验证器，也有两种方式

```js
import React from 'react';
import PropTypes from 'prop-types';
class User extends React.Component{
    render(){
       const template=(
        <div>
            <ul>
                <li>姓名:{this.props.username}</li>
                <li>年龄:{this.props.age}</li>
                <li>特长:{this.props.specialty}</li>
            </ul>
        </div>
       );
       return template;
    }
}
User.defaultProps={
    username:'无名',
    age:20,
    specialty:'无特长'
}
User.propTypes={
    username:PropTypes.string.isRequired,
    age:PropTypes.number.isRequired,
    specialty:PropTypes.string
}
export default User;
```

另外一种方式

```js
import React from 'react';
import PropTypes from 'prop-types';
class User extends React.Component{
    static defaultProps={
        username:'无名',
        age:20,
        specialty:'无特长'
    }
    static propTypes={
        username:PropTypes.string.isRequired,
        age:PropTypes.number.isRequired,
        specialty:PropTypes.string
    }
    render(){
       const template=(
        <div>
            <ul>
                <li>姓名:{this.props.username}</li>
                <li>年龄:{this.props.age}</li>
                <li>特长:{this.props.specialty}</li>
            </ul>
        </div>
       );
       return template;
    }
}
export default User;
```

#### 3.5 props的只读性

父组件

```js
import React, { Component } from 'react'
import Child from './Child';


export default class Parent extends Component {
    render() {
        return (
            <div>
                Parent
                <Child something="Hi，我是来自Parent中的数据"></Child>
            </div>
        )
    }
}
```

子组件

```js
import React, { Component } from 'react'
import PropTypes from 'prop-types'

export default class Child extends Component {
    static defaultProps={
        something:'来自parnet的something'
    }
    static propTypes={
        something:PropTypes.number
    }
    changeMsg=()=>{
        this.props.something="其他数据";
    }
    render() {
        return (
            <div>
                Child:{this.props.something}
                <button onClick={this.changeMsg}>改变数据</button>
            </div>
        )
    }
}
```

此时，如果单击改变数据的按钮的时候，会出现如下错误

![image-20201220105018685](F:\WEB前端\笔记\第4阶段\第15周React实战\image\image-20201220105018685.png)

这是因为组件件的外部属性props，在组件内部不可修改，是只读的。这些数据只能被数据的提供者修改 

如上的属性值是基本类型，不可修改

父组件d

```js
import React, { Component } from 'react'
import Child from './Child';

export default class Parent extends Component {
 
    render() {
        const obj={
            name:'张三'
        }
        return (
           
            <div>
                Parent
                 <Child obj={obj}></Child>
            </div>
        )
    }
}
```

子组件

```js
import React, { Component } from 'react'

export default class Child extends Component {
    componentDidMount(){
        this.props.obj.name="李四";
        console.log(this.props.obj)
    }
    render() {
        return (
            <div>
                Child:{this.props.obj.name}

            </div>
        )
    }
}
```

控制台效果

![1610351966390](F:\WEB前端\笔记\第4阶段\第15周React实战\image\1610351966390.png)

通过如上图可以发现父组件传递的如果是引用数据类型，引用数据类型中的属性是可以被修改的；再观察控制台数据已经更新了，但是页面中的内容还没有更新过来，如果要让页面中的内容及时更新,则调用this.forceUpdate()来实现立即更新

```js
import React, { Component } from 'react'

export default class Child extends Component {
    componentDidMount(){
        this.props.obj.name="李四";
        console.log(this.props.obj)
        this.forceUpdate();
    }
    render() {
        return (
            <div>
                Child:{this.props.obj.name}

            </div>
        )
    }
}
```

但是，如果我们此时更改的是引用类型本身，这个时候也是不允许修改的

```js
import React, { Component } from 'react'

export default class Child extends Component {
    componentDidMount(){
        this.props.obj={
            name:'李四'
        }
        //this.props.obj.name="李四";
        console.log(this.props.obj)
        this.forceUpdate();
    }
    render() {
        return (
            <div>
                Child:{this.props.obj.name}

            </div>
        )
    }
}
```

通过如上代码，我们可以得出如下结论

组件的外部属性props，在组件内部不可修改，是只读的。这些数据只能被数据的提供者修改

- 属性值是基本类型，则不可修改
- 属性值是引用类型，则引用本身不可修改，但是该引用数据的某些属性是可以修改的 

