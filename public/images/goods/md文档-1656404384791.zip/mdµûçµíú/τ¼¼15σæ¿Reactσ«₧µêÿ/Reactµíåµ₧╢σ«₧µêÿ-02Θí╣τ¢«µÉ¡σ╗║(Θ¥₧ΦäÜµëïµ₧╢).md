## 二.React入门案例

### 1.入门案例

1.1 初始化项目

```bash
npm init -y
```

1.2.安装相关依赖包

```bash
npm install react --save
npm install react-dom --save
npm install babel-standalone --save-dev
或者
yarn add react
yarn add react-dom
yarn add babel-standalone
```

react: react的核心包

react-dom: 提供与DOM相关的功能

babel-standalone:由Babel编译器提供，可以将ES6代码转为ES5代码，这样就能在不支持ES6的浏览器上执行React代码

1.3.在项目中的index.html中编写代码如下

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>第一个react.js</title>
    <script src="./node_modules/react/umd/react.development.js"></script>
    <script src="./node_modules/react-dom/umd/react-dom.development.js"></script>
    <script src="./node_modules/babel-standalone/babel.js"></script>
</head>
<body>
    <div id="root"></div>
    <script type="text/babel">
        const template=React.createElement("h1",null,"Hello React");
        ReactDOM.render(template,document.getElementById('root'));
    </script>
</body>
</html>
```

扩展：设置vscode自动补全react自动补全代码

在vscode编辑器最上方tab栏，点击文件(F)-->首选项-->设置（快捷键Ctr+,)，在搜索框中输入Include Languages，选择Emmet，并在Emmet：include language下点击在setting.json中编辑，添加:

```js
"emmet.includeLanguages": {
    "javascript": "javascriptreact"
},
```

 ![1611282431505](https://woniumd.oss-cn-hangzhou.aliyuncs.com/web/xuchaobo/20210808152000.png) 

组件按tab键没有自动补全，同样，在设置界面搜索框中输入Trigger Expansion On Tab，选择Emmet:Trigger Expansion On Tab将其勾选上。 

![1611282530148](https://woniumd.oss-cn-hangzhou.aliyuncs.com/web/xuchaobo/20210808152035.png)



### 2.创建虚拟DOM的方式

在上面的例子中，我们通过React对象中提供的createElement函数完成了虚拟DOM的创建，而后再通过ReactDOM的render函数将其渲染到页面的指定元素中，这种方式创建虚拟DOM的方式相对而言比较麻烦,而且循环创建多个元素的时候，还需要指定key,否则会报错。

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>第一个react.js</title>
    <script src="./node_modules/react/umd/react.development.js"></script>
    <script src="./node_modules/react-dom/umd/react-dom.development.js"></script>
    <script src="./node_modules/babel-standalone/babel.js"></script>
</head>
<body>
    <div id="root"></div>
    <script>
        const helloRectEle=React.createElement("h1",null,"Hello React");
        const helloWoniuEle=React.createElement("h1",null,"Hello Woniuxy");
        const helloGilesEle=React.createElement("h1",null,"Hello Giles");
        const containerEle=React.createElement("div",null,  [helloRectEle,helloWoniuEle,helloGilesEle]);
        ReactDOM.render(containerEle,document.getElementById('root'));
    </script>
</body>
</html>
```

如上页面显示是正常的，但是控制台会报如下错误

```
Warning: Each child in a list should have a unique "key" prop.

Check the top-level render call using <div>. See https://reactjs.org/link/warning-keys for more information.
    at h1
```

 这是因为在循环生成多个组件的时候，没有给组件加上key引起，具体修改如下

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>第一个react.js</title>
    <script src="./node_modules/react/umd/react.development.js"></script>
    <script src="./node_modules/react-dom/umd/react-dom.development.js"></script>
    <script src="./node_modules/babel-standalone/babel.js"></script>
</head>
<body>
    <div id="root"></div>
    <script>
        const helloRectEle=React.createElement("h1",{key:0},"Hello React");
        const helloWoniuEle=React.createElement("h1",{key:1},"Hello Woniuxy");
        const helloGilesEle=React.createElement("h1",{key:2},"Hello Giles");
        const containerEle=React.createElement("div",null,[helloRectEle,helloWoniuEle,helloGilesEle]);
        ReactDOM.render(containerEle,document.getElementById('root'));
    </script>
</body>
</html>
```

其实创建虚拟DOM除了上面这种方式外，还有更加简单的方式，就是使用JSX方式创建，下面我们先来通过一段代码来看一下，后续我们再具体详细讲解JSX的语法

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>第一个react.js</title>
    <script src="./node_modules/react/umd/react.development.js"></script>
    <script src="./node_modules/react-dom/umd/react-dom.development.js"></script>
    <script src="./node_modules/babel-standalone/babel.js"></script>
</head>
<body>
    <div id="root"></div>
    <script type="text/babel">
        const conatiner=(
            <div>
                <h1>Hello React</h1>
                <h1>Hello Woniuxy</h1>
                <h1>Hello Giles</h1>
            </div>
        )
        ReactDOM.render(conatiner,document.getElementById('root'));
    </script>
</body>
</html>
```

实际上JSX的方式最终还是会转成第一种使用React.createElement()函数创建的方式，这里只是为了方便使用了JSX,我们编写的JSX通过babel来转换的，下面我们可以在官网上来做这个实验

下面是babel的官网：babel官方网站： https://www.babeljs.cn/ 

这里提供了将JSX的方式最终转成createElement的方式

![image-20210808160344407](https://woniumd.oss-cn-hangzhou.aliyuncs.com/web/xuchaobo/20210808160344.png)

## 三.React脚手架搭建

脚手架: 用来帮助程序员快速创建一个基于库的模板项目

1.  包含了所有需要的配置

2.  指定好了所有的依赖

3.  可以直接安装/编译/运行一个简单效果

react提供了一个用于创建react项目的脚手架库: create-react-app

1. 项目的整体技术架构为:  react + webpack + es6 + eslint

2. 使用脚手架开发的项目的特点: 模块化, 组件化, 工程化

### create-react-app

搭建react脚手架有几种方式，接下来就给大家介绍一下各种方式：

1. 全局安装脚手架工具

    ```bash
    //全局安装脚手架工具
    npm install -g create-react-app
    //使用脚手架工具创建项目
    create-react-app reactdemo
    ```

    使用全局安装的方式来创建脚手架工具，这种方式一旦使用，那后续就可以使用本地的脚手架来创建项目。但是需要注意，脚手架工具一旦更新后，全局安装的工具需要自己更新一下

2. npx临时安装脚手架

    ```bash
    npx create-react-app reactdemo
    ```

    使用npx来创建脚手架工具，会临时在创建`create-react-app工具`,当项目创建完毕后，会立即删除`create-react-app`工具,这种方式创建项目可能会慢一些，但是你能保证你使用的是最新的脚手架工具来创建项目

3. yarn包管理安装脚手架

    ```bash
    yarn xxx
    ```

使用脚手架创建完我们的项目后，我们会看到如下的一些信息。

```bash
  npm start
    Starts the development server.

  npm run build
    Bundles the app into static files for production.

  npm test
  
    Starts the test runner.

  npm run eject
    Removes this tool and copies build dependencies, configuration files
    and scripts into the app directory. If you do this, you can’t go back!

We suggest that you begin by typing:

  cd react02-cli
  npm start
```

- npm start :启动项目的命令，在项目package.json文件中配置的信息
- npm run build：完成项目的构建和打包
- npm test：测试当前项目
- npm run eject：在react中`react-scripts `是 `create-react-app` 的一个核心包，一些脚本和工具的默认配置都集成在里面，比如webpack配置文件，babel的配置文件等等信息。eject 命令执行后会将封装在 `create-react-app `中的配置全部反编译到当前项目，这样用户就能完全取得 webpack 文件的控制权。

接下来我们将项目导入到vscode中使用，目录结果如下图所示：

![image-20200908232941406](https://woniumd.oss-cn-hangzhou.aliyuncs.com/web/xuchaobo/20210808160712.png)



- node_modules:项目依赖包的文件夹
- public：存放静态资源文件的目录
    - index.html：当前项目默认模板文件
- src：源代码的存放位置
    - index.js：项目的入口文件
    - app.js：项目的跟组件，相当于vue中的app.vue 文件
- .gitignore：git提交的时候，配置需要忽略的文件

## 四.React JSX

​		通过上面的代码，大家可以清晰的看到使用JSX方式创建虚拟DOM的方式更加简单，而且还有一个很奇怪的写法就是在js中可以直接写HTML代码，而且不使用双引号的方式作为字符串来括起来，这个是我们之前所学的知识无法实现的，但是在React中就可以这么做，这种语法我们称为JSX语法。

### 1.什么是JSX

​		JSX=JavaScript+XML，可以说是JavaScript的一种扩展语法，他结合了JavaScript和xml的语法，JSX 可以很好地描述 UI 应该呈现出它应有交互的本质形式。JSX 可能会使人联想到模版语言，但它具有 JavaScript 的全部功能。

​		React 认为渲染逻辑本质上与其他 UI 逻辑内在耦合，比如，在 UI 中需要绑定处理事件、在某些时刻状态发生变化时需要通知到 UI，以及需要在 UI 中展示准备好的数据。

使用JSX语法的优点：

- JSX 执行更快，因为它在编译为 JavaScript 代码后进行了优化
- JSX 是类型安全的，在编译过程中就能发现错误
- 使用 JSX 编写模板更简单快速

### 2.JSX表达式

**2.1 JSX嵌入表达式**

我们声明了一个名为 name 的变量，然后在 JSX 中使用它，并将它包裹在大括号中：

```js
const name="蜗牛学院";
const template=<div>欢迎来到{name}</div>
ReactDOM.render(template,document.getElementById('root'));
```

在上面的代码中，我们在h1模板里面创建了一个大括号，并且引用了name这个变量，那最终渲染的时候，就会将变量的值放在模板中一起渲染出结果。

最终在渲染的时候，遇到`<>`标签就解析为html代码，遇到`{}`就按照JavaScript来解析，这就是我们的规则。

**2.2 算数表达式**

```js
let firstNum=10;
let secondNum=20;
const template=<div>结果为:{firstNum+secondNum}</div>
ReactDOM.render(template,document.getElementById('root'));
```

**2.3 条件表达式**

```js
let age=12;
const template=<div>是否成年:{age>=18?'成年':'未成年'}</div>
ReactDOM.render(template,document.getElementById('root'));
```

**2.4 JSX对象表达式**

```js
const user={
       username:'Giles',
       school:'蜗牛学院西安校区',
}
const template=<h1>我是{user.school}的{user.username}</h1>
ReactDOM.render(template,document.getElementById('root'));
```

**2.5 JSX函数表达式**

甚至在括号中，我们调用函数也是可以的

```js
const user={
    username:'Giles',
    school:'蜗牛学院西安校区',
}
function introduce(user){
    return "我是"+user.school+"的"+user.username;
}
const template=<h1>{introduce(user)}</h1>
ReactDOM.render(template,document.getElementById('root'));
```

**2.6 JSX数组表达式**

```js
import React from 'react';
import ReactDOM from 'react-dom';
const students=['张晓华','王明','黄森'];
const template=(
    <div>
        <h2>学生列表</h2>
        {students}
    </div>
);
ReactDOM.render(template,document.getElementById('root'));
```

如上操作显示数组中的内容，如果要遍历这个数组代码如下所示

```js
import React from 'react';
import ReactDOM from 'react-dom';
const students=['张晓华','王明','黄森'];
const studentsDom=students.map((item,index)=>{
    return <li key={index}>{item}</li>
});
const template=(
    <div>
        <h2>学生列表</h2>
        <ul>
            {studentsDom}
        </ul>
    </div>
);
ReactDOM.render(template,document.getElementById('root'));
```

### **2.7 JSX防止注入攻击**

```jsx
const template  = <script> alert() </script>

ReactDOM.render(
  template,
  document.getElementById('root')
);
```

React DOM 在渲染所有输入内容之前，默认会进行转义。它可以确保在你的应用中，永远不会注入那些并非自己明确编写的内容。所有的内容在渲染之前都被转换成了字符串。这样可以有效地防止 XSS（cross-site-scripting, 跨站脚本）攻击。

​		上面的代码中，我们在模板中写了alert()函数，最终在解析的时候，会将alert函数看成是字符串来解析。

### 3.JSX中的样式

**3.1 行内样式**

```js
import React from 'react';
import ReactDOM from 'react-dom';
const students=['张晓华','王明','黄森'];
const studentsDom=students.map((item,index)=>{
    return <li key={index} style={{listStyleType:'circle'}}>{item}</li>
});
const template=(
    <div>
        <h2>学生列表</h2>
        <ul>
            {studentsDom}
        </ul>
    </div>
);
ReactDOM.render(template,document.getElementById('root'));
```

注意：行内样式要使用style={{key:value}}的形式

**3.2 外部样式**

首先，在src中新建index.css文件，代码如下

```css
.studentList{
    list-style-type:square;
}
```

其次，在index.js中导入并使用className进行引入

```js
import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
const students=['张晓华','王明','黄森'];
const studentsDom=students.map((item,index)=>{
    return <li key={index} className='studentList'>{item}</li>
});
const template=(
    <div>
        <h2>学生列表</h2>
        <ul>
            {studentsDom}
        </ul>
    </div>
);
ReactDOM.render(template,document.getElementById('root'));
```

注意：样式的类名指定使用className,切记不要写成class

### 4.JSX包含多个子元素

如果我们定义的标签有多个，这个时候我们需要一个根标签来包裹内容，这是JSX中默认的一个规范，否则代码将无法解析运行，如下所示

```js
const template = <h1>这是标题1</h1><h2>这是标题2</h2>

ReactDOM.render(
  template,
  document.getElementById('root')
);
```

这种写法在编译的过程中就会报错，因为h1和h2这两个标签没有根标签来进行包裹。我们可以将代码改为如下：

```js
const template = <div><h1>这是标题1</h1><h2>这是标题2</h2></div>
```

如果遇到模板包含的内容比较多，我们建议使用`()`将内容包裹起来

```js
const template = (
		<div>
			<h1>这是标题1</h1>
			<h2>这是标题2</h2>
		</div>
)
```

### 5.JSX中的注释

我们在JSX语法中也可以加入注释，可以帮助我们更方便的看代码

```js
const conatiner=(
    <div>
        {/*这里是JSX注释*/} 
        <h1>Hello React</h1>
        <h1>Hello Woniuxy</h1>
        <h1>Hello Giles</h1>
     </div>
)
```

## 五.ES6中类的回顾

类中的内容

```js
class Animal {
   type="哺乳动物";
   static type1="猫科动物";
   static name1="小白猫";
   constructor(name){
    this.name=name;
   }
   introuduce(){
       return "我是"+this.type+",我叫"+this.name;
   }
   introuduce1=()=>{
       return "我叫"+this.name+",我属于"+this.type;
   }
   static introuduce3=()=>{
        return "我叫"+this.name1+",我属于"+Animal.type1;
   }
}
class Dog extends Animal{
   constructor(name){
       super(name);
   }
}
const a1=new Animal();
const a2=new Animal("旺财");
console.log("a1",a1);
console.log("a2",a2);
console.log(a2.introuduce());
console.log(a2.introuduce1());
console.log(Animal.introuduce3())
console.log("***************************************************");
const d1=new Dog("小黑狗");
console.log(d1);
console.log(d1.introuduce());
console.log("***************************************************")

export default Animal;
```

setter和getter方法

```js
class Person{
    _name="default";
    _age=0;
    set setName(name){
        this._name=name;
    }
    get getName(){
        return this._name;
    }
    set setAge(age){
        this._age=age;
    }
    get getAge(){
        return this._age;
    }
}
const p1=new Person();
p1.setName="张三";
p1.setAge=21;
console.log(p1.getName);
console.log(p1.getAge);
export default Person;
```

## 作业练习

## 面试题

```js
function Cat() {
    let showName = function () {
        console.log(1);
    }
    return this;
}

Cat.showName = function () { console.log(2) };
Cat.prototype.showName = function () { console.log(3) };
//  两种方式定义函数，函数声明会先提升，但是变量声明提升赋值后会对产生覆盖
var showName = function () { console.log(4) };
function showName() { console.log(5) };
// 输出数据
Cat.showName();      //2 调用Cat类上面的静态方法showName
showName();          // 4
Cat().showName();    // 报错 Cat()相当于是调用函数，返回的this对象为全局对象
showName();
new Cat.showName();
new Cat().showName();
new new Cat().showName();
 //打印结果？？
```

```js
/**
 * 函数提升优先级比变量提升要高，且不会被变量声明覆盖，但是会被变量赋值覆盖
 */
console.log(foo);
function foo(){
	console.log("函数声明");
}
var foo = "变量";
```

```js
function Cat() {
    showName = function () {
         console.log(1);
     }
     console.log('this',this)
     return this;
}

 Cat.showName = function () { console.log(2) };
 Cat.prototype.showName = function () { console.log(3) };
 var showName = function () { console.log(4) };
 function showName() { console.log(5) };
 Cat.showName();
 showName();
 Cat().showName();
 showName();
 new Cat.showName();
 new Cat().showName();
 new new Cat().showName();
 
 //打印结果，注意跟上一题的区别
```

