## 一.移动端开发方式简介

### 原生开发

**原生开发（Native App）**：原生(Native)应用程序是某一个移动平台（比如iOS或安卓）所特有的，使用相应平台支持的开发工具和语言（比如iOS平台支持Xcode和Objective-C,Swift，安卓平台支持Eclipse和Java）。原生应用程序外观和运行起来（性能）是最佳的。

### 跨平台开发

**H5应用程序（H5APP/WEBAPP）**：HTML5应用程序使用标准的Web技术，通常是HTML5、JavaScript和CSS。这种只编写一次、可到处运行的移动开发方法构建的跨平台移动应用程序可以在多个设备上运行。虽然开发人员单单使用HTML5和JavaScript就能构建功能复杂的应用程序，但截至本文截稿时仍然存在一些重大的局限性，具体包括会话管理、安全离线存储以及访问原生设备功能（摄像头、日历和地理位置等）。

**混合应用程序（HybridAPP）**：混合(Hybrid)应用程序让开发人员可以把HTML5应用程序嵌入到一个细薄的原生容器里面（android里面通常是利用webView控件模拟浏览器内核），集原生应用程序和HTML5应用程序的优点（及缺点）于一体。

**js开发+原生渲染**：react-native即是以这种模式开发的，它和Hybird模式的区别在于，在渲染层面Hybird是利用webview进行渲染的，也就是说还是基于浏览器的，而react-native在渲染的时候用的是各个平台的原生UI控件，它的渲染效果更接近原生

| 开发方式        | 造价 | 跨平台 | 学习难度 | 访问手机原生API | 渲染性能 |
| :-------------- | ---- | ------ | -------- | --------------- | -------- |
| 原生开发        | 高   | 否     | 高       | 可以            | 最好     |
| H5开发          | 低   | 是     | 低       | 否              | 低       |
| 混合开发        | 中   | 是     | 中       | 可以            | 较好     |
| js开发+原生渲染 | 中   | 是     | 中       | 可以            | 好       |
|                 |      |        |          |                 |          |

## 二.react-native之android环境搭建

### 1.android平台环境搭建

#### 1.1 python2.x环境安装

1）下载安装

官网：https://www.python.org/getit/

2） 配置环境变量

配置PYTHON_HOME和PATH环境变量

-  新建PYTHON_HOME环境变量,内容为python的安装根目录
-  PATH中追加%PYTHON_HOME%

3） 测试安装是否成功

命令提示符中输入python

![1609403285001](F:\WEB前端\笔记\第4阶段\第16周React-native\images\1609403285001.png)

#### 1.2.java环境变量配置

1） 下载安装

官网:http://www.oracle.com

2） 配置环境变量

 配置JAVA_HOME，指向JDK的根目录

  ```bash
JAVA_HOME = C:\Program Files\Java\jdk1.8.0_151
  ```

  配置path环境变量，在原有path中追加如下内容

```bash
 path=;%JAVA_HOME%\bin
```

3）测试

```bash
java --version
```

#### 1.3.安装android环境

1） 拷贝SDK到本机

2）   配置环境变量

配置ANDROID_HOME，指向SDK的根目录

```bash
ANDROID_HOME=F:\Sdk
```

 配置path环境变量，在原有path中追加如下内容

```bash
path=;%ANDROID_HOME%\platform-tools
```

3）测试

在CMD窗口中输入如下命令

```bash
adb devices
```

#### 1.4.安装android模拟器

1） 安装夜神模拟器/逍遥模拟器

2） 设置模拟器

![1609404348211](Z:\xuchaobo\work\第四阶段\React\资料\md文档\第16周React-native\image\1609404348211.png)



辨率设置好之后，进入模拟器安装路劲，（比如 C:\Program Files\Nox\bin），打开cmd 执行命令nox_adb devices，然后重启模拟器，并关掉当前命令窗口，接着重新打开一个cmd窗口（注意不要在模拟器安装路径），

执行如下命令连接模拟器

```bash
adb connect 127.0.0.1:62001   #夜神模拟器的端口
adb connect 127.0.0.1:21503   #逍遥模拟器的端口

```

后续可以通过adb devices来检测有无模拟器或者真机连接

```js
adb kill-server //结束adb服务
adb start-server //启动adb服务
adb devices //获取adb设备列表
```

3） 测试

测试模拟器or真机是否连接成功：

在CMD中输入adb devices 检测和计算机连接的Android设备列表

![1609404504818](Z:\xuchaobo\work\第四阶段\React\资料\md文档\第16周React-native\image\1609404504818.png)

### 2.脚手架初始化react-native项目代码

#### 2.1.创建RN项目

在命令提示符中输入如下命令

```bash
npx react-native init RN --version 0.62.2
```

注意：项目路径不能有中文

出现如下页面证明安装成功

![1609404849181](Z:\xuchaobo\work\第四阶段\React\资料\md文档\第16周React-native\image\1609404849181.png)



进入到硬盘的相应目录下，然后使用vscode将其打开

#### 2.2 如何加快第一个初始化项目的速度

**1）在C盘手动配置gradle文件**

 这一步不是必须，后面执行npx react-native run-android或者是yarn android的时候，会自动下载gradle到C盘用户目录，但是会很慢需要翻墙，如果实现有了这个文件之后，则不再需要在启动项目的时候下载了 

 如果没有这个文件，则在运行项目的时候，会出现如下提示 

![1610000486047](Z:\xuchaobo\work\第四阶段\React\资料\md文档\第16周React-native\image\1610000486047.png)



 找到C:\Users\Administrator\.gradle\wrapper\dists\gradle-6.0.1-all\99d3u8wxs16ndehh90lbbir67目录

![1610000663513](Z:\xuchaobo\work\第四阶段\React\资料\md文档\第16周React-native\image\1610000663513.png)



 把gradle-6.0.1-all文件复制进去即可（如果里面有了，可把他先删除） 

**2）配置镜像加快项目启动速度**

找到android目录下面的build.gradle文件，做如下修改 

```gradle
// Top-level build file where you can add configuration options common to all sub-projects/modules.

buildscript {
    ext {
        buildToolsVersion = "28.0.3"
        minSdkVersion = 16
        compileSdkVersion = 28
        targetSdkVersion = 28
    }
    repositories {
        //添加这三行        
        maven { url 'https://maven.aliyun.com/repository/public' }        
        maven { url 'https://maven.aliyun.com/repository/google' }        
        maven { url 'https://maven.aliyun.com/repository/gradle-plugin' }
        //注释掉google和jcenter
        //google()
        //jcenter()
    }
    dependencies {
        classpath("com.android.tools.build:gradle:3.5.2")

        // NOTE: Do not place your application dependencies here; they belong
        // in the individual module build.gradle files
    }
}

allprojects {
    repositories {
        //添加这三行        
        maven { url 'https://maven.aliyun.com/repository/public' }        
        maven { url 'https://maven.aliyun.com/repository/google' }        
        maven { url 'https://maven.aliyun.com/repository/gradle-plugin' }
        mavenLocal()
        maven {
            // All of React Native (JS, Obj-C sources, Android binaries) is installed from npm
            url("$rootDir/../node_modules/react-native/android")
        }
        maven {
            // Android JSC is installed from npm
            url("$rootDir/../node_modules/jsc-android/dist")
        }

        google()
        jcenter()
        maven { url 'https://www.jitpack.io' }
    }
}
```

#### 2.3.运行到android模拟器

进入项目的根目录，执行如下命令

```bash
npx react-native run-android
或者使用
yarn android
```

问题：如果在运行的时候启动不起来，可以将夜神安装目录下的bin中的adb.exe程序复制到ANDROID_HOME/platform-tools下，然后再行执行adb connect 127.0.0.1:62001，然后再执行adb devices，重新启动vscode后再次执行npx react-native run-android就可以解决了

#### 2.4.模拟器调试

**1）如何打开开发菜单**

方式1：如上命令窗口按d键可以打开开发菜单

方式2：打开CMD命令窗口执行: adb shell input keyevent 82

方式3：模拟器右侧>更多>菜单

**2）如何刷新**

方式1：在命令窗口按r键可以实现刷新

方式2：点击菜单中的Reload选项

**3）Debug模式**

点击菜单中的Debug，进入debugger-ui界面，通过查看浏览器中的console来进行调试

![1611543762100](F:\WEB前端\笔记\第4阶段\第16周React-native\images\1611543762100.png)

**4）Toggle Inspect**

![1611543850364](F:\WEB前端\笔记\第4阶段\第16周React-native\images\1611543850364.png)

## 项目结构

将项目导入vscode工具中，我们来分析以下目前默认的项目结构：

<img src="Z:\xuchaobo\work\第四阶段\RN\文档\image\image-20201222094626944.png" alt="image-20201222094626944" style="zoom:50%;" />

<table border="1" cellpadding="1" cellspacing="1" style="width:672px;"><caption>
  <strong>React Native结构目录</strong>
 </caption><thead><tr><th style="width:188px;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 名称</th><th style="width:482px;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 描述</th></tr></thead><tbody><tr><td style="width:188px;">android目录</td><td style="width:482px;">Android项目目录，包含了使用AndroidStudio开发项目的环境配置文件；</td></tr><tr><td style="width:188px;">ios目录</td><td style="width:482px;">iOS项目目录，包含了XCode的环境</td></tr><tr><td style="width:188px;">node_modules目录</td><td style="width:482px;">基于node文件依赖系统产生的相关依赖和第三方lib</td></tr><tr><td style="width:188px;">.babelrc</td><td style="width:482px;">Babel配置文件，在.babelrc配置文件中，主要是对预设（presets）和插件（plugins）进行配置，因此不同的转译器作用不同的配置项</td></tr><tr><td style="width:188px;">.buckconfig</td><td style="width:482px;"><a href="https://buckbuild.com/">Buck</a>的配置文件，buck是Facebook开源的高效构建系统</td></tr><tr><td style="width:188px;">.flowconfig</td><td style="width:482px;"><a href="https://flow.org/">Flow</a>的配置文件，<a href="https://flow.org/en/docs/config/">flowconfig</a>是是Flow的配置文件</td></tr><tr><td style="width:188px;">.gitattributes</td><td style="width:482px;">git配置文件，指定非文本文件的对比合并方式</td></tr><tr><td style="width:188px;">.gitignore</td><td style="width:482px;">git配置文件，用于忽略你不想提交到Git上的文件</td></tr><tr><td style="width:188px;">.watchmanconfig</td><td style="width:482px;"><a href="http://facebook.github.io/watchman/">watchman</a>的配置文件，watchman用于监控文件变化，辅助实现工程修改信息</td></tr><tr><td style="width:188px;">index.ios.js/index.android.js</td><td style="width:482px;"> <p>ios或android的入口，但是已经使用<strong>index.js</strong>代替，android中配置<strong>application</strong>文件的<strong>getJSMainModuleName()</strong>配置入口</p> </td></tr><tr><td style="width:188px;">app.json</td><td style="width:482px;">app的json文件</td></tr><tr><td style="width:188px;">package.json</td><td style="width:482px;">项目基本信息以及依赖信息</td></tr><tr><td style="width:188px;">package-lock.json</td><td style="width:482px;">npm install生成的文件，记录当前npm package的信息</td></tr></tbody></table>


我们在开发中可以自己调整目录结构，或者关注核心的文件就可以

## 三.常用组件和样式

在项目中我们可以使用一下的命令来创建组件

```js
rcc:创建类组件
rnc：rn的类组件
rfc：创建函数组件
rnf：创建rn的函数组件
```

### 1.View&Text组件

View相当于div

Text相当于span，文本必须写在Text标签之间，否则会报错，而且文本样式必须写在Text标签之上，里层Text会继承外层Text的样式 

基础组件：具体的参考地址为：https://reactnative.cn/docs/components-and-apis

### 2.自定义组件

在项目下新建src/components目录，然后在此目录下新建Hello.js组件，注意，在RN开发的时候我们的组件后缀名不能是jsx，必须是js文件。

```js
import React, { Component } from 'react';
import {View,Text} from 'react-native';

export default class Hello extends Component {
    render() {
        return (
            <View>
                <Text>HelloGiles</Text>
            </View>
        )
    }
}

```

在App.js中引入

```js
import Hello from './src/components/Hello'

const App= () => {
  console.log("react native.....")
  return (
    <>
      <Hello></Hello>
    </>
  );
};
```

父子组件传递参数：

```js
{/* 获取父组件的数据 */}
<Text>{this.props.title}</Text>
```

也可以设置props的默认值

```js
// 设置默认值
Hello.defaultProps = {
    age:10
}
```

### 3.样式设置

在react-native中如果要使用css样式，我们可以由两种方式

1. 直接在组件上面增加style标签，填写样式

    ```js
    const App = () => {
      return (
        <View>
            <Text style={{color:"red"}}>蜗牛在线课堂:http://www.woniuxy.com</Text>
        </View>
      );
    };
    ```

2. 通过StyleSheet组件来创建样式对象，在jsx中引入样式样式对象

    ```js
    const styles = StyleSheet.create({
      bg:{
        backgroundColor:"orange"
      }
    })
    在App外面定义styles对象，通过StyleSheet来创建
    <Text style={styles.bg}>蜗牛官网：http://www.woniuxy.cn</Text>
    在Text组件中使用styles来引用。
    ```

3. 样式优先级和继承

    我们可以将上面两种写法合并在一起

    ```
    <Text style={styles.bg,{backgroundColor:"tomato"}}>蜗牛官网：http://www.woniuxy.cn</Text>
    ```

    最终渲染的颜色是tomato，你可以理解为这个是内联样式。通过styles.bg创建的是内部样式。

    继承样式

    ```html
    <View style={styles.fontSty}>
            <Text style={{color:"red"}}>蜗牛在线课堂:http://www.woniuxy.com</Text>
            <Text style={styles.bg}>蜗牛官网：http://www.woniuxy.cn</Text>
            <Text style={styles.bg,{backgroundColor:"tomato"}}>蜗牛官网：http://www.woniuxy.cn</Text>
        </View>
    ```

    我们设置fontSty字体大小为30，你会发现子类并没有继承。这是由别于css样式继承的。

    >在RN中我们写的任何内容都不能有px像素单位
    >
    >默认写数字就可以了。

## 四.flex布局

 flex布局常用属性

1. justifyContent: center | space-between | space-around (控制主轴方向上的元素的排版
2. alignItems:center | flex-start | flex-end （控制侧轴方向上元素的排版）
3.  flexDirection:row | column (决定主轴方向是水平方向还是垂直方向 

 注意：在rn里面flex盒子的主轴方向默认是垂直方向  

```js
import React, { Component } from 'react'
import { Text, View ,StyleSheet} from 'react-native'

export default class FlexLayout extends Component {
    render() {
        return (
           <View style={styles.container}>
               <View style={[styles.box,{backgroundColor:'red'}]}><Text>1</Text></View>
               <View style={[styles.box,{backgroundColor:'green'}]}><Text>2</Text></View>
               <View style={[styles.box,{backgroundColor:'blue'}]}><Text>3</Text></View>
           </View>
        )
    }
}
const styles=StyleSheet.create({
    box:{
        width:50,
        height:50,
        justifyContent:'center',
        alignItems:'center'
    },
    container:{
        flexDirection:'row',
        justifyContent:'space-between',
        alignItems:'center',
        flex:1,
        backgroundColor:'pink'
    }
});
```

我们在view上面设置原生的排列方式为row，并设置text组件flex-grow为1.在页面上渲染的效果就是两个文本占满一行排列。

注意：

1. 在RN中单位不能使用px、vh、vw默认写数字就可以。
2. 可以使用百分比来设置盒子的宽度

```html
 <View style={{width:"50%",height:100,backgroundColor:"pink"}}>
 	<View style={{width:"50%",height:50,backgroundColor:"tomato"}}></View>
 </View>
```

width：50%获取的是父元素的宽度，如果你要获取到屏幕宽度的50%，需要如下代码：

```js
import { StyleSheet, Text, View, Dimensions } from 'react-native'

const width = Dimensions.get("window").width;
const height = Dimensions.get("window").height;
export default class Content extends Component {
    state = {
        dimensions: {
            width,
            height
        }
    }
    <View style={{ width: this.state.dimensions.width / 2, height: 40, backgroundColor: "blue" }}></View>
```

将width和height获取到，放在state里面加载。以后级可以直接在任何组件中使用。

## 系统组件的介绍

在RN中默认给我们提供了很多的组件，类似于以前html中的标签，接下来就给大家介绍以下常用的组件

| 组件名字          | 含义                                                         |
| ----------------- | ------------------------------------------------------------ |
| View              | 相当于web中的div标签，不支持字体大小、颜色，不能直接放文本   |
| Text              | 文本标签，可以设置字体大小、颜色，支持事件绑定               |
| TouchableOpacity  | 可以绑定点击事件的块元素，可以设置点击时的透明度             |
| Image             | 图片标签，可以渲染本地图片和网络图片                         |
| ImageBackground   | 设置背景图片，在RN中默认不能使用background-image属性，只能使用组件 |
| TextInput         | 文本框组件，需要通过事件来获取值                             |
| ActivityIndicator | 显示一个加载效果图                                           |
| Button            | 一个简单的跨平台的按钮组件。可以进行一些简单的定制。         |
|                   |                                                              |

### TouchableOpacity组件使用

```html
show(){
        alert("show");
}
<TouchableOpacity activeOpacity={1} onPress={this.show}>
	<Text>蜗牛学院</Text>
</TouchableOpacity>
```

可以给TouchableOpacity组件增加activeOpacity属性和绑定onPress点击事件

### Image组件

- 本地图片

    ```html
    {/* <Image source={require("../../assets/images/logo_black.png")}/> */}
    {/* <Image source={require("../../assets/images/pic01.jpg")}/> */}
    {/* <Image source={require("../../assets/images/123.gif")}/> */}
    ```

    可以加载本地的图片，也可以加载网络图片

    需要使用require来引入本地图片资源

- 网络图片

    ```html
    <Image style={{width:"100%",height:200}} source={{uri:"http://pic91.nipic.com/file/20160309/20790766_161653397000_2.jpg"}}/>
    ```

    网络图片需要加上uri地址，还需要加上width和height。否则图片无法显示

- android默认不支持gif和webP格式的图片

    android设备默认无法执行gif动画效果，你要让安卓可以执行那需要配置

    在android/app/build.gradle的dependencies中添加

    ```js
    // 如果你需要支持GIF动图
    implementation 'com.facebook.fresco:animated-gif:2.0.0'
    
    // 如果你需要支持WebP格式，包括WebP动图
    implementation 'com.facebook.fresco:animated-webp:2.1.0'
    implementation 'com.facebook.fresco:webpsupport:2.0.0'
    
    // 如果只需要支持WebP格式而不需要动图
    implementation 'com.facebook.fresco:webpsupport:2.0.0'
    ```

    添加以上配置过后，你可以可以支持gif和webp的图片格式

### ImageBackground组件

设置背景图片

```html
{/* 背景图片 */}
<ImageBackground style={{width:"100%",height:50}} source={require("../../assets/images/pic01.jpg")}>
	<Text>测试图片</Text>
</ImageBackground>
```

注意：必须要由style属性，否则报错

### TextInput

文本框组件，默认没有边框

```html
handlerText(text){
   alert(text);
}
handlerFocus(text){
	console.log(text);
}
{/* TextInput组件 */}
<TextInput 
    style={{borderColor:"orange",borderWidth:2}} 
    onChangeText={this.handlerText}
    onFocus={this.handlerFocus}
/>
```

onChangeText事件就是检查文本信息，一旦发生改变就执行handlerText，onFocus为获取到焦点事件。

## 五.项目开发

这里我们完成豆瓣项目为例，来进行学习

### 项目结构搭建

1. 使用node命令创建项目

    ```bash
    npx react-native init RNMovies --version 0.62.2
    ```

2. 搭建项目结构

    ​	<img src="Z:\xuchaobo\work\第四阶段\RN\文档\image\image-20201225114843476.png" alt="image-20201225114843476" style="zoom:50%;" />

3. 创建项目需要用到的页面

    <img src="Z:\xuchaobo\work\第四阶段\RN\文档\image\image-20201225120200466.png" alt="image-20201225120200466" style="zoom:50%;" />

    

分别创建如下界面

| 页面路径               | 组件类型 | 说明     |
| ---------------------- | -------- | -------- |
| src/pages/Login.js     | 函数组件 | 登录页面 |
| src/pages/DouList.js   | 函数组件 | 列表页面 |
| src/pages/DouDetail.js | 类组件   | 详情页面 |
| src/pages/NavPage.js   | 函数组件 | 导航页面 |

### 路由配置

在RN中要使用路由和React中是不一样的，我们需要下载路由组件来进行使用,react-navigation和react-router-dom类似，只不过react-navigation用于为android/ios端，提供完整的路由解决

https://reactnavigation.org/docs/getting-started

方案

1. 下载安装react-navigation

    ```bash
    yarn add @react-navigation/native
    ```

2. 下载react-navigation相关依赖

    ```
    yarn add react-native-reanimated react-native-gesture-handler react-native-screens react-native-safe-area-context @react-native-community/masked-view
    ```

3. 在App.js文件中引入react-navigation组件，定义路由容器

    ```js
    import 'react-native-gesture-handler'; //必须放在第一行
    import React, { Component } from 'react'
    import { NavigationContainer } from '@react-navigation/native';
    
    export default class App extends Component {
      render() {
        return (
            // 配置路由容器，类似于之前react中的hashRouter
           <NavigationContainer>
    	
           </NavigationContainer>
        )
      }
    }
    ```

4. 下载置*stack navigator* 

    ```js
    yarn add @react-navigation/stack
    ```

5. 配置路由信息

    ```js
    import 'react-native-gesture-handler'; //必须放在第一行
    import React, { Component } from 'react'
    import {Text} from "react-native"
    import { NavigationContainer } from '@react-navigation/native';
    import { createStackNavigator } from '@react-navigation/stack';
    import Login from "./src/pages/Login"
    import Navigator from "./src/pages/Navigator"
    import Search from "./src/pages/Search"
    import Detail from "./src/pages/Detail"
    // 创建Stack
    const Stack = createStackNavigator();
    
    export default class App extends Component {
      render() {
        return (
            // 配置路由容器，类似于之前react中的hashRouter
           <NavigationContainer>
             <Stack.Navigator initialRouteName="Navigator">
               <Stack.Screen name="Login" component={Login} options={{title:"登录"}}></Stack.Screen>
               <Stack.Screen name="Navigator" component={Navigator}></Stack.Screen>
               <Stack.Screen name="Detail" component={Detail}></Stack.Screen>
               <Stack.Screen name="Search" component={Search}></Stack.Screen>
             </Stack.Navigator>
           </NavigationContainer>
        )
      }
    }
    
    ```

    在配置中initialRouteName="Navigator"代表默认选中Navigator这个组件

    1. name表示当前路由的名称 

    2. component表示当前路由所要渲染的组件 

    3. options可以对当前页面进行某些配置，比如页面顶部的标题可通过title配置 

    4. 如果不指定初始路由名称（即通过initialRouteName指定的路由名称），则默认第一个 

    关于头部导航我们可以设置一些默认样式，通过options来设计

    ```html
    <Stack.Screen name="Navigator" component={Navigator} options={{
        title:"导航页",
        headerTitleStyle:{ color:'gray' },
        headerStyle:{ 
        	backgroundColor:'green',
        	elevation: 0,
    	}
    }}></Stack.Screen>
    ```

    title：头部标题

    headerTitleStyle：头部的样式，color主要是值文本颜色

    headerStyle：设置头部的公共样式，

    backgroundColor：头部背景

    elevation：去掉阴影效果

## 六.本地存储

在RN中使用AsyncStoreage来实现数据的本地存储，使用步骤

### 1 下载安装 @react-native-community/async-storage 

```js
yarn add @react-native-community/async-storage
```

### 2 使用AsyncStorage对数据进行增删改查 

-  注意：AsyncStorage下面的方法都是异步的 

####   2.1 存储基本数据

 ```js
import AsyncStorage from '@react-native-community/async-storage'
const storeData = async (value) => {  
    try {    
        await AsyncStorage.setItem('@storage_Key', value)  
    } catch (e) {    
        // saving error  
    }
}
 ```

#### 2.2 存储引用数据类型

```js
import AsyncStorage from '@react-native-community/async-storage'
const storeData = async (value) => {  
    try {    
        const jsonValue = JSON.stringify(value)    
        await AsyncStorage.setItem('@storage_Key', jsonValue)  
	} catch (e) {    
    	// saving error  
	}
}
```

####  2.3 读取基本类型数据 

```js
import AsyncStorage from '@react-native-community/async-storage'
const getData = async () => {  
    try {    
        const value = await AsyncStorage.getItem('@storage_Key')    
        if(value !== null) {      
            // value previously stored    
        }  
    } catch(e) {   
        // error reading value  
    }
}
```

#### 2.4 读取引用类型数据 

```js
import AsyncStorage from '@react-native-community/async-storage'
const getData = async () => {  
    try {    
        const jsonValue = await AsyncStorage.getItem('@storage_Key')    
        return jsonValue != null ? JSON.parse(jsonValue) : null;  
    } catch(e) {    
        // error reading value  
    }
}
```

#### 2.5 清除数据

```js
//清除指定数据
AsyncStorage.removeItem(keyName)
//清除所有
AsyncStorage.clear()
```

### 

## 视频播放

1. 下载依赖

   ```
   yarn add react-native-video
   ```

2. 引入依赖

   ```
   import Video from 'react-native-video';
   ```

3. 完整代码

   ```js
   import React from 'react'
   import { View, Text, StyleSheet } from 'react-native'
   // import MyModal from '../MyModal'
   import Video from 'react-native-video';
   
   export default function HomeCenter() {
       let adress1 = "https://media.w3.org/2010/05/sintel/trailer.mp4";
       let adress2 = "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8";
       // currentTime当前时间，playableDuration播放总时间
       const onProgress = (currentTime,playableDuration)=>{
           console.log(currentTime);
           console.log(playableDuration);
       }
       const onEnd = ()=>{
           console.log("end");
       }
       const onLoadStart = ()=>{
           console.log("开始播放");
       }
       return (
           <View>
               <Text>个人中心</Text>
               {/* <MyModal></MyModal>  */}
               <Video source={{ uri: adress1 }}   // Can be a URL or a local file.
                   ref={(ref) => {
                       this.player = ref
                   }}
                   style={styles.backgroundVideo}  //视频样式
                   rate={0}     //0/1,0暂停,1正常
                   resizeMode='cover' //视频适应方式 contain cover
                   repeat={true} //是否重复播放
                   controls={true}  //显示控制按钮
                   volume={1.0}  // 0 is muted（柔和）, 1 is normal（正常）.
                   onProgress={onProgress}  //视频播放每隔250毫秒触发,并携带当前已播放时间
                   onEnd = {onEnd}
                   onLoadStart={onLoadStart}
                />
           </View>
       )
   }
   
   const styles = StyleSheet.create({
       backgroundVideo: {
           width:"100%",
           height:300,
           position: 'absolute',
           top: 0,
           left: 0,
           bottom: 0,
           right: 0
       }
   })
   ```

   